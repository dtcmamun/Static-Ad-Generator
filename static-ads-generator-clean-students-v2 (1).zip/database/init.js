const { Pool } = require('pg');

const LEGACY_TEMPLATE_SEED = [
  { name: 'Customer Quote Card', category: 'Testimonial', image_path: '/uploads/templates/testimonial-customer-quote-card.png' },
  { name: 'Star Rating Review', category: 'Testimonial', image_path: '/uploads/templates/testimonial-star-rating-review.png' },
  { name: 'Before & After Story', category: 'Testimonial', image_path: '/uploads/templates/testimonial-before-after-story.png' },
  { name: 'Flash Sale Banner', category: 'Offer/Discount', image_path: '/uploads/templates/offer-flash-sale-banner.png' },
  { name: 'Percentage Off Deal', category: 'Offer/Discount', image_path: '/uploads/templates/offer-percentage-off-deal.png' },
  { name: 'Limited Time Offer', category: 'Offer/Discount', image_path: '/uploads/templates/offer-limited-time-offer.png' },
  { name: 'Feature Highlight Grid', category: 'Features & Benefits', image_path: '/uploads/templates/features-feature-highlight-grid.png' },
  { name: 'Benefits Comparison', category: 'Features & Benefits', image_path: '/uploads/templates/features-benefits-comparison.png' },
  { name: 'Key Feature Spotlight', category: 'Features & Benefits', image_path: '/uploads/templates/features-key-feature-spotlight.png' },
  { name: 'Stats & Numbers', category: 'Social Proof', image_path: '/uploads/templates/social-stats-numbers.png' },
  { name: 'User Count Showcase', category: 'Social Proof', image_path: '/uploads/templates/social-user-count-showcase.png' },
  { name: 'Trust Badges Layout', category: 'Social Proof', image_path: '/uploads/templates/social-trust-badges-layout.png' },
  { name: 'Bold BF Sale', category: 'Black Friday', image_path: '/uploads/templates/black-friday-bold-sale.png' },
  { name: 'Countdown Deal', category: 'Black Friday', image_path: '/uploads/templates/black-friday-countdown-deal.png' },
  { name: 'Doorbusters Layout', category: 'Black Friday', image_path: '/uploads/templates/black-friday-doorbusters-layout.png' },
  { name: 'Hero Product Shot', category: 'Product Showcase', image_path: '/uploads/templates/showcase-hero-product-shot.png' },
  { name: 'Multi-Angle Display', category: 'Product Showcase', image_path: '/uploads/templates/showcase-multi-angle-display.png' },
  { name: 'Lifestyle Context', category: 'Product Showcase', image_path: '/uploads/templates/showcase-lifestyle-context.png' }
];

const LEGACY_CLIENT_NAMES = new Set(['default client', 'test client ux']);
const LEGACY_CLIENT_SLUGS = new Set(['default-client', 'test-client-ux']);

function buildPoolConfig() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error('DATABASE_URL is not set. Replit provides this automatically for PostgreSQL projects.');
  }

  // Replit/Postgres usually works without SSL config, but this keeps cloud-hosted DBs compatible.
  const forceSsl = String(process.env.PGSSLMODE || '').toLowerCase() === 'require';
  return {
    connectionString,
    ssl: forceSsl ? { rejectUnauthorized: false } : undefined
  };
}

async function initializeSchema(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS clients (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      slug TEXT UNIQUE,
      is_default INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS brand_kits (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL UNIQUE,
      brand_name TEXT,
      brand_description TEXT,
      intelligence_research_text TEXT,
      typography TEXT,
      color_primary TEXT,
      color_secondary TEXT,
      color_accent TEXT,
      logo_dark_path TEXT,
      logo_light_path TEXT,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS templates (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      image_path TEXT NOT NULL,
      source_type TEXT DEFAULT 'starter',
      tags TEXT DEFAULT '[]',
      is_favorite INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS assets (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      file_type TEXT,
      file_size INTEGER,
      category TEXT DEFAULT 'Other',
      file_path TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS generations (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL,
      reference_image_path TEXT,
      product_image_path TEXT,
      prompt TEXT NOT NULL,
      concept_name TEXT,
      avatar_name TEXT,
      size TEXT DEFAULT '1:1',
      used_brand_kit INTEGER DEFAULT 0,
      generated_images TEXT NOT NULL,
      status TEXT DEFAULT 'completed',
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS campaign_tags (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL,
      tag_type TEXT NOT NULL,
      tag_value TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(client_id, tag_type, tag_value)
    );

    CREATE TABLE IF NOT EXISTS brand_intelligence (
      id SERIAL PRIMARY KEY,
      client_id INTEGER NOT NULL,
      persona TEXT NOT NULL,
      pain_point TEXT NOT NULL,
      angle TEXT NOT NULL,
      visual_direction TEXT NOT NULL,
      emotion TEXT NOT NULL,
      copy_hook TEXT,
      source TEXT DEFAULT 'ai',
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );

    ALTER TABLE templates ADD COLUMN IF NOT EXISTS source_type TEXT DEFAULT 'starter';
    ALTER TABLE templates ADD COLUMN IF NOT EXISTS tags TEXT DEFAULT '[]';
    ALTER TABLE templates ADD COLUMN IF NOT EXISTS is_favorite INTEGER DEFAULT 0;
    ALTER TABLE templates ADD COLUMN IF NOT EXISTS client_id INTEGER;

    ALTER TABLE assets ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'Other';
    ALTER TABLE assets ADD COLUMN IF NOT EXISTS client_id INTEGER;

    ALTER TABLE generations ADD COLUMN IF NOT EXISTS concept_name TEXT;
    ALTER TABLE generations ADD COLUMN IF NOT EXISTS avatar_name TEXT;
    ALTER TABLE generations ADD COLUMN IF NOT EXISTS client_id INTEGER;
    ALTER TABLE brand_kits ADD COLUMN IF NOT EXISTS intelligence_research_text TEXT;

    CREATE INDEX IF NOT EXISTS idx_templates_client_id ON templates(client_id);
    CREATE INDEX IF NOT EXISTS idx_assets_client_id ON assets(client_id);
    CREATE INDEX IF NOT EXISTS idx_generations_client_id ON generations(client_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_brand_kits_client_id ON brand_kits(client_id);
    CREATE INDEX IF NOT EXISTS idx_campaign_tags_client_id_type ON campaign_tags(client_id, tag_type);
    CREATE INDEX IF NOT EXISTS idx_brand_intelligence_client_id ON brand_intelligence(client_id);
  `);

  await client.query(`
    UPDATE templates
    SET
      source_type = COALESCE(source_type, 'starter'),
      tags = COALESCE(tags, '[]'),
      is_favorite = COALESCE(is_favorite, 0)
  `);

  await client.query(`
    UPDATE assets
    SET category = COALESCE(NULLIF(BTRIM(category), ''), 'Other')
  `);
}

function isLegacyClient(client) {
  const normalizedName = String(client.name || '').trim().toLowerCase();
  const normalizedSlug = String(client.slug || '').trim().toLowerCase();
  return LEGACY_CLIENT_NAMES.has(normalizedName) || LEGACY_CLIENT_SLUGS.has(normalizedSlug);
}

async function createPrimaryClient(client) {
  let suffix = 1;
  while (suffix < 1000) {
    const name = suffix === 1 ? 'Primary Client' : `Primary Client ${suffix}`;
    const slug = suffix === 1 ? 'primary-client' : `primary-client-${suffix}`;
    const existing = await client.query(
      'SELECT id FROM clients WHERE lower(name) = lower($1) OR slug = $2 LIMIT 1',
      [name, slug]
    );
    if (existing.rowCount === 0) {
      const inserted = await client.query(
        `INSERT INTO clients (name, slug, is_default, created_at, updated_at)
         VALUES ($1, $2, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
         RETURNING id`,
        [name, slug]
      );
      return Number(inserted.rows[0].id);
    }
    suffix += 1;
  }

  const timestamp = Date.now();
  const fallbackName = `Primary Client ${timestamp}`;
  const fallbackSlug = `primary-client-${timestamp}`;
  const inserted = await client.query(
    `INSERT INTO clients (name, slug, is_default, created_at, updated_at)
     VALUES ($1, $2, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
     RETURNING id`,
    [fallbackName, fallbackSlug]
  );
  return Number(inserted.rows[0].id);
}

async function ensureDefaultClient(client) {
  const existingDefault = await client.query(
    'SELECT id FROM clients WHERE is_default = 1 ORDER BY id ASC LIMIT 1'
  );
  if (existingDefault.rowCount > 0) {
    return Number(existingDefault.rows[0].id);
  }

  const existingAny = await client.query('SELECT id FROM clients ORDER BY id ASC LIMIT 1');
  if (existingAny.rowCount > 0) {
    const chosenId = Number(existingAny.rows[0].id);
    await client.query('UPDATE clients SET is_default = CASE WHEN id = $1 THEN 1 ELSE 0 END', [chosenId]);
    return chosenId;
  }

  const inserted = await client.query(
    `INSERT INTO clients (name, slug, is_default, created_at, updated_at)
     VALUES ($1, $2, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
     RETURNING id`,
    ['Primary Client', 'primary-client']
  );
  return Number(inserted.rows[0].id);
}

async function ensureClientScopeColumns(client, defaultClientId) {
  await client.query('UPDATE templates SET client_id = $1 WHERE client_id IS NULL', [defaultClientId]);
  await client.query('UPDATE assets SET client_id = $1 WHERE client_id IS NULL', [defaultClientId]);
  await client.query('UPDATE generations SET client_id = $1 WHERE client_id IS NULL', [defaultClientId]);
}

async function removeLegacyClients(client) {
  const result = await client.query('SELECT id, name, slug, is_default FROM clients ORDER BY id ASC');
  const clients = result.rows;
  const legacyClients = clients.filter((row) => isLegacyClient(row));

  if (legacyClients.length === 0) {
    return ensureDefaultClient(client);
  }

  const nonLegacyClients = clients.filter((row) => !isLegacyClient(row));
  let targetClientId = null;
  if (nonLegacyClients.length > 0) {
    const preferred = nonLegacyClients.find((row) => Number(row.is_default) === 1) || nonLegacyClients[0];
    targetClientId = Number(preferred.id);
  } else {
    targetClientId = await createPrimaryClient(client);
  }

  for (const legacyClient of legacyClients) {
    const fromClientId = Number(legacyClient.id);
    if (fromClientId === targetClientId) continue;

    await client.query('UPDATE templates SET client_id = $1 WHERE client_id = $2', [targetClientId, fromClientId]);
    await client.query('UPDATE assets SET client_id = $1 WHERE client_id = $2', [targetClientId, fromClientId]);
    await client.query('UPDATE generations SET client_id = $1 WHERE client_id = $2', [targetClientId, fromClientId]);

    await client.query(
      `INSERT INTO campaign_tags (client_id, tag_type, tag_value, created_at)
       SELECT $1, tag_type, tag_value, created_at
       FROM campaign_tags
       WHERE client_id = $2
       ON CONFLICT (client_id, tag_type, tag_value) DO NOTHING`,
      [targetClientId, fromClientId]
    );
    await client.query('DELETE FROM campaign_tags WHERE client_id = $1', [fromClientId]);

    const targetBrandKit = await client.query('SELECT id FROM brand_kits WHERE client_id = $1 LIMIT 1', [targetClientId]);
    if (targetBrandKit.rowCount > 0) {
      await client.query('DELETE FROM brand_kits WHERE client_id = $1', [fromClientId]);
    } else {
      await client.query('UPDATE brand_kits SET client_id = $1 WHERE client_id = $2', [targetClientId, fromClientId]);
    }

    await client.query('DELETE FROM clients WHERE id = $1', [fromClientId]);
  }

  await client.query('UPDATE clients SET is_default = CASE WHEN id = $1 THEN 1 ELSE 0 END', [targetClientId]);
  return targetClientId;
}

async function ensureBrandKitRecord(client, clientId) {
  await client.query(
    `INSERT INTO brand_kits (client_id, created_at, updated_at)
     VALUES ($1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
     ON CONFLICT (client_id) DO NOTHING`,
    [clientId]
  );
}

async function removeLegacyStarterTemplates(client) {
  const starterSeedPaths = LEGACY_TEMPLATE_SEED
    .map((row) => String(row.image_path || '').trim())
    .filter(Boolean);

  if (!starterSeedPaths.length) {
    return;
  }

  const placeholders = starterSeedPaths.map((_, index) => `$${index + 1}`).join(', ');
  await client.query(
    `DELETE FROM templates
     WHERE source_type = 'starter'
       AND image_path IN (${placeholders})`,
    starterSeedPaths
  );
}

async function initDb() {
  const pool = new Pool(buildPoolConfig());
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    await initializeSchema(client);
    let defaultClientId = await ensureDefaultClient(client);
    await ensureClientScopeColumns(client, defaultClientId);
    defaultClientId = await removeLegacyClients(client);
    await ensureBrandKitRecord(client, defaultClientId);
    await removeLegacyStarterTemplates(client);

    await client.query('COMMIT');
    return pool;
  } catch (error) {
    await client.query('ROLLBACK');
    await pool.end().catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

module.exports = {
  initDb,
  LEGACY_TEMPLATE_SEED
};
