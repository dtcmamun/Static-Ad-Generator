# Replit Starter Guide for Node.js Projects

A universal guide for getting any Node.js/Express project running on Replit. Use this as a reference for every project you deploy.

---

## Table of Contents

1. [Importing a Project](#importing-a-project)
2. [The Replit Agent Prompt](#the-replit-agent-prompt)
3. [Port Configuration](#port-configuration)
4. [Environment Variables & Secrets](#environment-variables--secrets)
5. [Replit Configuration Files](#replit-configuration-files)
6. [Dependencies & DevDependencies](#dependencies--devdependencies)
7. [Database Setup](#database-setup)
8. [Frontend Build & Static Files](#frontend-build--static-files)
9. [Creating a Clean ZIP for Sharing](#creating-a-clean-zip-for-sharing)
10. [Common Pitfalls](#common-pitfalls)

---

## Importing a Project

### From ZIP File

1. Go to [replit.com](https://replit.com)
2. Click **Create Repl**
3. Select **Import from ZIP**
4. Upload your ZIP file (must be under 100 MB — exclude `node_modules/`)
5. Wait for the import to complete

### From GitHub

1. Go to [replit.com](https://replit.com)
2. Click **Create Repl**
3. Select **Import from GitHub**
4. Paste the repository URL
5. Wait for the import to complete

---

## The Replit Agent Prompt

When you import a pre-built project, the Replit agent will try to "help" set it up. It often goes off-script — installing things you don't need, changing your database, creating workflows, or trying to run dev mode.

**Best practice:** Give the agent an explicit prompt that tells it exactly what to do and what NOT to do.

### Template Prompt

Adapt this for your project:

> This is a fully built application. Do not modify any source code, do not change the file structure, and do not create new files.
>
> Run these commands exactly, in this order:
>
> 1. `npm install --include=dev`
> 2. [any setup commands, e.g. database migrations]
> 3. [build command, e.g. `npx vite build`]
> 4. [start command, e.g. `node server/index.js`]
>
> Do not modify any files. Do not install Node.js separately. Do not create any workflows. The app runs in production mode on port 5000. There is only one server process.
>
> Do not modify the .replit file. It is already configured correctly.

### Key Phrases That Keep the Agent on Track

- **"Do not modify any source code"** — Prevents it from rewriting your files
- **"Do not create any workflows"** — Prevents it from overriding your `.replit` run command
- **"Do not install Node.js separately"** — It's already available in the Nix environment
- **"Do not use Postgres"** — If your app uses SQLite, say so explicitly or the agent may try to set up Postgres
- **"Run these commands exactly, in this order"** — Gives it a specific checklist instead of letting it improvise

---

## Port Configuration

**Replit maps port 5000 to the external preview URL.** Your app must listen on port 5000.

```javascript
const PORT = process.env.PORT || 5000;
```

In your `.replit` file:

```toml
[env]
PORT = "5000"

[[ports]]
localPort = 5000
externalPort = 80
```

**Never hardcode a different port.** If your app listens on 3000, 8080, or anything else, the Replit preview will be blank.

Note: On macOS, port 5000 is used by AirPlay. For local development, use a different fallback (e.g., 5001) and let the `PORT` env var override it on Replit.

---

## Environment Variables & Secrets

### How It Works

- **Locally:** Use a `.env` file with `dotenv`
- **On Replit:** Use the **Secrets panel** (lock icon in sidebar). Replit injects these at runtime — no `.env` file needed.
- **In `.replit` file:** The `[env]` section sets non-secret variables (PORT, NODE_ENV, DATABASE_URL)

### Best Practices

- Never commit `.env` to git — add it to `.gitignore`
- Always include a `.env.example` with placeholder values so others know what keys are needed
- Put non-secret config (PORT, NODE_ENV) in the `.replit` `[env]` section
- Put actual secrets (API keys) in the Secrets panel only
- Use descriptive variable names: `STRIPE_SECRET_KEY` not `KEY1`

### Example `.env.example`

```
# API Keys (add these in the Replit Secrets panel)
API_KEY=your_api_key_here
DATABASE_URL=file:./dev.db

# App Config (already set in .replit file)
PORT=5000
NODE_ENV=production
```

---

## Replit Configuration Files

### .replit

Controls how Replit runs your app:

```toml
run = "npm install && npm run build && npm start"
entrypoint = "server/index.js"
modules = ["nodejs-20"]

[nix]
channel = "stable-24_05"

[deployment]
build = ["sh", "-c", "npm install && npm run build"]
run = ["sh", "-c", "npm start"]
deploymentTarget = "cloudrun"

[env]
PORT = "5000"
NODE_ENV = "production"

[[ports]]
localPort = 5000
externalPort = 80
```

**Key settings:**
- `run` — Command executed when you click Run (chain with `&&` for sequential steps)
- `entrypoint` — File Replit opens by default in the editor
- `[env]` — Non-secret environment variables
- `[[ports]]` — Maps internal port to external port 80
- `[deployment]` — Separate build/run commands for production deploys

### replit.nix

Declares system-level dependencies:

```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs_20
    pkgs.nodePackages.npm
  ];
}
```

Add more if your project needs them:

```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs_20
    pkgs.nodePackages.npm
    pkgs.sqlite       # If using SQLite CLI
    pkgs.imagemagick  # If processing images
  ];
}
```

---

## Dependencies & DevDependencies

### The Problem

Replit sometimes runs `npm install` in production mode, which **skips devDependencies**. This means tools like `vite`, `tailwindcss`, `concurrently`, and `prisma` won't be installed if they're listed under `devDependencies`.

### The Fix

Use `--include=dev` to force install everything:

```bash
npm install --include=dev
```

Or in your `.replit` run command:

```toml
run = "npm install --include=dev && npm run build && npm start"
```

### When This Matters

If your build step uses any tool from `devDependencies` (which is common — Vite, TypeScript, Prisma CLI, etc.), you need `--include=dev`. Otherwise the build will fail with `command not found`.

---

## Database Setup

### SQLite (Recommended for Self-Contained Apps)

SQLite stores everything in a single file. No external database server needed.

```toml
[env]
DATABASE_URL = "file:./dev.db"
```

**Important:** Tell the Replit agent explicitly that your app uses SQLite. Otherwise it may try to set up Postgres, which Replit offers as a built-in service. If you don't need Postgres, say so clearly in your agent prompt.

### Prisma with SQLite

If using Prisma ORM, your run command should include:

```bash
npx prisma generate && npx prisma db push
```

- `prisma generate` — Creates the client library from your schema
- `prisma db push` — Creates/syncs the database file

### External Databases

For production apps that need a hosted database:
- **Supabase** (PostgreSQL)
- **PlanetScale** (MySQL)
- **MongoDB Atlas** (NoSQL)
- **Neon** (PostgreSQL)

Store connection strings in the Secrets panel.

---

## Frontend Build & Static Files

### Production Mode (Recommended)

For apps with a build step (React, Vue, etc.), build the frontend and serve it as static files from Express:

```javascript
// In your Express server
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('dist'));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'dist', 'index.html'));
  });
}
```

Your `.replit` run command handles the build:

```toml
run = "npm install --include=dev && npm run build && npm start"
```

**This means one server, one port.** Express serves both the API and the frontend. Do not try to run a separate dev server (Vite, webpack-dev-server) on Replit — it complicates port mapping and confuses the agent.

### Simple HTML (No Build Step)

For simpler apps, serve HTML directly:

```javascript
app.use(express.static('public'));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});
```

---

## Creating a Clean ZIP for Sharing

When sharing a project (with students, clients, etc.), exclude files that shouldn't be distributed:

```bash
zip -r my-project.zip . -x "node_modules/*" ".git/*" ".env" ".DS_Store" "*.db" "dist/*"
```

**What to exclude:**
- `node_modules/` — Recreated via `npm install` (this is the big one — often 100MB+)
- `.git/` — Git history not needed for deployment
- `.env` — Contains your actual API keys/secrets
- `.DS_Store` — macOS junk files
- `*.db` — Local database files (recreated on first run)
- `dist/` — Build output (recreated via build command)

**What to include:**
- `package.json` and `package-lock.json` — Needed to install exact dependency versions
- `.env.example` — Documents what secrets are needed
- `.replit` and `replit.nix` — Replit configuration
- All source code

**Important:** Files must be at the ZIP root level, not nested in a subfolder.

---

## Common Pitfalls

### 1. Blank Preview Window
**Symptom:** App is running but Replit preview shows nothing
**Fix:** Make sure your app listens on port 5000. Check the `.replit` `[[ports]]` section.

### 2. `command not found` During Build
**Symptom:** `vite: command not found`, `tsc: command not found`, etc.
**Fix:** Run `npm install --include=dev`. Replit skips devDependencies in production mode.

### 3. Replit Agent Tries to Use Postgres
**Symptom:** Agent starts investigating database setup, mentions Postgres
**Fix:** Explicitly tell the agent what database your app uses. "This app uses SQLite, not Postgres."

### 4. Replit Agent Creates Workflows
**Symptom:** Agent creates its own run configuration instead of using your `.replit` file
**Fix:** Include "Do not create any workflows" and "Do not modify the .replit file" in your prompt.

### 5. Replit Agent Runs Dev Mode
**Symptom:** Agent tries to run `concurrently`, starts two servers, or runs `vite` as a dev server
**Fix:** Tell it: "The app runs in production mode. One server, one port."

### 6. ZIP File Too Large (Over 100 MB)
**Symptom:** Replit rejects the upload
**Fix:** You almost certainly included `node_modules/`. Exclude it when zipping — Replit will run `npm install` to recreate it.

### 7. Secrets Not Available
**Symptom:** `API_KEY environment variable is not set`
**Fix:** Add secrets via the lock icon in the Replit sidebar. They're injected at runtime.

### 8. ZIP Has Nested Folder
**Symptom:** Replit shows a single folder instead of your project files
**Fix:** Run the `zip` command from inside the project directory so files are at the root level.

---

## Quick Checklist

Before importing to Replit, verify:

- [ ] `.replit` file exists with correct `run` command, port 5000, and `[env]` section
- [ ] `replit.nix` file exists with Node.js declared
- [ ] `.env.example` documents all required environment variables
- [ ] `.gitignore` excludes `node_modules/`, `.env`, database files
- [ ] `package.json` has a `start` script that runs the server
- [ ] Server listens on `process.env.PORT || 5000`
- [ ] Production mode serves frontend as static files (if applicable)
- [ ] ZIP excludes `node_modules/`, `.env`, `.git/`, build output
