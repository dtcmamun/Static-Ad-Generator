require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const multer = require('multer');
const { fal } = require('@fal-ai/client');
const { initDb } = require('./database/init');

const app = express();
const PORT = Math.max(1, Math.min(Number(process.env.PORT) || 8080, 65535));
const HOST = String(process.env.HOST || '0.0.0.0').trim() || '0.0.0.0';
let db = null;

const SQL_PLACEHOLDER_CACHE = new Map();
const TYPOGRAPHY_STYLE_CACHE = new Map();

function toPgSql(sql) {
  const key = String(sql || '');
  if (SQL_PLACEHOLDER_CACHE.has(key)) {
    return SQL_PLACEHOLDER_CACHE.get(key);
  }

  let index = 0;
  const converted = key.replace(/\?/g, () => `$${++index}`);
  SQL_PLACEHOLDER_CACHE.set(key, converted);
  return converted;
}

async function executeQuery(sql, params = [], runner = null) {
  const client = runner || db;
  if (!client) {
    throw new Error('Database connection is not initialized.');
  }
  return client.query(toPgSql(sql), params);
}

async function dbGet(sql, params = [], runner = null) {
  const result = await executeQuery(sql, params, runner);
  return result.rows[0] || null;
}

async function dbAll(sql, params = [], runner = null) {
  const result = await executeQuery(sql, params, runner);
  return result.rows;
}

async function withDbTransaction(callback) {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const result = await callback({
      query: (sql, params = []) => executeQuery(sql, params, client),
      get: (sql, params = []) => dbGet(sql, params, client),
      all: (sql, params = []) => dbAll(sql, params, client)
    });
    await client.query('COMMIT');
    return result;
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_rollbackError) {
      // Preserve original error when rollback also fails.
    }
    throw error;
  } finally {
    client.release();
  }
}

const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOADS_DIR = path.join(PUBLIC_DIR, 'uploads');
const TEMPLATE_DIR = path.join(PUBLIC_DIR, 'uploads', 'templates');
const BRAND_DIR = path.join(PUBLIC_DIR, 'uploads', 'brand');
const ASSET_DIR = path.join(PUBLIC_DIR, 'uploads', 'assets');
const GENERATED_DIR = path.join(PUBLIC_DIR, 'uploads', 'generated');

const MAX_UPLOAD_SIZE = 15 * 1024 * 1024;
const IMAGE_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/svg+xml']);
const ASSET_CATEGORY_OPTIONS = ['Product Image', 'Packaging', 'Lifestyle', 'Logo', 'Other'];

let falConfigured = false;

function ensureDirectories() {
  [PUBLIC_DIR, TEMPLATE_DIR, BRAND_DIR, ASSET_DIR, GENERATED_DIR].forEach((dir) => {
    fs.mkdirSync(dir, { recursive: true });
  });
}

function slugify(input) {
  return String(input || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50);
}

function createStorage(dirPath) {
  return multer.diskStorage({
    destination(_req, _file, cb) {
      cb(null, dirPath);
    },
    filename(_req, file, cb) {
      const ext = path.extname(file.originalname || '').toLowerCase() || '.png';
      const base = slugify(path.basename(file.originalname || 'image', ext)) || 'image';
      cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${base}${ext}`);
    }
  });
}

function imageFileFilter(_req, file, cb) {
  if (IMAGE_MIME_TYPES.has(file.mimetype)) {
    cb(null, true);
    return;
  }
  cb(new Error('Only image files are allowed.'));
}

const brandUpload = multer({
  storage: createStorage(BRAND_DIR),
  fileFilter: imageFileFilter,
  limits: { fileSize: MAX_UPLOAD_SIZE }
});

const assetUpload = multer({
  storage: createStorage(ASSET_DIR),
  fileFilter: imageFileFilter,
  limits: { fileSize: MAX_UPLOAD_SIZE }
});

const templateUpload = multer({
  storage: createStorage(TEMPLATE_DIR),
  fileFilter: imageFileFilter,
  limits: { fileSize: MAX_UPLOAD_SIZE }
});

function configureFal() {
  const falKey = normalizeWhitespace(process.env.FAL_KEY || '');
  if (!falKey) {
    throw new Error('FAL_KEY is not set. Add it in Replit Secrets or .env.');
  }
  const normalized = falKey.toLowerCase();
  if (
    normalized === 'your_fal_api_key_here'
    || normalized === 'replace_with_fal_key'
    || normalized === 'replace_me'
    || normalized === 'changeme'
  ) {
    throw new Error('FAL_KEY is still a placeholder. Add your real FAL API key in .env or Secrets.');
  }
  if (!falConfigured) {
    fal.config({ credentials: falKey });
    falConfigured = true;
  }
}

function getGeminiApiKey() {
  return normalizeWhitespace(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '');
}

function getGeminiModel() {
  return normalizeWhitespace(process.env.GEMINI_MODEL || 'gemini-2.5-pro') || 'gemini-2.5-pro';
}

function normalizeGeminiUserParts(userPrompt, userContent) {
  if (Array.isArray(userContent)) {
    return userContent
      .map((part) => {
        if (!part) return null;

        // Compatibility with prior planner content-block shape.
        if (part.type === 'text' && typeof part.text === 'string') {
          return { text: part.text };
        }
        if (part.type === 'image' && part.source && part.source.type === 'base64') {
          return {
            inline_data: {
              mime_type: part.source.media_type,
              data: part.source.data
            }
          };
        }

        // Gemini part passthrough (sanitized to known keys only).
        if (typeof part.text === 'string') {
          return { text: part.text };
        }
        if (part.inline_data && typeof part.inline_data === 'object') {
          return {
            inline_data: {
              mime_type: part.inline_data.mime_type,
              data: part.inline_data.data
            }
          };
        }
        if (part.file_data && typeof part.file_data === 'object') {
          return {
            file_data: {
              mime_type: part.file_data.mime_type,
              file_uri: part.file_data.file_uri
            }
          };
        }

        return null;
      })
      .filter(Boolean);
  }

  return [{ text: String(userPrompt || '') }];
}

async function callGeminiGenerateContent({
  system,
  userPrompt,
  userContent,
  maxTokens = 2000,
  temperature = 0.2,
  expectJson = true,
  thinkingBudget = null
}) {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not set.');
  }

  const model = getGeminiModel();
  const maxOutputTokens = Math.max(256, Math.min(Number(maxTokens) || 2000, 4096));
  const safeTemperature = Math.max(0, Math.min(Number(temperature) || 0.2, 1));
  const hasThinkingBudget = thinkingBudget !== null && thinkingBudget !== undefined && String(thinkingBudget).trim() !== '';
  const safeThinkingBudget = hasThinkingBudget && Number.isFinite(Number(thinkingBudget))
    ? Math.max(128, Math.min(Math.round(Number(thinkingBudget)), 32768))
    : null;
  const userParts = normalizeGeminiUserParts(userPrompt, userContent);
  if (!userParts.length) {
    throw new Error('Gemini request has no user content.');
  }

  const payload = {
    contents: [
      {
        role: 'user',
        parts: userParts
      }
    ],
    generationConfig: {
      temperature: safeTemperature,
      maxOutputTokens
    }
  };

  if (expectJson) {
    payload.generationConfig.responseMimeType = 'application/json';
  }
  if (safeThinkingBudget !== null) {
    payload.generationConfig.thinkingConfig = { thinkingBudget: safeThinkingBudget };
  }

  const cleanSystem = normalizeWhitespace(system || '');
  if (cleanSystem) {
    payload.system_instruction = {
      parts: [{ text: cleanSystem }]
    };
  }

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'x-goog-api-key': apiKey,
      'content-type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const rawText = await response.text();
  let parsedResponse = null;
  try {
    parsedResponse = JSON.parse(rawText);
  } catch (_error) {
    parsedResponse = null;
  }

  if (!response.ok) {
    const details = normalizeWhitespace(
      parsedResponse && parsedResponse.error
        ? `${parsedResponse.error.status || 'error'}: ${parsedResponse.error.message || ''}`
        : rawText
    );
    throw new Error(`Gemini request failed (${response.status}). ${details}`.trim());
  }

  const candidate = Array.isArray(parsedResponse && parsedResponse.candidates)
    ? parsedResponse.candidates[0]
    : null;
  const text = candidate && candidate.content && Array.isArray(candidate.content.parts)
    ? candidate.content.parts
      .map((part) => (part && typeof part.text === 'string' ? part.text : ''))
      .join('\n')
      .trim()
    : '';

  return {
    id: normalizeWhitespace(parsedResponse && parsedResponse.responseId),
    model,
    usage: parsedResponse && parsedResponse.usageMetadata ? parsedResponse.usageMetadata : null,
    text
  };
}

function getExtensionFromContentType(contentType) {
  const ct = (contentType || '').toLowerCase();
  if (ct.includes('png')) return '.png';
  if (ct.includes('jpeg') || ct.includes('jpg')) return '.jpg';
  if (ct.includes('webp')) return '.webp';
  if (ct.includes('svg')) return '.svg';
  return '.png';
}

function getMimeTypeFromPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.png') return 'image/png';
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg';
  if (ext === '.webp') return 'image/webp';
  if (ext === '.svg') return 'image/svg+xml';
  return 'application/octet-stream';
}

function toGeminiInlineDataPart(absPath) {
  const mimeType = getMimeTypeFromPath(absPath);
  if (!mimeType.startsWith('image/')) {
    throw new Error('Gemini vision input must be an image file.');
  }
  const bytes = fs.readFileSync(absPath);
  return {
    inline_data: {
      mime_type: mimeType,
      data: bytes.toString('base64')
    }
  };
}

async function getDefaultClientId() {
  const row = await dbGet('SELECT id FROM clients WHERE is_default = 1 ORDER BY id ASC LIMIT 1')
    || await dbGet('SELECT id FROM clients ORDER BY id ASC LIMIT 1');
  return row ? Number(row.id) : null;
}

async function getClientById(clientId) {
  return await dbGet('SELECT * FROM clients WHERE id = ?', [clientId]) || null;
}

async function getRequestClientId(req) {
  const rawFromQuery = req && req.query ? req.query.clientId : undefined;
  const rawFromBody = req && req.body ? req.body.clientId : undefined;
  const raw = rawFromQuery !== undefined ? rawFromQuery : rawFromBody;
  const parsed = Number(raw);
  if (Number.isFinite(parsed) && parsed > 0) {
    const client = await getClientById(parsed);
    if (client) return Number(client.id);
  }
  return await getDefaultClientId();
}

async function getBrandKit(clientId) {
  return await dbGet('SELECT * FROM brand_kits WHERE client_id = ?', [clientId]) || null;
}

async function ensureBrandKitRecord(clientId, runner = null) {
  await executeQuery(`
    INSERT INTO brand_kits (client_id, created_at, updated_at)
    VALUES (?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    ON CONFLICT(client_id) DO NOTHING
  `, [clientId], runner);
}

function normalizeClientName(value) {
  return normalizeWhitespace(value).slice(0, 80);
}

async function listClients() {
  const clients = await dbAll(
    'SELECT id, name, slug, is_default, created_at, updated_at FROM clients ORDER BY is_default DESC, name ASC'
  );
  return clients.map((client) => ({
    ...client,
    is_default: Boolean(client.is_default)
  }));
}

function isUploadPublicPath(publicPath) {
  return typeof publicPath === 'string' && publicPath.startsWith('/uploads/');
}

function collectGeneratedImagePaths(generatedImagesRaw) {
  const images = parseGeneratedImages(generatedImagesRaw);
  return images
    .map((item) => getGeneratedImagePath(item))
    .filter((item) => isUploadPublicPath(item));
}

async function collectClientUploadPaths(clientId) {
  const [templates, assets, brandRows, generations] = await Promise.all([
    dbAll('SELECT image_path FROM templates WHERE client_id = ?', [clientId]),
    dbAll('SELECT file_path FROM assets WHERE client_id = ?', [clientId]),
    dbAll('SELECT logo_dark_path, logo_light_path FROM brand_kits WHERE client_id = ?', [clientId]),
    dbAll('SELECT reference_image_path, product_image_path, generated_images FROM generations WHERE client_id = ?', [clientId])
  ]);

  const paths = new Set();

  templates.forEach((row) => {
    const value = normalizeWhitespace(row && row.image_path ? row.image_path : '');
    if (isUploadPublicPath(value)) paths.add(value);
  });

  assets.forEach((row) => {
    const value = normalizeWhitespace(row && row.file_path ? row.file_path : '');
    if (isUploadPublicPath(value)) paths.add(value);
  });

  brandRows.forEach((row) => {
    const dark = normalizeWhitespace(row && row.logo_dark_path ? row.logo_dark_path : '');
    const light = normalizeWhitespace(row && row.logo_light_path ? row.logo_light_path : '');
    if (isUploadPublicPath(dark)) paths.add(dark);
    if (isUploadPublicPath(light)) paths.add(light);
  });

  generations.forEach((row) => {
    const reference = normalizeWhitespace(row && row.reference_image_path ? row.reference_image_path : '');
    const product = normalizeWhitespace(row && row.product_image_path ? row.product_image_path : '');
    if (isUploadPublicPath(reference)) paths.add(reference);
    if (isUploadPublicPath(product)) paths.add(product);
    collectGeneratedImagePaths(row && row.generated_images ? row.generated_images : '').forEach((pathValue) => paths.add(pathValue));
  });

  return Array.from(paths);
}

async function countUploadPathReferences(publicPath) {
  if (!isUploadPublicPath(publicPath)) {
    return Number.POSITIVE_INFINITY;
  }

  const escapedLikeValue = publicPath.replace(/[%_]/g, '\\$&');
  const likePattern = `%${escapedLikeValue}%`;

  const [templateCount, assetCount, brandLogoCount, generationRefCount, generationProductCount, generationImageCount] = await Promise.all([
    dbGet('SELECT COUNT(*) AS count FROM templates WHERE image_path = ?', [publicPath]),
    dbGet('SELECT COUNT(*) AS count FROM assets WHERE file_path = ?', [publicPath]),
    dbGet('SELECT COUNT(*) AS count FROM brand_kits WHERE logo_dark_path = ? OR logo_light_path = ?', [publicPath, publicPath]),
    dbGet('SELECT COUNT(*) AS count FROM generations WHERE reference_image_path = ?', [publicPath]),
    dbGet('SELECT COUNT(*) AS count FROM generations WHERE product_image_path = ?', [publicPath]),
    dbGet("SELECT COUNT(*) AS count FROM generations WHERE generated_images LIKE ? ESCAPE '\\\\'", [likePattern])
  ]);

  return (
    Number(templateCount && templateCount.count || 0)
    + Number(assetCount && assetCount.count || 0)
    + Number(brandLogoCount && brandLogoCount.count || 0)
    + Number(generationRefCount && generationRefCount.count || 0)
    + Number(generationProductCount && generationProductCount.count || 0)
    + Number(generationImageCount && generationImageCount.count || 0)
  );
}

async function deleteUploadFileIfUnreferenced(publicPath) {
  if (!isUploadPublicPath(publicPath)) return false;
  try {
    const referenceCount = await countUploadPathReferences(publicPath);
    if (referenceCount > 0) return false;
    const absolutePath = path.resolve(PUBLIC_DIR, publicPath.replace(/^\/+/, ''));
    if (absolutePath.startsWith(PUBLIC_DIR) && fs.existsSync(absolutePath)) {
      fs.unlinkSync(absolutePath);
      return true;
    }
  } catch (_error) {
    // Keep caller flow successful even if storage cleanup fails.
  }
  return false;
}

function toPublicPath(absPath) {
  const relative = path.relative(PUBLIC_DIR, absPath).replace(/\\/g, '/');
  return `/${relative}`;
}

function resolveUploadPath(publicPath) {
  if (typeof publicPath !== 'string' || !publicPath.startsWith('/uploads/')) {
    throw new Error('Invalid image path.');
  }

  const relativePath = publicPath.replace(/^\/+/, '');
  const absolutePath = path.resolve(PUBLIC_DIR, relativePath);

  if (!absolutePath.startsWith(PUBLIC_DIR)) {
    throw new Error('Invalid image path.');
  }

  if (!fs.existsSync(absolutePath)) {
    throw new Error(`File not found: ${publicPath}`);
  }

  return absolutePath;
}

function parseGeneratedImages(rawValue) {
  if (!rawValue) return [];
  try {
    const parsed = JSON.parse(rawValue);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_error) {
    return [];
  }
}

function getGeneratedImagePath(image) {
  if (typeof image === 'string') {
    return normalizeWhitespace(image);
  }

  if (image && typeof image === 'object') {
    return normalizeWhitespace(image.image_path || image.path || '');
  }

  return '';
}

function normalizeWhitespace(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeResearchText(value, maxLength = 50000) {
  const normalized = String(value == null ? '' : value)
    .replace(/\r\n?/g, '\n')
    .trim();
  return normalized.slice(0, Math.max(0, Number(maxLength) || 50000));
}

function normalizeTagValue(value) {
  return normalizeWhitespace(String(value || '').replace(/,+/g, ' ')).slice(0, 80);
}

function normalizeProfilePairArray(value, max = 20) {
  const source = Array.isArray(value) ? value : [];
  const seen = new Set();
  const pairs = [];
  source.forEach((entry) => {
    if (!entry || typeof entry !== 'object') return;
    const persona = normalizeTagValue(
      entry.persona || entry.avatar || entry.avatar_name || entry.name || ''
    );
    const angle = normalizeTagValue(
      entry.angle || entry.concept || entry.concept_name || ''
    );
    if (!persona || !angle) return;
    const key = `${persona.toLowerCase()}::${angle.toLowerCase()}`;
    if (seen.has(key)) return;
    seen.add(key);
    pairs.push({
      persona,
      angle,
      pain_point: normalizeWhitespace(entry.pain_point || entry.painPoint || '').slice(0, 220),
      emotion: normalizeWhitespace(entry.emotion || '').slice(0, 120)
    });
  });
  return pairs.slice(0, Math.max(1, Number(max) || 20));
}

function isFrameworkLikeConceptLabel(value) {
  const normalized = normalizeWhitespace(value || '').toLowerCase();
  if (!normalized) return false;
  const exactFrameworks = [
    'problem/solution',
    'problem solution',
    'social proof',
    'comparison',
    'checklist',
    'before/after',
    'before after',
    'testimonial',
    'urgency',
    'offer urgency',
    'benefit stack',
    'objection handling',
    'product showcase',
    'feature education',
    'pas',
    'problem-agitation-solution',
    'us vs them',
    'split screen',
    'grid layout',
    'full image overlay',
    'diagrammatic'
  ];
  if (exactFrameworks.includes(normalized)) return true;
  if (/^(problem|solution|format|framework|layout|template)$/i.test(normalized)) return true;
  return false;
}

function mapFrameworkLabelToConceptTheme(value) {
  const normalized = normalizeTagValue(value);
  const lower = normalized.toLowerCase();
  if (!lower) return '';

  if (/problem[\s/-]*solution|pas|problem-agitation-solution|problem agitation solution/.test(lower)) {
    return 'Solve daily challenges';
  }
  if (/social proof|testimonial|reviews?|trust|rating|community proof/.test(lower)) {
    return 'Parent-approved results';
  }
  if (/comparison|us vs them|versus|\bvs\b|before[\s/-]*after|old way|new way/.test(lower)) {
    return 'Better than alternatives';
  }
  if (/checklist|feature education|education|benefit stack|objection handling/.test(lower)) {
    return 'Clear everyday benefits';
  }
  if (/offer urgency|urgency|limited|countdown|deadline/.test(lower)) {
    return 'Best-value right now';
  }
  if (/product showcase|product hero|hero shot/.test(lower)) {
    return 'Product-first clarity';
  }

  return normalized;
}

function filterGeneratedConceptLabels(candidates, seedConcepts = []) {
  const seedSet = new Set((Array.isArray(seedConcepts) ? seedConcepts : [])
    .map((item) => mapFrameworkLabelToConceptTheme(item).toLowerCase())
    .filter(Boolean));
  const mappedCandidates = (Array.isArray(candidates) ? candidates : [])
    .map((candidate) => mapFrameworkLabelToConceptTheme(candidate))
    .filter(Boolean);

  return uniqueByNormalized(mappedCandidates, 24).filter((candidate) => {
    const key = normalizeTagValue(candidate).toLowerCase();
    if (!key) return false;
    if (seedSet.has(key)) return true;
    return !isFrameworkLikeConceptLabel(candidate);
  });
}

function normalizeTone(value) {
  const normalized = normalizeWhitespace(value || '');
  if (!normalized) return '';
  const allowed = new Set(['Bold', 'Minimal', 'Playful', 'Clinical', 'Editorial', 'Lifestyle']);
  if (allowed.has(normalized)) return normalized;
  return '';
}

function uniqueByNormalized(list, max = 16) {
  const seen = new Set();
  const output = [];
  (Array.isArray(list) ? list : []).forEach((item) => {
    const normalized = normalizeTagValue(item);
    const key = normalized.toLowerCase();
    if (!normalized || seen.has(key)) return;
    seen.add(key);
    output.push(normalized);
  });
  return output.slice(0, max);
}

function enforceStaticAdLanguage(text) {
  let value = normalizeWhitespace(text);
  if (!value) return value;

  value = value
    .replace(/\bcreate (an?|the)?\s*(short[-\s]?form\s+)?video\b/ig, 'Create a static ad')
    .replace(/\b(short[-\s]?form\s+)?video(s)?\b/ig, 'static ad')
    .replace(/\bvideo ad(s)?\b/ig, 'static ad')
    .replace(/\bfootage\b/ig, 'imagery')
    .replace(/\bclip(s)?\b/ig, 'image')
    .replace(/\bscene(s)?\b/ig, 'layout')
    .replace(/\bvoice[\s-]?over\b/ig, 'text overlay')
    .replace(/\bb-?roll\b/ig, 'supporting visual elements');

  return normalizeWhitespace(value);
}

function extractPromptField(text, labelRegex) {
  const source = String(text || '');
  const match = source.match(labelRegex);
  return normalizeWhitespace(match && match[1] ? match[1] : '');
}

function stripPromptField(text, labelRegex) {
  return String(text || '').replace(labelRegex, '').trim();
}

function parseCampaignItemPromptMeta(itemPrompt) {
  let remaining = String(itemPrompt || '');
  const avatarName = extractPromptField(remaining, /avatar:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Create a static Meta ad for avatar:\s*[^.\n]+\.\s*/i);

  const conceptName = extractPromptField(remaining, /Concept angle:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Concept angle:\s*[^.\n]+\.\s*/i);

  const toneHint = extractPromptField(remaining, /Tone:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Tone:\s*[^.\n]+\.\s*/i);

  const offerCta = extractPromptField(remaining, /Offer\/CTA to include:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Offer\/CTA to include:\s*[^.\n]+\.\s*/i);

  const campaignGoal = extractPromptField(remaining, /Campaign goal:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Campaign goal:\s*[^.\n]+\.\s*/i);

  const variationCycle = extractPromptField(remaining, /Variation cycle:\s*([^.\n]+)/i);
  remaining = stripPromptField(remaining, /Variation cycle:\s*[^.\n]+\.\s*/i);

  remaining = stripPromptField(remaining, /Use winning ad references for layout\/style cues only\.\s*/ig);
  remaining = stripPromptField(remaining, /Use product identity image as the primary source\. If winning references are provided, use them for style cues only\.\s*/ig);
  remaining = stripPromptField(remaining, /Use product identity image as the primary source for product visuals\.\s*/ig);
  remaining = stripPromptField(remaining, /Keep product identity consistent with the selected product image when provided\.\s*/ig);
  remaining = stripPromptField(remaining, /This must be a static image ad, not a video\.\s*/ig);
  remaining = stripPromptField(remaining, /Do not duplicate the source ad\.\s*/ig);
  remaining = stripPromptField(remaining, /Use a structurally distinct composition from other outputs in this batch\.\s*/ig);
  remaining = stripPromptField(remaining, /Change paneling, headline placement, and callout architecture as needed for this concept\.\s*/ig);
  remaining = stripPromptField(remaining, /Use the reference ad only as a style\/quality guide, not a fixed template\.\s*/ig);
  remaining = stripPromptField(remaining, /No fixed style template is provided for this item\. Build a fresh composition from strategy cues\.\s*/ig);

  return {
    avatarName,
    conceptName,
    toneHint,
    offerCta,
    campaignGoal,
    variationCycle,
    cleanDirection: normalizeWhitespace(remaining)
  };
}

function extractGenerationConcept(prompt) {
  const text = String(prompt || '');
  const match = text.match(/Concept angle:\s*([^.\n]+)/i)
    || text.match(/using\s+([^.\n]+?)\s+framing/i)
    || text.match(/Angle:\s*([^.\n]+)/i)
    || text.match(/\bangle\s*=\s*([^;\n]+)/i);
  if (!match) return '';
  return normalizeWhitespace(String(match[1] || '').replace(/['"]/g, ''));
}

function extractGenerationAvatar(prompt) {
  const text = String(prompt || '');
  const match = text.match(/avatar:\s*([^.\n]+)/i)
    || text.match(/\bavatar\s*=\s*([^;\n]+)/i);
  if (!match) return '';
  return normalizeWhitespace(String(match[1] || '').replace(/['"]/g, ''));
}

function chunkArray(values, chunkSize = 12) {
  const source = Array.isArray(values) ? values : [];
  const size = Math.max(1, Math.min(Number(chunkSize) || 12, 30));
  const chunks = [];
  for (let index = 0; index < source.length; index += size) {
    chunks.push(source.slice(index, index + size));
  }
  return chunks;
}

function sanitizePlannerText(value, maxLength = 220) {
  return normalizeWhitespace(String(value || '')).slice(0, Math.max(0, maxLength));
}

function normalizePlannerSpec(raw, fallback) {
  const source = raw && typeof raw === 'object' ? raw : {};
  return {
    item_id: sanitizePlannerText(source.item_id || fallback.item_id || '', 120),
    copy_framework: sanitizePlannerText(
      source.copy_framework || source.framework || source.copyFramework || fallback.copy_framework || 'Problem/Solution',
      80
    ),
    visual_format: sanitizePlannerText(
      source.visual_format || source.layout_format || source.visualFormat || fallback.visual_format || 'Product Showcase',
      80
    ),
    product_integration: sanitizePlannerText(
      source.product_integration || source.integration || source.productIntegration || fallback.product_integration || 'Hero shot',
      80
    ),
    scene_direction: sanitizePlannerText(
      source.scene_direction || source.scene || source.art_direction || source.sceneDirection || fallback.scene_direction || '',
      260
    ),
    headline_hint: sanitizePlannerText(
      source.headline_hint || source.headline || source.headlineHint || fallback.headline_hint || '',
      90
    ),
    supporting_line_hint: sanitizePlannerText(
      source.supporting_line_hint || source.support_line || source.subheadline || source.supportingLineHint || fallback.supporting_line_hint || '',
      120
    ),
    cta_hint: sanitizePlannerText(
      source.cta_hint || source.cta || source.ctaHint || fallback.cta_hint || '',
      40
    ),
    why_distinct: sanitizePlannerText(
      source.why_distinct || source.reason || source.whyDistinct || fallback.why_distinct || '',
      160
    )
  };
}

async function planCreativeSpecsWithGemini({
  plannerItems,
  generationStrategy,
  hasStyleReference,
  brandKit
}) {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    return {
      enabled: false,
      model: null,
      specsByItemId: {},
      requestCount: 0,
      reason: 'GEMINI_API_KEY is not set.'
    };
  }

  const items = Array.isArray(plannerItems)
    ? plannerItems
      .map((item) => ({
        item_id: sanitizePlannerText(item && item.item_id, 120),
        avatar_name: sanitizePlannerText(item && item.avatar_name, 80),
        concept_name: sanitizePlannerText(item && item.concept_name, 80),
        seed_prompt: sanitizePlannerText(item && item.seed_prompt, 320),
        tone: sanitizePlannerText(item && item.tone, 60),
        campaign_goal: sanitizePlannerText(item && item.campaign_goal, 80),
        offer_cta: sanitizePlannerText(item && item.offer_cta, 60)
      }))
      .filter((item) => item.item_id)
    : [];

  if (items.length === 0) {
    return {
      enabled: true,
      model: getGeminiModel(),
      specsByItemId: {},
      requestCount: 0,
      reason: 'No items to plan.'
    };
  }

  const chunks = chunkArray(
    items,
    Number(process.env.GEMINI_PROMPT_PLANNER_BATCH_SIZE) || 12
  );
  const allSpecs = {};
  let requestCount = 0;
  let resolvedModel = '';

  for (const chunk of chunks) {
    const systemPrompt = [
      'You are a senior direct-response Meta static ads strategist.',
      'Generate execution-ready creative specs for each input item.',
      'Do not copy competitor names, claims, or literal text from references.',
      'Return JSON only.'
    ].join(' ');

    const brandTypography = getBrandKitTypographyDirection(brandKit);
    const brandContext = brandKit
      ? {
        brand_name: sanitizePlannerText(brandKit.brand_name, 80),
        brand_description: sanitizePlannerText(brandKit.brand_description, 240),
        typography_family: sanitizePlannerText(brandTypography.family, 80),
        typography_style: sanitizePlannerText(brandTypography.style, 80),
        color_primary: sanitizePlannerText(brandKit.color_primary, 16),
        color_secondary: sanitizePlannerText(brandKit.color_secondary, 16),
        color_accent: sanitizePlannerText(brandKit.color_accent, 16)
      }
      : null;

    const userPrompt = [
      'Create one structured creative spec per item for Meta static ads.',
      `Workflow mode: ${generationStrategy}.`,
      `Winning style reference present: ${hasStyleReference ? 'yes' : 'no'}.`,
      'Each item must be meaningfully distinct and conversion-focused.',
      'Use these copy frameworks when relevant: Problem/Solution, Comparison, Checklist, Benefit Headline, Curiosity Question, Urgency Scenario, Social Proof, Quantitative Data.',
      'Use these visual formats when relevant: Full Image Overlay, Split Screen, Checklist/Infographic, Grid Layout, Product Showcase, Diagrammatic.',
      'Product integration should be one of: Hero shot, In-use, Part of kit, Feature close-up.',
      'For each item, output concise fields and avoid long copy blocks.',
      'Headline hint should be <= 7 words. Supporting line hint <= 10 words. CTA hint <= 3 words.',
      'If no CTA is needed, cta_hint can be an empty string.',
      'Return ONLY valid JSON with exactly this shape:',
      '{"items":[{"item_id":"string","copy_framework":"string","visual_format":"string","product_integration":"string","scene_direction":"string","headline_hint":"string","supporting_line_hint":"string","cta_hint":"string","why_distinct":"string"}]}',
      brandContext ? `Brand context: ${JSON.stringify(brandContext)}` : 'Brand context: none provided.',
      `Input items JSON: ${JSON.stringify(chunk)}`
    ].join('\n');

    const response = await callGeminiGenerateContent({
      system: systemPrompt,
      userPrompt,
      maxTokens: 2400,
      temperature: 0.25
    });
    requestCount += 1;
    resolvedModel = response.model || resolvedModel;

    const parsed = extractJsonObjectFromText(response.text);
    const rawItems = Array.isArray(parsed && parsed.items) ? parsed.items : [];
    for (let index = 0; index < chunk.length; index += 1) {
      const fallback = {
        item_id: chunk[index].item_id,
        copy_framework: 'Problem/Solution',
        visual_format: 'Product Showcase',
        product_integration: 'Hero shot',
        scene_direction: chunk[index].seed_prompt,
        headline_hint: '',
        supporting_line_hint: '',
        cta_hint: chunk[index].offer_cta || '',
        why_distinct: ''
      };
      const raw = rawItems[index] || rawItems.find((candidate) => {
        const candidateId = sanitizePlannerText(candidate && candidate.item_id, 120);
        return candidateId && candidateId === fallback.item_id;
      });
      const normalized = normalizePlannerSpec(raw, fallback);
      const resolvedItemId = normalized.item_id || fallback.item_id;
      if (!resolvedItemId) continue;
      allSpecs[resolvedItemId] = normalized;
    }
  }

  return {
    enabled: true,
    model: resolvedModel || getGeminiModel(),
    specsByItemId: allSpecs,
    requestCount,
    reason: ''
  };
}

function truncatePromptContext(value, maxLength = 1200) {
  return normalizeWhitespace(value || '').slice(0, Math.max(0, Number(maxLength) || 1200));
}

function findBestBrandIntelligenceMatch(items, avatarName = '', conceptName = '') {
  const source = Array.isArray(items) ? items : [];
  if (!source.length) return null;

  const avatar = normalizeTagValue(avatarName || '').toLowerCase();
  const concept = normalizeTagValue(conceptName || '').toLowerCase();
  let best = null;
  let bestScore = -1;

  source.forEach((item) => {
    if (!item || typeof item !== 'object') return;
    const persona = normalizeTagValue(item.persona || '').toLowerCase();
    const angle = normalizeTagValue(item.angle || '').toLowerCase();
    if (!persona && !angle) return;

    let score = 0;
    if (avatar && persona) {
      if (persona === avatar) score += 8;
      else if (persona.includes(avatar) || avatar.includes(persona)) score += 4;
    }
    if (concept && angle) {
      if (angle === concept) score += 8;
      else if (angle.includes(concept) || concept.includes(angle)) score += 4;
    }
    if (score > bestScore) {
      best = item;
      bestScore = score;
    }
  });

  return bestScore > 0 ? best : null;
}

function buildBrandIntelligenceSnapshot(items, selectedProfile = null, maxItems = 6) {
  const source = Array.isArray(items) ? items : [];
  const selected = selectedProfile && typeof selectedProfile === 'object'
    ? selectedProfile
    : null;
  const selectedKey = selected
    ? `${normalizeTagValue(selected.persona)}::${normalizeTagValue(selected.angle)}`.toLowerCase()
    : '';

  const rows = [];
  const seen = new Set();

  const pushItem = (item) => {
    if (!item || typeof item !== 'object') return;
    const persona = truncatePromptContext(item.persona || '', 80);
    const pain = truncatePromptContext(item.pain_point || '', 140);
    const angle = truncatePromptContext(item.angle || '', 140);
    const visual = truncatePromptContext(item.visual_direction || '', 140);
    const emotion = truncatePromptContext(item.emotion || '', 80);
    const key = `${persona}::${angle}`.toLowerCase();
    if (!persona || !angle || !key || seen.has(key)) return;
    seen.add(key);
    rows.push(
      [
        `Persona: ${persona}`,
        pain ? `Pain: ${pain}` : '',
        `Angle: ${angle}`,
        visual ? `Visual: ${visual}` : '',
        emotion ? `Emotion: ${emotion}` : ''
      ].filter(Boolean).join(' | ')
    );
  };

  if (selected) {
    pushItem(selected);
  }

  source.forEach((item) => {
    if (rows.length >= maxItems) return;
    const key = `${normalizeTagValue(item && item.persona)}::${normalizeTagValue(item && item.angle)}`.toLowerCase();
    if (selectedKey && key === selectedKey) return;
    pushItem(item);
  });

  return rows.slice(0, maxItems).map((row, index) => `${index + 1}. ${row}`).join('\n');
}

function normalizeReferenceBlueprint(parsed) {
  if (!parsed || typeof parsed !== 'object') return null;
  const source = parsed.blueprint && typeof parsed.blueprint === 'object'
    ? parsed.blueprint
    : parsed;

  const textElements = Array.isArray(source.text_elements)
    ? source.text_elements
      .map((item) => {
        if (!item) return null;
        if (typeof item === 'string') {
          const text = truncatePromptContext(item, 240);
          return text ? { content: text, style: '' } : null;
        }
        if (typeof item === 'object') {
          const content = truncatePromptContext(item.content || item.text || item.copy || '', 240);
          const style = truncatePromptContext(item.style || item.format || item.position || '', 240);
          if (!content && !style) return null;
          return { content, style };
        }
        return null;
      })
      .filter(Boolean)
      .slice(0, 8)
    : [];

  const visualMotifs = Array.isArray(source.visual_motifs)
    ? source.visual_motifs.map((item) => truncatePromptContext(item, 120)).filter(Boolean).slice(0, 10)
    : [];

  const normalized = {
    subject: truncatePromptContext(source.subject || source.product_subject || '', 320),
    background: truncatePromptContext(source.background || source.background_layout || '', 320),
    layout_structure: truncatePromptContext(source.layout_structure || source.layout || source.composition || '', 320),
    typography: truncatePromptContext(source.typography || source.typography_style || '', 240),
    visual_motifs: visualMotifs,
    text_elements: textElements,
    branding: truncatePromptContext(source.branding || source.brand || '', 240),
    style: truncatePromptContext(source.style || source.style_notes || source.aesthetic || '', 320)
  };

  const hasSignal = Boolean(
    normalized.subject
    || normalized.background
    || normalized.layout_structure
    || normalized.typography
    || normalized.style
    || normalized.text_elements.length
    || normalized.visual_motifs.length
  );
  return hasSignal ? normalized : null;
}

function containsSplitComparisonLanguage(value) {
  return /(split[-\s]*screen|split[-\s]*layout|left\s+side|right\s+side|side[-\s]*by[-\s]*side|before[-\s]*after|old\s+way|new\s+way|comparison\s+(panel|layout|table)|\bus\s*vs\s*them\b|\bvs\b|\bversus\b)/i
    .test(String(value || ''));
}

function detectComposedPromptQualityIssues(prompt, { referenceLayoutCategory = 'unknown' } = {}) {
  const text = normalizeWhitespace(prompt || '');
  const issues = [];
  if (!text) {
    issues.push('empty');
    return issues;
  }
  if (text.length < 120) {
    issues.push('too_short');
  }
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length < 35) {
    issues.push('underspecified');
  }
  if (/^\s*[-*]\s+/m.test(text) || /(first|second|third)\s+bullet/i.test(text)) {
    issues.push('bullet_fragment');
  }
  if (/\btypography requirement\s*:/i.test(text)) {
    issues.push('directive_label_leak');
  }
  if (/^\s*\{/.test(text) || /"prompt"\s*:/.test(text)) {
    issues.push('json_wrapper_leak');
  }
  const doubleQuoteCount = (text.match(/"/g) || []).length;
  if (doubleQuoteCount % 2 === 1) {
    issues.push('unbalanced_quotes');
  }
  const isSplitReference = referenceLayoutCategory === 'split_or_comparison';
  if (!isSplitReference && containsSplitComparisonLanguage(text)) {
    issues.push('off_family_layout');
  }
  if (!/(product|packaging|pouch|image\s*2|background|layout|composition|headline|callout|hero|cta)/i.test(text)) {
    issues.push('missing_execution_detail');
  }
  return issues;
}

function detectReferenceLayoutCategory(referenceBlueprint) {
  const blueprint = referenceBlueprint && typeof referenceBlueprint === 'object'
    ? referenceBlueprint
    : null;
  if (!blueprint) return 'unknown';

  const joined = [
    blueprint.layout_structure || '',
    blueprint.background || '',
    blueprint.style || '',
    Array.isArray(blueprint.visual_motifs) ? blueprint.visual_motifs.join(' ') : '',
    Array.isArray(blueprint.text_elements)
      ? blueprint.text_elements
        .map((item) => {
          if (!item) return '';
          if (typeof item === 'string') return item;
          if (typeof item === 'object') return `${item.content || ''} ${item.style || ''}`.trim();
          return '';
        })
        .join(' ')
      : ''
  ].join(' ').toLowerCase();

  const hasSplit = containsSplitComparisonLanguage(joined);
  if (hasSplit) return 'split_or_comparison';

  const hasGrid = /(grid|collage|tiles?|mosaic|multi[-\s]*panel|four[-\s]*up|3x|2x)/.test(joined);
  if (hasGrid) return 'grid';

  const hasCenteredHero = /(center|centered|hero|single product|single subject|callout|radial|around product)/.test(joined);
  if (hasCenteredHero) return 'single_hero';

  return 'single_canvas';
}

function buildReferenceLayoutGuardLine(referenceBlueprint) {
  const layoutCategory = detectReferenceLayoutCategory(referenceBlueprint);
  if (layoutCategory === 'split_or_comparison') {
    return 'Reference layout family lock: keep a split/comparison structure consistent with the reference (do not switch to unrelated single-hero or collage layouts).';
  }
  if (layoutCategory === 'grid') {
    return 'Reference layout family lock: keep a grid/collage style consistent with the reference (do not switch to split-screen comparison or unrelated single-hero layouts).';
  }
  if (layoutCategory === 'single_hero' || layoutCategory === 'single_canvas') {
    return 'Reference layout family lock: keep a single-canvas hero composition consistent with the reference; do not introduce split-screen, before/after, old-way/new-way, side-by-side comparison, or multi-panel grids.';
  }
  return 'Reference layout family lock: preserve the reference’s core composition family; avoid introducing unrelated panel structures.';
}

function normalizeComposedPromptValue(value) {
  if (typeof value === 'string') {
    return enforceStaticAdLanguage(normalizeWhitespace(value));
  }
  if (!value || typeof value !== 'object') {
    return '';
  }

  const lines = [];
  const subject = truncatePromptContext(value.subject || value.product || value.product_subject || '', 320);
  const background = truncatePromptContext(value.background || value.background_layout || '', 320);
  const layout = truncatePromptContext(value.layout_structure || value.layout || value.composition || '', 320);
  const style = truncatePromptContext(value.style || value.style_notes || value.aesthetic || '', 320);
  const branding = truncatePromptContext(value.branding || value.brand || '', 220);
  const typography = truncatePromptContext(value.typography || value.typography_style || '', 220);

  if (subject) lines.push(`Subject: ${subject}.`);
  if (background) lines.push(`Background: ${background}.`);
  if (layout) lines.push(`Layout: ${layout}.`);

  const textElements = Array.isArray(value.text_elements) ? value.text_elements : [];
  if (textElements.length > 0) {
    const textSummary = textElements
      .map((item) => {
        if (!item) return '';
        if (typeof item === 'string') return truncatePromptContext(item, 200);
        if (typeof item === 'object') {
          const content = truncatePromptContext(item.content || item.text || '', 160);
          const itemStyle = truncatePromptContext(item.style || item.format || item.position || '', 160);
          if (content && itemStyle) return `"${content}" (${itemStyle})`;
          if (content) return `"${content}"`;
          return itemStyle;
        }
        return '';
      })
      .filter(Boolean)
      .join('; ');
    if (textSummary) {
      lines.push(`Text elements: ${textSummary}.`);
    }
  }

  if (branding) lines.push(`Branding: ${branding}.`);
  if (typography) lines.push(`Typography: ${typography}.`);
  if (style) lines.push(`Style: ${style}.`);

  return enforceStaticAdLanguage(normalizeWhitespace(lines.join(' ')));
}

async function extractReferenceBlueprintWithGemini(referenceAbsPath) {
  if (!getGeminiApiKey()) {
    return {
      enabled: false,
      model: null,
      blueprint: null,
      reason: 'GEMINI_API_KEY is not set.'
    };
  }
  if (!referenceAbsPath) {
    return {
      enabled: false,
      model: null,
      blueprint: null,
      reason: 'referenceAbsPath is required.'
    };
  }

  const response = await callGeminiGenerateContent({
    system: [
      'You are a visual ad deconstruction assistant.',
      'Analyze a single static ad image and extract a reusable style/layout blueprint.',
      'Return JSON only.'
    ].join(' '),
    userContent: [
      toGeminiInlineDataPart(referenceAbsPath),
      {
        type: 'text',
        text: [
          'Extract a JSON blueprint describing this ad\'s visual structure.',
          'Focus on layout/composition/style and text placement patterns.',
          'Do not infer medical/legal claims. Keep output descriptive and concise.',
          'Return ONLY valid JSON with exactly this shape:',
          '{"subject":"string","background":"string","layout_structure":"string","typography":"string","visual_motifs":["string"],"text_elements":[{"content":"string","style":"string"}],"branding":"string","style":"string"}'
        ].join('\n')
      }
    ],
    maxTokens: 1800,
    temperature: 0.2
  });

  const parsed = extractJsonObjectFromText(response.text);
  const blueprint = normalizeReferenceBlueprint(parsed);
  if (!blueprint) {
    return {
      enabled: false,
      model: response.model || null,
      blueprint: null,
      reason: 'Gemini returned no usable reference blueprint.'
    };
  }

  return {
    enabled: true,
    model: response.model || getGeminiModel(),
    blueprint,
    reason: ''
  };
}

async function composeNanoBananaPromptWithGemini({
  productAbsPath,
  referenceAbsPath,
  referenceBlueprint = null,
  avatarName = '',
  conceptName = '',
  toneHint = '',
  offerCta = '',
  campaignGoal = '',
  variationCycle = '',
  extraInstructions = '',
  brandKit = null,
  selectedProfile = null,
  brandProfiles = [],
  researchText = ''
}) {
  if (!getGeminiApiKey()) {
    return {
      enabled: false,
      model: null,
      prompt: '',
      rationale: '',
      reason: 'GEMINI_API_KEY is not set.'
    };
  }

  if (!productAbsPath || !referenceAbsPath) {
    return {
      enabled: false,
      model: null,
      prompt: '',
      rationale: '',
      reason: 'Both productAbsPath and referenceAbsPath are required.'
    };
  }

  const matchedProfile = selectedProfile || findBestBrandIntelligenceMatch(brandProfiles, avatarName, conceptName);
  const brandContext = truncatePromptContext(buildBrandContextLine(brandKit), 900);
  const safeExtraInstructions = truncatePromptContext(extraInstructions, 500);
  const safeReferenceBlueprint = normalizeReferenceBlueprint(referenceBlueprint);
  const referenceBlueprintJson = safeReferenceBlueprint
    ? truncatePromptContext(JSON.stringify(safeReferenceBlueprint), 1800)
    : '';
  const referenceLayoutGuardLine = safeReferenceBlueprint
    ? buildReferenceLayoutGuardLine(safeReferenceBlueprint)
    : '';
  const referenceLayoutCategory = detectReferenceLayoutCategory(safeReferenceBlueprint);
  const referenceIsSingleCanvas = referenceLayoutCategory === 'single_hero' || referenceLayoutCategory === 'single_canvas';
  const referenceIsSplitComparison = referenceLayoutCategory === 'split_or_comparison';
  const referenceLayoutHardRule = referenceIsSingleCanvas
    ? 'Hard layout lock: reference is single-canvas. Forbidden structures: split-screen, before/after, old-way/new-way, side-by-side comparison, multi-panel grids.'
    : (referenceIsSplitComparison
      ? 'Hard layout lock: reference is split/comparison. Keep split/comparison panel structure; do not collapse into single-canvas hero.'
      : '');
  const typographyDirection = getBrandKitTypographyDirection(brandKit);
  const typographyStyle = normalizeWhitespace(typographyDirection.style || '');
  const typographyFamily = normalizeWhitespace(typographyDirection.family || '');

  const system = [
    'You are a senior direct-response prompt writer for fal-ai/nano-banana-pro/edit.',
    'Your job is to write one production-ready prompt for a static Facebook/Meta ad edit task.',
    'Image 1 is style/layout reference only; Image 2 is product identity only.',
    'Recreate style from Image 1 while preserving product identity from Image 2.',
    'Preserve the reference layout family exactly; never change panel structure from the reference.',
    'Avatar/angle/pain-point cues are secondary and must not override the reference layout family.',
    'Messaging must align with brand context, audience pain points, and the specified angle.',
    'Never copy competitor text, claims, or brand names from the reference ad.',
    'Return only the final executable prompt text. Do not return JSON.'
  ].join(' ');

  const userText = [
    'Task: Write the creative-direction prompt that will be sent to fal-ai/nano-banana-pro/edit.',
    'Image ordering in this request:',
    '- First image = winning/competitor ad reference (must control style/layout only).',
    '- Second image = product identity image (must control product identity).',
    'Success criteria:',
    '1) Use the product identity exactly from Image 2.',
    '2) Align messaging and visual angle with customer pain points and brand context.',
    'Constraint priority (highest to lowest): product identity + reference layout family > brand kit > avatar/angle cues.',
    `Reference layout category: ${referenceLayoutCategory}.`,
    referenceLayoutHardRule,
    'Translate avatar/angle primarily through messaging, props, callouts, iconography, and scene details, not by changing panel structure.',
    avatarName ? `Primary avatar: ${truncatePromptContext(avatarName, 90)}.` : '',
    conceptName ? `Primary angle: ${truncatePromptContext(conceptName, 180)}.` : '',
    toneHint ? `Tone hint: ${truncatePromptContext(toneHint, 80)}.` : '',
    campaignGoal ? `Campaign goal: ${truncatePromptContext(campaignGoal, 120)}.` : '',
    offerCta ? `Offer / CTA guidance: ${truncatePromptContext(offerCta, 80)}.` : '',
    variationCycle ? `Variation cycle context: ${truncatePromptContext(variationCycle, 80)}.` : '',
    safeExtraInstructions ? `Additional user instructions (scene/messaging only; do not alter layout family): ${safeExtraInstructions}.` : '',
    matchedProfile && matchedProfile.pain_point
      ? `Key pain point to solve: ${truncatePromptContext(matchedProfile.pain_point, 200)}.`
      : '',
    matchedProfile && matchedProfile.emotion
      ? `Target emotion: ${truncatePromptContext(matchedProfile.emotion, 120)}.`
      : '',
    typographyStyle
      ? `Typography style lock for any overlay text: use a ${truncatePromptContext(typographyStyle, 80)} style${typographyFamily ? ` (brand font reference: ${truncatePromptContext(typographyFamily, 80)})` : ''}.`
      : '',
    referenceBlueprintJson ? `Reference style blueprint (from Gemini vision):\n${referenceBlueprintJson}` : '',
    referenceLayoutGuardLine ? `Reference layout guard:\n${referenceLayoutGuardLine}` : '',
    brandContext ? `Brand context:\n${brandContext}` : '',
    'Output rules:',
    '- Return one prompt only.',
    '- Keep it concrete and model-executable.',
    '- Use plain prose only (no markdown bullets, no numbered lists, no field labels like "First bullet").',
    '- Keep copy lines concise and executable for an image model.',
    '- Never print internal metadata labels.',
    '- Return plain text only (no JSON, no code fences, no prefacing commentary).'
  ].filter(Boolean).join('\n');

  const response = await callGeminiGenerateContent({
    system,
    userContent: [
      toGeminiInlineDataPart(referenceAbsPath),
      toGeminiInlineDataPart(productAbsPath),
      { type: 'text', text: userText }
    ],
    maxTokens: 2600,
    temperature: 0.1
  });

  let aiPrompt = normalizeComposedPromptValue(extractPlainTextFromModelResponse(response.text || ''));
  if (!aiPrompt) {
    return {
      enabled: false,
      model: response.model || null,
      prompt: '',
      rationale: '',
      reason: 'Gemini returned no usable prompt.'
    };
  }

  if (typographyStyle) {
    const promptLower = aiPrompt.toLowerCase();
    const styleMentioned = promptLower.includes(typographyStyle.toLowerCase());
    if (!styleMentioned) {
      aiPrompt = normalizeWhitespace([
        aiPrompt,
        `Use a ${typographyStyle} style for any added headline/overlay/CTA text${typographyFamily ? ` (brand font reference: ${typographyFamily})` : ''}.`
      ].join('\n'));
    }
  }

  const qualityIssues = detectComposedPromptQualityIssues(aiPrompt, {
    referenceLayoutCategory
  });
  if (qualityIssues.length > 0) {
    try {
      const rewriteResponse = await callGeminiGenerateContent({
        system: [
          'You rewrite ad-generation prompts for strict quality and layout compliance.',
          'Do not change product-identity rules or brand context.',
          'Return only one clean executable prompt in plain text.'
        ].join(' '),
        userPrompt: [
          `Reference layout category: ${referenceLayoutCategory}.`,
          referenceLayoutHardRule,
          `Fix these issues in the prompt: ${qualityIssues.join(', ')}.`,
          'Rewrite the prompt so it keeps the same brand/angle intent while strictly preserving the reference layout family.',
          'Do not use markdown bullets, numbered lists, field labels ("First bullet"), or JSON wrappers in the rewritten prompt text.',
          'Do not use split-screen, before/after, old-way/new-way, side-by-side, vs/versus, or comparison-table structures unless the reference itself is split/comparison.',
          'Return one clean executable prompt in plain prose (about 120-260 words).',
          `Original model output:\n${response.text || ''}`,
          `Current extracted prompt:\n${aiPrompt || ''}`
        ].filter(Boolean).join('\n'),
        maxTokens: 2200,
        temperature: 0.1
      });
      const rewrittenPrompt = normalizeComposedPromptValue(extractPlainTextFromModelResponse(rewriteResponse.text || ''));
      const rewrittenIssues = detectComposedPromptQualityIssues(rewrittenPrompt, {
        referenceLayoutCategory
      });
      if (rewrittenPrompt && rewrittenIssues.length === 0) {
        aiPrompt = rewrittenPrompt;
      } else {
        console.warn('[prompt.compose] rewrite pass could not resolve prompt quality issues', {
          qualityIssues,
          rewrittenIssues
        });
      }
    } catch (rewriteError) {
      console.warn('[prompt.compose] rewrite pass failed', {
        error: normalizeWhitespace(rewriteError && rewriteError.message) || 'Unknown rewrite error.'
      });
    }
  }

  return {
    enabled: true,
    model: response.model || getGeminiModel(),
    prompt: aiPrompt,
    rationale: '',
    reason: ''
  };
}

function normalizeGeneratedImageEntries(generatedImages, fallbackConceptName = '', fallbackAvatarName = '') {
  const fallbackConcept = normalizeWhitespace(fallbackConceptName || '');
  const fallbackAvatar = normalizeWhitespace(fallbackAvatarName || '');
  const source = Array.isArray(generatedImages) ? generatedImages : [];
  const entries = [];

  for (const image of source) {
    const imagePath = getGeneratedImagePath(image);
    if (!imagePath) continue;

    const objectImage = image && typeof image === 'object' ? image : null;
    const conceptName = normalizeWhitespace(
      (objectImage && (objectImage.concept_name || objectImage.concept)) || fallbackConcept
    );
    const avatarName = normalizeWhitespace(
      (objectImage && (objectImage.avatar_name || objectImage.avatar)) || fallbackAvatar
    );

    if (!conceptName && !avatarName && typeof image === 'string') {
      entries.push(imagePath);
      continue;
    }

    const taggedEntry = { image_path: imagePath };
    if (conceptName) taggedEntry.concept_name = conceptName;
    if (avatarName) taggedEntry.avatar_name = avatarName;
    entries.push(taggedEntry);
  }

  return entries;
}

function buildTwoImageEditPrompt(userPrompt) {
  const cleanPrompt = String(userPrompt || '').trim();
  return [
    'Create a static advertisement by combining two input images.',
    'Image role rules (strict):',
    '- Image 1 controls ONLY visual style: layout structure, composition, text placement hierarchy, and design aesthetic.',
    '- Image 2 is the ONLY product identity source.',
    '- Keep the final product faithful to Image 2 (shape, color, materials, branding, proportions).',
    '- CRITICAL PRODUCT FIDELITY: preserve Image 2 packaging identity exactly (brand mark, label style, package silhouette, and core colorway).',
    '- Never invent, substitute, recolor, or reformat the product package from Image 2.',
    '- Treat Image 2 as a locked product cutout/asset: preserve package front artwork, logo text, and silhouette exactly.',
    '- Preserve package hue/saturation/brightness from Image 2; do not tint or recolor any package region.',
    '- Keep package text/logo from Image 2 legible and unchanged. Do not rewrite labels.',
    '- Never copy/recreate product identity from Image 1.',
    '- Never copy text content, claims, product category, or messaging from Image 1.',
    '- Apply color/style guidance only to non-product elements (backgrounds, overlays, props, CTA surfaces).',
    '- If any instruction conflicts with these rules, these rules win.',
    '- If text policy says no text, render zero added text overlays (only packaging/logo text already on Image 2 is allowed).',
    '- Composition guard: fill the full canvas. Do not place a small ad/poster inside a larger background frame.',
    '- Avoid thick outer borders, oversized safe margins, or inset matte framing around the main creative.',
    'Creative direction:',
    cleanPrompt
  ].join('\n');
}

function parseGenerationRow(row) {
  if (!row) return row;
  const conceptName = normalizeWhitespace(row.concept_name || '') || extractGenerationConcept(row.prompt || '');
  const avatarName = normalizeWhitespace(row.avatar_name || '') || extractGenerationAvatar(row.prompt || '');
  const taggedImages = normalizeGeneratedImageEntries(
    parseGeneratedImages(row.generated_images),
    conceptName,
    avatarName
  );

  return {
    ...row,
    concept_name: conceptName,
    avatar_name: avatarName,
    used_brand_kit: Boolean(row.used_brand_kit),
    generated_images: taggedImages
  };
}

function parseTemplateTags(rawValue) {
  if (!rawValue) return [];

  if (Array.isArray(rawValue)) {
    return rawValue
      .map((item) => String(item).trim())
      .filter(Boolean)
      .slice(0, 12);
  }

  if (typeof rawValue === 'string') {
    const trimmed = rawValue.trim();
    if (!trimmed) return [];

    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed
          .map((item) => String(item).trim())
          .filter(Boolean)
          .slice(0, 12);
      }
    } catch (_error) {
      // Fallback to comma-separated parsing.
    }

    return trimmed
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean)
      .slice(0, 12);
  }

  return [];
}

function parseBoolean(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value > 0;
  const lowered = String(value).toLowerCase().trim();
  return ['1', 'true', 'yes', 'on'].includes(lowered);
}

function normalizeCampaignGenerationStrategy(value) {
  const normalized = normalizeWhitespace(value || '').toLowerCase();
  if (normalized === 'product_exploration' || normalized === 'product-led' || normalized === 'product') {
    return 'product_exploration';
  }
  return 'winner_iteration';
}

function parseTemplateRow(row) {
  if (!row) return null;
  return {
    ...row,
    is_favorite: Boolean(row.is_favorite),
    tags: parseTemplateTags(row.tags)
  };
}

function normalizeBrandIntelligenceField(value, maxLength = 180) {
  return normalizeWhitespace(String(value || '')).slice(0, Math.max(0, Number(maxLength) || 180));
}

function parseBrandIntelligenceRow(row) {
  if (!row) return null;
  return {
    id: Number(row.id),
    client_id: Number(row.client_id),
    persona: normalizeBrandIntelligenceField(row.persona, 120),
    pain_point: normalizeBrandIntelligenceField(row.pain_point, 220),
    angle: normalizeBrandIntelligenceField(row.angle, 220),
    visual_direction: normalizeBrandIntelligenceField(row.visual_direction, 220),
    emotion: normalizeBrandIntelligenceField(row.emotion, 120),
    copy_hook: normalizeBrandIntelligenceField(row.copy_hook, 220),
    source: normalizeBrandIntelligenceField(row.source, 40) || 'ai',
    created_at: row.created_at
  };
}

function normalizeBrandIntelligenceResponse(parsed, rawOutput, targetCount = 10) {
  const requested = Math.max(3, Math.min(Number(targetCount) || 10, 20));
  const extractFirstArray = (value) => {
    if (!value) return null;
    if (Array.isArray(value)) return value;
    if (typeof value !== 'object') return null;
    const nestedCandidates = [
      value.items,
      value.personas,
      value.angles,
      value.results,
      value.output,
      value.data,
      value.response,
      value.result
    ];
    for (const candidate of nestedCandidates) {
      if (Array.isArray(candidate)) return candidate;
      if (candidate && typeof candidate === 'object') {
        const deep = extractFirstArray(candidate);
        if (Array.isArray(deep)) return deep;
      }
    }
    return null;
  };

  const rawItems = extractFirstArray(parsed);

  const items = [];
  const seen = new Set();
  let modelItemsCount = 0;
  const pushUnique = (candidate, source = 'model') => {
    if (!candidate) return;
    const persona = normalizeBrandIntelligenceField(
      candidate.persona
      || candidate.avatar
      || candidate.avatar_name
      || candidate.audience
      || candidate.customer
      || candidate.segment
      || candidate.name
      || '',
      120
    );
    const painPoint = normalizeBrandIntelligenceField(
      candidate.pain_point
      || candidate.painPoint
      || candidate.problem
      || candidate.pain
      || candidate.challenge
      || candidate.blocker
      || '',
      220
    );
    const angle = normalizeBrandIntelligenceField(
      candidate.angle
      || candidate.message_angle
      || candidate.hook
      || candidate.concept
      || candidate.framework
      || candidate.positioning
      || '',
      220
    );
    const visualDirection = normalizeBrandIntelligenceField(
      candidate.visual_direction
      || candidate.visual
      || candidate.scene
      || candidate.visualDirection
      || candidate.art_direction
      || candidate.direction
      || '',
      220
    );
    const emotion = normalizeBrandIntelligenceField(
      candidate.emotion
      || candidate.feeling
      || candidate.emotional_trigger
      || candidate.tone
      || '',
      120
    );
    const copyHook = normalizeBrandIntelligenceField(
      candidate.copy_hook
      || candidate.copyHook
      || candidate.headline
      || candidate.hook_line
      || '',
      220
    );

    if (!persona || !angle) return;
    const key = `${persona}::${angle}`.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    items.push({
      persona,
      pain_point: painPoint || 'Needs a clearer, easier way to solve their problem.',
      angle,
      visual_direction: visualDirection || 'Lifestyle-forward product scene with clear benefit hierarchy.',
      emotion: emotion || 'Relief and confidence.',
      copy_hook: copyHook || ''
    });
    if (source === 'model') modelItemsCount += 1;
  };

  if (Array.isArray(rawItems)) {
    rawItems.forEach((entry) => {
      if (!entry) return;
      if (typeof entry === 'string') {
        pushUnique({ persona: entry, angle: entry });
        return;
      }
      if (Array.isArray(entry)) {
        pushUnique({
          persona: entry[0],
          pain_point: entry[1],
          angle: entry[2],
          visual_direction: entry[3],
          emotion: entry[4],
          copy_hook: entry[5]
        });
        return;
      }
      if (typeof entry === 'object') {
        pushUnique(entry);
      }
    });
  }

  const fallbackItems = [
    ['Skeptical first-time buyer', 'Worried the product will not work as promised.', 'Proof-first outcome framing with a believable result.', 'Before/after comparison panel with product in center.', 'Trust and relief.', '“I did not expect this to work, but it did.”'],
    ['Price-conscious shopper', 'Needs confidence that value matches price.', 'Cost-to-value framing with stacked benefits.', 'Value stack card with clean pricing emphasis.', 'Confidence and smart decision-making.', '“More value per order, less waste.”'],
    ['Busy professional', 'No time for complex routines.', 'Fast routine simplification and convenience.', 'Morning routine scene with minimal clutter.', 'Calm and control.', '“Works in under 60 seconds.”'],
    ['Results-focused optimizer', 'Wants measurable improvement quickly.', 'Performance/outcome framing with clear milestones.', 'Progress timeline with punchy metric callouts.', 'Momentum and certainty.', '“Visible change you can track.”'],
    ['Ingredient-conscious buyer', 'Distrusts unclear ingredient claims.', 'Clean-ingredient transparency angle.', 'Ingredient callout layout with product close-up.', 'Safety and clarity.', '“Know exactly what you are using.”'],
    ['Existing-category user', 'Current solution causes irritation or friction.', 'Replace-the-old-way comparison framing.', 'Split-screen “old way vs new way” format.', 'Relief and empowerment.', '“Switch once, feel the difference daily.”'],
    ['Social-proof seeker', 'Needs reassurance from people like them.', 'Testimonial/credibility-led social proof.', 'Review cluster layout with trust badges.', 'Belonging and confidence.', '“Thousands already made the switch.”'],
    ['Routine-builder', 'Struggles to stay consistent every day.', 'Habit-friendly routine angle.', 'Simple step-by-step daily ritual scene.', 'Consistency and motivation.', '“Easy enough to stick with.”'],
    ['Quality-focused buyer', 'Wants premium quality without hype.', 'Premium craftsmanship + proof framing.', 'Editorial hero shot with premium composition.', 'Pride and certainty.', '“Premium feel, practical results.”'],
    ['Gift buyer / recommender', 'Needs a safe recommendation to share.', 'Shareable-confidence recommendation angle.', 'Gift-ready product presentation with social context.', 'Pride and generosity.', '“The product I confidently recommend.”']
  ];

  let fallbackIndex = 0;
  while (items.length < requested && fallbackIndex < fallbackItems.length) {
    const fallback = fallbackItems[fallbackIndex];
    pushUnique({
      persona: fallback[0],
      pain_point: fallback[1],
      angle: fallback[2],
      visual_direction: fallback[3],
      emotion: fallback[4],
      copy_hook: fallback[5]
    }, 'fallback');
    fallbackIndex += 1;
  }

  while (items.length < requested) {
    const next = items.length + 1;
    pushUnique({
      persona: `Audience Segment ${next}`,
      pain_point: 'Needs a clearer reason to act now.',
      angle: `Distinct conversion angle ${next}`,
      visual_direction: 'Clean direct-response product composition.',
      emotion: 'Clarity and confidence.',
      copy_hook: `“Reason to switch #${next}.”`
    }, 'fallback');
  }

  return {
    items: items.slice(0, requested),
    rationale: normalizeBrandIntelligenceField(
      (parsed && (parsed.rationale || parsed.summary || parsed.notes)) || rawOutput || '',
      1000
    ),
    modelItemsCount
  };
}

async function listBrandIntelligence(clientId) {
  const rows = await dbAll(
    'SELECT * FROM brand_intelligence WHERE client_id = ? ORDER BY id ASC',
    [clientId]
  );
  return rows.map(parseBrandIntelligenceRow);
}

async function getBrandIntelligenceResearchText(clientId) {
  const row = await dbGet(
    'SELECT intelligence_research_text FROM brand_kits WHERE client_id = ?',
    [clientId]
  );
  return normalizeResearchText(row && row.intelligence_research_text ? row.intelligence_research_text : '');
}

async function saveBrandIntelligenceResearchText(clientId, researchText, runner = null) {
  const normalized = normalizeResearchText(researchText);
  await ensureBrandKitRecord(clientId, runner);
  await executeQuery(
    'UPDATE brand_kits SET intelligence_research_text = ?, updated_at = CURRENT_TIMESTAMP WHERE client_id = ?',
    [normalized || null, clientId],
    runner
  );
  return normalized;
}

async function replaceBrandIntelligence(clientId, items, source = 'ai') {
  const normalizedSource = normalizeBrandIntelligenceField(source, 40) || 'ai';
  const safeItems = Array.isArray(items) ? items : [];

  await withDbTransaction(async (tx) => {
    await tx.query('DELETE FROM brand_intelligence WHERE client_id = ?', [clientId]);

    for (const item of safeItems) {
      const normalized = {
        persona: normalizeBrandIntelligenceField(item.persona, 120),
        pain_point: normalizeBrandIntelligenceField(item.pain_point, 220),
        angle: normalizeBrandIntelligenceField(item.angle, 220),
        visual_direction: normalizeBrandIntelligenceField(item.visual_direction, 220),
        emotion: normalizeBrandIntelligenceField(item.emotion, 120),
        copy_hook: normalizeBrandIntelligenceField(item.copy_hook, 220)
      };

      if (!normalized.persona || !normalized.angle) continue;

      await tx.query(`
        INSERT INTO brand_intelligence (
          client_id,
          persona,
          pain_point,
          angle,
          visual_direction,
          emotion,
          copy_hook,
          source,
          created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `, [
        clientId,
        normalized.persona,
        normalized.pain_point || 'Needs a clearer, easier path to solve the problem.',
        normalized.angle,
        normalized.visual_direction || 'Clean product-focused direct-response composition.',
        normalized.emotion || 'Relief and confidence.',
        normalized.copy_hook || '',
        normalizedSource
      ]);
    }
  });

  return await listBrandIntelligence(clientId);
}

function normalizeBrandIntelligenceItemInput(payload = {}, fallback = {}) {
  const merged = {
    persona: payload.persona ?? payload.avatar ?? fallback.persona ?? '',
    pain_point: payload.pain_point ?? payload.painPoint ?? payload.pain ?? fallback.pain_point ?? '',
    angle: payload.angle ?? payload.concept ?? fallback.angle ?? '',
    visual_direction: payload.visual_direction ?? payload.visualDirection ?? payload.visual ?? fallback.visual_direction ?? '',
    emotion: payload.emotion ?? fallback.emotion ?? '',
    copy_hook: payload.copy_hook ?? payload.copyHook ?? fallback.copy_hook ?? '',
    source: payload.source ?? fallback.source ?? 'manual'
  };

  const normalized = {
    persona: normalizeBrandIntelligenceField(merged.persona, 120),
    pain_point: normalizeBrandIntelligenceField(merged.pain_point, 220),
    angle: normalizeBrandIntelligenceField(merged.angle, 220),
    visual_direction: normalizeBrandIntelligenceField(merged.visual_direction, 220),
    emotion: normalizeBrandIntelligenceField(merged.emotion, 120),
    copy_hook: normalizeBrandIntelligenceField(merged.copy_hook, 220),
    source: normalizeBrandIntelligenceField(merged.source, 40) || 'manual'
  };

  return {
    persona: normalized.persona,
    pain_point: normalized.pain_point || 'Needs a clearer, easier path to solve the problem.',
    angle: normalized.angle,
    visual_direction: normalized.visual_direction || 'Clean product-focused direct-response composition.',
    emotion: normalized.emotion || 'Relief and confidence.',
    copy_hook: normalized.copy_hook || '',
    source: normalized.source
  };
}

async function createBrandIntelligenceItem(clientId, payload, source = 'manual') {
  const normalized = normalizeBrandIntelligenceItemInput(payload, { source });
  if (!normalized.persona || !normalized.angle) {
    return { error: 'Persona and angle are required.' };
  }

  const inserted = await executeQuery(`
    INSERT INTO brand_intelligence (
      client_id,
      persona,
      pain_point,
      angle,
      visual_direction,
      emotion,
      copy_hook,
      source,
      created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    RETURNING id
  `, [
    clientId,
    normalized.persona,
    normalized.pain_point,
    normalized.angle,
    normalized.visual_direction,
    normalized.emotion,
    normalized.copy_hook,
    normalized.source
  ]);

  const insertedId = inserted && inserted.rows && inserted.rows[0] ? Number(inserted.rows[0].id) : null;
  const row = await dbGet('SELECT * FROM brand_intelligence WHERE id = ? AND client_id = ?', [insertedId, clientId]);
  return { item: parseBrandIntelligenceRow(row), error: null };
}

async function updateBrandIntelligenceItem(clientId, profileId, payload = {}) {
  const existing = await dbGet(
    'SELECT * FROM brand_intelligence WHERE id = ? AND client_id = ?',
    [profileId, clientId]
  );
  if (!existing) {
    return { item: null, error: 'Profile not found.' };
  }

  const normalized = normalizeBrandIntelligenceItemInput(payload, existing);
  if (!normalized.persona || !normalized.angle) {
    return { item: null, error: 'Persona and angle are required.' };
  }

  await executeQuery(`
    UPDATE brand_intelligence
    SET
      persona = ?,
      pain_point = ?,
      angle = ?,
      visual_direction = ?,
      emotion = ?,
      copy_hook = ?,
      source = ?
    WHERE id = ? AND client_id = ?
  `, [
    normalized.persona,
    normalized.pain_point,
    normalized.angle,
    normalized.visual_direction,
    normalized.emotion,
    normalized.copy_hook,
    normalized.source,
    profileId,
    clientId
  ]);

  const updated = await dbGet(
    'SELECT * FROM brand_intelligence WHERE id = ? AND client_id = ?',
    [profileId, clientId]
  );
  return { item: parseBrandIntelligenceRow(updated), error: null };
}

async function deleteBrandIntelligenceItem(clientId, profileId) {
  const existing = await dbGet(
    'SELECT id FROM brand_intelligence WHERE id = ? AND client_id = ?',
    [profileId, clientId]
  );
  if (!existing) {
    return false;
  }
  await executeQuery('DELETE FROM brand_intelligence WHERE id = ? AND client_id = ?', [profileId, clientId]);
  return true;
}

function normalizeTemplateName(name, fallback = 'Untitled Template') {
  const value = String(name || '').trim();
  return value || fallback;
}

function normalizeTemplateCategory(category, fallback = 'Custom') {
  const value = String(category || '').trim();
  return value || fallback;
}

function normalizeAssetCategory(category, fallback = 'Other') {
  const raw = normalizeWhitespace(category || '').toLowerCase();
  if (!raw) return fallback;

  if (raw === 'product' || raw === 'product image' || raw === 'product shot') {
    return 'Product Image';
  }
  if (raw === 'packaging' || raw === 'packaging shot' || raw === 'package' || raw === 'pack') {
    return 'Packaging';
  }
  if (raw === 'lifestyle' || raw === 'lifestyle image' || raw === 'lifestyle images' || raw === 'in-use') {
    return 'Lifestyle';
  }
  if (raw === 'logo') {
    return 'Logo';
  }
  if (raw === 'other' || raw === 'uncategorized') {
    return 'Other';
  }

  return fallback;
}

async function persistTemplateRecord({ clientId, name, category, imagePath, sourceType, tags, isFavorite = false }) {
  const inserted = await executeQuery(`
    INSERT INTO templates (
      client_id,
      name,
      category,
      image_path,
      source_type,
      tags,
      is_favorite,
      created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    RETURNING id
  `, [
    clientId,
    normalizeTemplateName(name),
    normalizeTemplateCategory(category),
    imagePath,
    sourceType || 'uploaded',
    JSON.stringify(parseTemplateTags(tags)),
    isFavorite ? 1 : 0
  ]);

  const insertedId = inserted && inserted.rows && inserted.rows[0] ? Number(inserted.rows[0].id) : null;
  const row = await dbGet('SELECT * FROM templates WHERE id = ? AND client_id = ?', [insertedId, clientId]);
  return parseTemplateRow(row);
}

function copyImageIntoTemplateLibrary(sourceImagePath, targetNamePrefix = 'template') {
  const sourceAbsPath = resolveUploadPath(sourceImagePath);
  const ext = path.extname(sourceAbsPath).toLowerCase() || '.png';
  const base = slugify(targetNamePrefix) || 'template';
  const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${base}${ext}`;
  const targetAbsPath = path.join(TEMPLATE_DIR, filename);

  fs.copyFileSync(sourceAbsPath, targetAbsPath);
  return toPublicPath(targetAbsPath);
}

function extractJsonObjectFromText(rawText) {
  const text = String(rawText || '').trim();
  if (!text) return null;

  try {
    const direct = JSON.parse(text);
    if (typeof direct === 'string') {
      try {
        return JSON.parse(direct);
      } catch (_error) {
        return null;
      }
    }
    return direct;
  } catch (_error) {
    // Try extracting JSON block.
  }

  const fenced = text.match(/```json\s*([\s\S]*?)```/i) || text.match(/```\s*([\s\S]*?)```/i);
  if (fenced && fenced[1]) {
    try {
      const fencedParsed = JSON.parse(fenced[1].trim());
      if (typeof fencedParsed === 'string') {
        return JSON.parse(fencedParsed);
      }
      return fencedParsed;
    } catch (_error) {
      // Continue to object-range extraction.
    }
  }

  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start !== -1 && end !== -1 && end > start) {
    const candidate = text.slice(start, end + 1);
    try {
      const candidateParsed = JSON.parse(candidate);
      if (typeof candidateParsed === 'string') {
        return JSON.parse(candidateParsed);
      }
      return candidateParsed;
    } catch (_error) {
      return null;
    }
  }

  return null;
}

function decodeEscapedPromptText(value) {
  const raw = String(value || '');
  if (!raw) return '';

  try {
    return normalizeWhitespace(JSON.parse(`"${raw}"`));
  } catch (_error) {
    return normalizeWhitespace(
      raw
        .replace(/\\"/g, '"')
        .replace(/\\n/g, ' ')
        .replace(/\\t/g, ' ')
        .replace(/\\r/g, ' ')
        .replace(/\\u([0-9a-fA-F]{4})/g, (_match, hex) => {
          try {
            return String.fromCharCode(parseInt(hex, 16));
          } catch (_innerError) {
            return ' ';
          }
        })
    );
  }
}

function extractPlainTextFromModelResponse(rawText) {
  const text = String(rawText || '').trim();
  if (!text) return '';
  const fenced = text.match(/```(?:json|text)?\s*([\s\S]*?)```/i);
  let cleaned = fenced && fenced[1] ? fenced[1].trim() : text;
  cleaned = cleaned
    .replace(/^here(?:'s| is)\s+the\s+prompt\s*[:\-]\s*/i, '')
    .replace(/^final\s+prompt\s*[:\-]\s*/i, '')
    .trim();
  return normalizeWhitespace(cleaned);
}

function captureJsonLikeStringValue(text, key) {
  const source = String(text || '');
  if (!source) return '';
  const keyRegex = new RegExp(`["']?${key}["']?\\s*:\\s*`, 'i');
  const match = keyRegex.exec(source);
  if (!match) return '';

  let index = match.index + match[0].length;
  while (index < source.length && /\s/.test(source[index])) {
    index += 1;
  }
  if (index >= source.length) return '';

  const starter = source[index];
  if (starter === '"' || starter === '\'') {
    const quote = starter;
    index += 1;
    let buffer = '';
    let escaping = false;
    while (index < source.length) {
      const ch = source[index];
      if (escaping) {
        buffer += `\\${ch}`;
        escaping = false;
      } else if (ch === '\\') {
        escaping = true;
      } else if (ch === quote) {
        break;
      } else {
        buffer += ch;
      }
      index += 1;
    }
    return decodeEscapedPromptText(buffer);
  }

  const tail = source.slice(index);
  const token = tail.split(/[,\n\r}]/)[0] || '';
  return normalizeWhitespace(token);
}

function extractPromptFromTextBlob(value) {
  const text = normalizeWhitespace(value);
  if (!text) return '';

  const parsed = extractJsonObjectFromText(text);
  if (parsed && typeof parsed === 'object') {
    return extractPromptFromStructuredVariant(parsed);
  }

  const keys = [
    'base_prompt',
    'basePrompt',
    'variant_prompt',
    'variantPrompt',
    'direction_prompt',
    'directionPrompt',
    'creative_prompt',
    'creativePrompt',
    'style_prompt',
    'stylePrompt',
    'prompt',
    'text'
  ];

  for (const key of keys) {
    const regex = new RegExp(`"${key}"\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"`, 'i');
    const match = text.match(regex);
    if (match && match[1]) {
      return decodeEscapedPromptText(match[1]);
    }
    const jsonLikeValue = captureJsonLikeStringValue(text, key);
    if (jsonLikeValue) {
      return jsonLikeValue;
    }
  }

  return text;
}

function extractPromptFromStructuredVariant(value) {
  if (!value) return '';

  if (typeof value === 'string') {
    return extractPromptFromTextBlob(value);
  }

  if (typeof value === 'object') {
    const promptValue = extractPromptFromStructuredVariant(
      value.prompt ||
      value.text ||
      value.variant_prompt ||
      value.variantPrompt ||
      value.direction_prompt ||
      value.directionPrompt ||
      value.creative_prompt ||
      value.creativePrompt ||
      value.base_prompt ||
      value.basePrompt ||
      value.style_prompt ||
      value.stylePrompt ||
      ''
    );
    return promptValue;
  }

  return '';
}

function buildVariantFingerprint(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/variant\s*direction\s*\d+/g, '')
    .replace(/testing\s*direction\s*\d+/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 220);
}

function normalizeStyleAnalysisResponse(parsed, rawOutput, variantCount = 4) {
  const targetCount = Math.max(1, Math.min(Number(variantCount) || 4, 8));
  const fallbackText = normalizeWhitespace(rawOutput).slice(0, 1000);

  let stylePromptSeed = extractPromptFromStructuredVariant(
    (parsed && (parsed.style_prompt || parsed.base_prompt || parsed.basePrompt || parsed.prompt)) ||
    'Create a high-converting static ad using the selected reference layout and selected product image.'
  );
  if (/^\s*\{/.test(stylePromptSeed) && /base[_\s-]?prompt/i.test(stylePromptSeed)) {
    stylePromptSeed = extractPromptFromTextBlob(stylePromptSeed);
  }
  const stylePrompt = enforceStaticAdLanguage(stylePromptSeed);
  const styleFingerprint = buildVariantFingerprint(stylePrompt);

  const layoutRaw = parsed && (parsed.layout_blueprint || parsed.layoutBlueprint);
  const layoutBlueprint = Array.isArray(layoutRaw)
    ? layoutRaw.map((item) => normalizeWhitespace(item)).filter(Boolean).slice(0, 8)
    : [];

  if (layoutBlueprint.length === 0) {
    layoutBlueprint.push(
      'Strong headline zone near top',
      'Primary product hero in center',
      'Offer/supporting elements below product',
      'Clear CTA region near bottom'
    );
  }

  const copyRaw = (parsed && (parsed.copy_skeleton || parsed.copySkeleton)) || {};
  const copySkeleton = {
    headline: normalizeWhitespace(copyRaw.headline || 'Main promise for {PRODUCT}'),
    subheadline: normalizeWhitespace(copyRaw.subheadline || 'Key support line for {AUDIENCE}'),
    body: normalizeWhitespace(copyRaw.body || 'Benefit proof + offer details using {OFFER}'),
    cta: normalizeWhitespace(copyRaw.cta || '{CTA}')
  };

  const variantRaw = parsed && (parsed.variant_prompts || parsed.variantPrompts || parsed.variants);
  const normalizedVariantPrompts = [];
  const seenVariantFingerprints = new Set();

  function pushUniqueVariant({ name, prompt }) {
    const basePrompt = extractPromptFromStructuredVariant(prompt);
    const objectHint = prompt && typeof prompt === 'object'
      ? normalizeWhitespace(
        prompt.direction ||
        prompt.variant_direction ||
        prompt.variantDirection ||
        prompt.angle ||
        prompt.strategy ||
        prompt.rationale ||
        prompt.delta ||
        prompt.distinction ||
        ''
      )
      : '';
    const combinedPrompt = [basePrompt, objectHint].filter(Boolean).join(' ');
    const cleanedPrompt = enforceStaticAdLanguage(combinedPrompt);
    if (!cleanedPrompt) return;
    const fingerprint = buildVariantFingerprint(cleanedPrompt);
    if (!fingerprint || seenVariantFingerprints.has(fingerprint) || fingerprint === styleFingerprint) return;
    seenVariantFingerprints.add(fingerprint);
    normalizedVariantPrompts.push({
      name: normalizeWhitespace(name || `Variant ${normalizedVariantPrompts.length + 1}`),
      prompt: cleanedPrompt
    });
  }

  if (Array.isArray(variantRaw)) {
    for (const item of variantRaw) {
      if (typeof item === 'string') {
        pushUniqueVariant({
          name: `Variant ${normalizedVariantPrompts.length + 1}`,
          prompt: item
        });
        continue;
      }

      if (item && typeof item === 'object') {
        pushUniqueVariant({
          name: item.name || item.label || `Variant ${normalizedVariantPrompts.length + 1}`,
          prompt: item
        });
      }
    }
  } else if (variantRaw && typeof variantRaw === 'object') {
    for (const [key, value] of Object.entries(variantRaw)) {
      pushUniqueVariant({
        name: normalizeWhitespace(key || `Variant ${normalizedVariantPrompts.length + 1}`),
        prompt: value
      });
    }
  }

  const angleFallbacks = [
    'Angle: Problem-agitation-solution framing with pain-first headline and relief CTA.',
    'Angle: Benefit stack framing with 3 concrete outcomes and icon-style callouts.',
    'Angle: Social-proof framing with testimonial snippet and trust signal.',
    'Angle: Offer urgency framing with limited-time incentive and deadline cue.',
    'Angle: Comparison framing (old way vs {PRODUCT}) with clear winner statement.',
    'Angle: Routine simplicity framing with 3-step daily-use flow.',
    'Angle: Objection handling framing that addresses the top hesitation directly.',
    'Angle: Authority framing with expert-style, factual tone and proof language.'
  ];

  while (normalizedVariantPrompts.length < targetCount) {
    const index = normalizedVariantPrompts.length + 1;
    const anglePrompt = angleFallbacks[(index - 1) % angleFallbacks.length];
    pushUniqueVariant({
      name: `Variant ${index}`,
      prompt: `${stylePrompt} ${anglePrompt} Keep the product from the selected product image.`
    });

    // Safety fallback if uniqueness filtering still prevented insert.
    if (normalizedVariantPrompts.length < index) {
      normalizedVariantPrompts.push({
        name: `Variant ${index}`,
        prompt: `${stylePrompt} Distinct testing direction ${index}. Keep the product from the selected product image.`
      });
    }
  }

  const cappedVariants = normalizedVariantPrompts
    .slice(0, targetCount)
    .map((variant, index) => ({
      name: normalizeWhitespace(variant.name || `Variant ${index + 1}`),
      prompt: enforceStaticAdLanguage(
        `${variant.prompt} Perspective shift ${index + 1}: ${angleFallbacks[index % angleFallbacks.length]} Use layout/style from reference image and feature only the product from selected product image. This must be a static image ad, not a video.`
      )
    }));

  const rationale = normalizeWhitespace(
    (parsed && parsed.rationale) ||
    'Style analysis extracted from visual hierarchy, composition, offer placement, and CTA structure.'
  ) || fallbackText;

  return {
    style_prompt: stylePrompt,
    layout_blueprint: layoutBlueprint,
    copy_skeleton: copySkeleton,
    rationale,
    variant_prompts: cappedVariants
  };
}

function normalizeConceptPortfolioResponse(parsed, rawOutput, conceptCount = 6) {
  const targetCount = Math.max(3, Math.min(Number(conceptCount) || 6, 8));
  const fallbackRationale = normalizeWhitespace(rawOutput).slice(0, 1000);
  const sourceList = parsed && (parsed.concepts || parsed.ideas || parsed.frameworks || parsed.angles);
  const concepts = [];

  if (Array.isArray(sourceList)) {
    for (const item of sourceList) {
      if (!item) continue;

      let normalizedItem = item;
      if (typeof item === 'string') {
        normalizedItem = {
          name: item,
          concept_type: 'Offer-Led',
          angle: item,
          why_distinct: 'Different promise framing from baseline concept.',
          prompt_template: item
        };
      }

      if (!normalizedItem || typeof normalizedItem !== 'object') continue;

      const name = normalizeWhitespace(
        normalizedItem.name ||
        normalizedItem.concept_name ||
        normalizedItem.title ||
        `Concept ${concepts.length + 1}`
      ) || `Concept ${concepts.length + 1}`;

      const conceptType = normalizeWhitespace(
        normalizedItem.concept_type ||
        normalizedItem.type ||
        normalizedItem.framework ||
        normalizedItem.category ||
        'Offer-Led'
      ) || 'Offer-Led';

      const angle = normalizeWhitespace(
        normalizedItem.angle ||
        normalizedItem.hook ||
        normalizedItem.message_angle ||
        normalizedItem.positioning ||
        name
      ) || name;

      const audienceStage = normalizeWhitespace(
        normalizedItem.audience_stage ||
        normalizedItem.stage ||
        normalizedItem.funnel_stage ||
        'consideration'
      ) || 'consideration';

      const whyDistinct = normalizeWhitespace(
        normalizedItem.why_distinct ||
        normalizedItem.distinction ||
        normalizedItem.rationale ||
        normalizedItem.reason ||
        'Uses a different persuasion path than a standard feature/offer ad.'
      ) || 'Uses a different persuasion path than a standard feature/offer ad.';

      const distanceScoreRaw = Number(
        normalizedItem.distance_score ??
        normalizedItem.novelty_score ??
        normalizedItem.concept_distance ??
        55
      );
      const distanceScore = Math.max(0, Math.min(100, Number.isFinite(distanceScoreRaw) ? Math.round(distanceScoreRaw) : 55));

      const copyRaw = (normalizedItem.copy_skeleton || normalizedItem.copySkeleton || {});
      const copySkeleton = {
        headline: normalizeWhitespace(copyRaw.headline || ''),
        subheadline: normalizeWhitespace(copyRaw.subheadline || ''),
        body: normalizeWhitespace(copyRaw.body || ''),
        cta: normalizeWhitespace(copyRaw.cta || '')
      };

      const promptTemplate = normalizeWhitespace(
        normalizedItem.prompt_template ||
        normalizedItem.promptTemplate ||
        normalizedItem.prompt ||
        [
          `Create a ${conceptType} ad concept for {PRODUCT}.`,
          `Core angle: ${angle}.`,
          'Use the reference only for style/layout.',
          'Use only the selected product image for product identity.',
          'Keep this at least 40% conceptually different from standard offer ads.'
        ].join(' ')
      );

      concepts.push({
        id: normalizeWhitespace(normalizedItem.id || '') || `concept-${concepts.length + 1}-${slugify(name).slice(0, 24) || 'idea'}`,
        name,
        concept_type: conceptType,
        angle,
        audience_stage: audienceStage,
        why_distinct: whyDistinct,
        distance_score: distanceScore,
        prompt_template: promptTemplate,
        copy_skeleton: copySkeleton
      });
    }
  }

  const fallbackConcepts = [
    {
      name: 'Problem-Agitation-Solution',
      concept_type: 'PAS',
      angle: 'Intensify pain then resolve with the product',
      audience_stage: 'problem-aware',
      why_distinct: 'Leads with pain narrative instead of discount/offer.',
      distance_score: 68
    },
    {
      name: 'Social Proof Compilation',
      concept_type: 'Testimonial',
      angle: 'Customer outcomes and credibility cues',
      audience_stage: 'consideration',
      why_distinct: 'Leads with trust and proof rather than claims.',
      distance_score: 62
    },
    {
      name: 'Us vs Them Breakdown',
      concept_type: 'Comparison',
      angle: 'Show contrast against alternatives',
      audience_stage: 'decision',
      why_distinct: 'Decision framing via alternatives matrix.',
      distance_score: 71
    },
    {
      name: 'Objection Crusher',
      concept_type: 'Objection Handling',
      angle: 'Answer key hesitations directly',
      audience_stage: 'late consideration',
      why_distinct: 'Centers rebuttals before pitch.',
      distance_score: 64
    },
    {
      name: 'Offer Deadline Stack',
      concept_type: 'Offer-Led',
      angle: 'Urgency + stacked value offer',
      audience_stage: 'decision',
      why_distinct: 'Uses urgency and economic framing.',
      distance_score: 57
    },
    {
      name: 'Feature-to-Benefit Ladder',
      concept_type: 'Feature Education',
      angle: 'Translate product details into concrete outcomes',
      audience_stage: 'awareness',
      why_distinct: 'Educational progression versus direct offer.',
      distance_score: 60
    }
  ];

  let index = 0;
  while (concepts.length < targetCount && index < fallbackConcepts.length) {
    const fallback = fallbackConcepts[index];
    const id = `concept-${concepts.length + 1}-${slugify(fallback.name).slice(0, 24) || 'idea'}`;
    concepts.push({
      id,
      ...fallback,
      prompt_template: [
        `Create a ${fallback.concept_type} static ad for {PRODUCT}.`,
        `Angle: ${fallback.angle}.`,
        'Use reference image only for layout/style signals.',
        'Use selected product image for product identity and visual subject.',
        'Maintain at least 40% conceptual distance from generic offer-led creatives.'
      ].join(' '),
      copy_skeleton: {
        headline: '{HEADLINE}',
        subheadline: '{SUBHEADLINE}',
        body: '{BODY_COPY}',
        cta: '{CTA}'
      }
    });
    index += 1;
  }

  const deduped = [];
  const seen = new Set();
  for (const concept of concepts) {
    const key = `${concept.concept_type}::${concept.angle}`.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(concept);
  }

  while (deduped.length < targetCount) {
    const n = deduped.length + 1;
    deduped.push({
      id: `concept-${n}`,
      name: `Concept ${n}`,
      concept_type: 'Custom Angle',
      angle: `Alternative conversion framing ${n}`,
      audience_stage: 'consideration',
      why_distinct: 'Alternative persuasion route for broader audience coverage.',
      distance_score: 55,
      prompt_template: [
        'Create a high-converting static ad with a distinct conversion angle.',
        'Reference image provides layout/style only.',
        'Selected product image defines product identity.',
        'Make this conceptually distinct from prior concepts.'
      ].join(' '),
      copy_skeleton: {
        headline: '{HEADLINE}',
        subheadline: '{SUBHEADLINE}',
        body: '{BODY_COPY}',
        cta: '{CTA}'
      }
    });
  }

  const normalizedConcepts = deduped.slice(0, targetCount).map((concept, idx) => ({
    ...concept,
    id: normalizeWhitespace(concept.id) || `concept-${idx + 1}`,
    distance_score: Math.max(0, Math.min(100, Number(concept.distance_score) || 55)),
    copy_skeleton: {
      headline: normalizeWhitespace(concept.copy_skeleton && concept.copy_skeleton.headline),
      subheadline: normalizeWhitespace(concept.copy_skeleton && concept.copy_skeleton.subheadline),
      body: normalizeWhitespace(concept.copy_skeleton && concept.copy_skeleton.body),
      cta: normalizeWhitespace(concept.copy_skeleton && concept.copy_skeleton.cta)
    }
  }));

  const recommendedId = normalizeWhitespace(
    (parsed && (parsed.recommended_id || parsed.recommendedConceptId || parsed.recommended_concept_id)) ||
    (normalizedConcepts[0] && normalizedConcepts[0].id)
  ) || (normalizedConcepts[0] && normalizedConcepts[0].id);

  return {
    concepts: normalizedConcepts,
    recommended_id: recommendedId,
    rationale: normalizeWhitespace(parsed && parsed.rationale) || fallbackRationale
  };
}

function normalizeCampaignPlanResponse(parsed, {
  productContext,
  campaignGoal,
  avatarCount,
  conceptsPerAvatar,
  maxItems
}) {
  const targetAvatars = Math.max(2, Math.min(Number(avatarCount) || 5, 8));
  const targetConcepts = Math.max(2, Math.min(Number(conceptsPerAvatar) || 3, 8));
  const targetItems = Math.max(4, Math.min(Number(maxItems) || (targetAvatars * targetConcepts), 60));

  const fallbackAvatars = [
    { id: 'avatar-busy-parent', name: 'Busy Parent', pain_point: 'No time for complex routines', overlooked_reason: 'High intent but low time.' },
    { id: 'avatar-budget-shopper', name: 'Budget-Conscious Buyer', pain_point: 'Needs value proof before buying', overlooked_reason: 'Often dismissed as price-only.' },
    { id: 'avatar-first-timer', name: 'Skeptical First-Timer', pain_point: 'Unsure if product will work', overlooked_reason: 'Needs trust and proof framing.' },
    { id: 'avatar-performance', name: 'Performance Seeker', pain_point: 'Wants measurable outcome fast', overlooked_reason: 'Responds to feature/benefit specifics.' },
    { id: 'avatar-gift-buyer', name: 'Gift Buyer', pain_point: 'Needs a practical, meaningful buy', overlooked_reason: 'Often hidden seasonal segment.' },
    { id: 'avatar-community', name: 'Community-Tribe Buyer', pain_point: 'Looks for social proof from peers', overlooked_reason: 'Converts when culturally aligned.' },
    { id: 'avatar-professional', name: 'Professional Use Case', pain_point: 'Needs reliability under pressure', overlooked_reason: 'Non-obvious occupational audience.' },
    { id: 'avatar-overlooked', name: 'Overlooked Niche Persona', pain_point: 'Needs identity-specific relevance', overlooked_reason: 'Often absent from standard targeting.' }
  ];

  const fallbackConcepts = [
    { id: 'concept-problem-solution', name: 'Problem/Solution', framework: 'Pain-first scenario then clear resolution.' },
    { id: 'concept-benefit-stack', name: 'Feature/Benefit Stack', framework: '3 key benefits with icon callouts.' },
    { id: 'concept-comparison', name: 'Comparison', framework: 'Us vs alternative with explicit contrast.' },
    { id: 'concept-education', name: 'Educational Checklist', framework: 'Checklist/guide style with authority tone.' },
    { id: 'concept-social-proof', name: 'Social Proof', framework: 'Testimonial/community validation framing.' },
    { id: 'concept-emotional', name: 'Emotional/Values', framework: 'Values-led narrative and identity resonance.' },
    { id: 'concept-offer', name: 'Offer/CTA', framework: 'Urgent offer framing with direct CTA.' },
    { id: 'concept-engagement', name: 'Engagement Prompt', framework: 'Pattern interrupt with visual prompt/puzzle.' }
  ];

  const rawAvatars = parsed && (parsed.avatars || parsed.audiences || parsed.personas);
  const rawConcepts = parsed && (parsed.concepts || parsed.angles || parsed.frameworks);

  const avatars = [];
  const avatarSeen = new Set();
  if (Array.isArray(rawAvatars)) {
    for (const item of rawAvatars) {
      if (!item) continue;
      if (typeof item === 'string') {
        const label = normalizeWhitespace(item);
        if (!label) continue;
        const key = slugify(label).toLowerCase();
        if (!key || avatarSeen.has(key)) continue;
        avatarSeen.add(key);
        avatars.push({
          id: `avatar-${slugify(label).slice(0, 30) || avatars.length + 1}`,
          name: label,
          pain_point: '',
          overlooked_reason: ''
        });
        continue;
      }
      if (typeof item === 'object') {
        const name = normalizeWhitespace(item.name || item.avatar || item.persona || item.title);
        if (!name) continue;
        const key = slugify(name).toLowerCase();
        if (!key || avatarSeen.has(key)) continue;
        avatarSeen.add(key);
        avatars.push({
          id: normalizeWhitespace(item.id || '') || `avatar-${slugify(name).slice(0, 30) || avatars.length + 1}`,
          name,
          pain_point: normalizeWhitespace(item.pain_point || item.pain || item.problem || ''),
          overlooked_reason: normalizeWhitespace(item.overlooked_reason || item.reason || item.why_overlooked || '')
        });
      }
    }
  }

  const concepts = [];
  const conceptSeen = new Set();
  if (Array.isArray(rawConcepts)) {
    for (const item of rawConcepts) {
      if (!item) continue;
      if (typeof item === 'string') {
        const label = normalizeWhitespace(item);
        if (!label) continue;
        const key = slugify(label).toLowerCase();
        if (!key || conceptSeen.has(key)) continue;
        conceptSeen.add(key);
        concepts.push({
          id: `concept-${slugify(label).slice(0, 30) || concepts.length + 1}`,
          name: label,
          framework: ''
        });
        continue;
      }
      if (typeof item === 'object') {
        const name = normalizeWhitespace(item.name || item.concept || item.angle || item.title);
        if (!name) continue;
        const key = slugify(name).toLowerCase();
        if (!key || conceptSeen.has(key)) continue;
        conceptSeen.add(key);
        concepts.push({
          id: normalizeWhitespace(item.id || '') || `concept-${slugify(name).slice(0, 30) || concepts.length + 1}`,
          name,
          framework: normalizeWhitespace(item.framework || item.description || item.strategy || '')
        });
      }
    }
  }

  for (const fallback of fallbackAvatars) {
    if (avatars.length >= targetAvatars) break;
    const key = slugify(fallback.name).toLowerCase();
    if (!key || avatarSeen.has(key)) continue;
    avatarSeen.add(key);
    avatars.push(fallback);
  }

  for (const fallback of fallbackConcepts) {
    if (concepts.length >= targetConcepts) break;
    const key = slugify(fallback.name).toLowerCase();
    if (!key || conceptSeen.has(key)) continue;
    conceptSeen.add(key);
    concepts.push(fallback);
  }

  const selectedAvatars = avatars.slice(0, targetAvatars).map((avatar, index) => ({
    id: avatar.id || `avatar-${index + 1}`,
    name: avatar.name || `Avatar ${index + 1}`,
    pain_point: avatar.pain_point || '',
    overlooked_reason: avatar.overlooked_reason || ''
  }));

  const selectedConcepts = concepts.slice(0, targetConcepts).map((concept, index) => ({
    id: concept.id || `concept-${index + 1}`,
    name: concept.name || `Concept ${index + 1}`,
    framework: concept.framework || ''
  }));

  const items = [];
  for (let a = 0; a < selectedAvatars.length; a += 1) {
    for (let c = 0; c < selectedConcepts.length; c += 1) {
      if (items.length >= targetItems) break;
      const avatar = selectedAvatars[a];
      const concept = selectedConcepts[c];
      const id = `item-${items.length + 1}-${slugify(avatar.name).slice(0, 14)}-${slugify(concept.name).slice(0, 14)}`;
      const promptTemplate = normalizeWhitespace([
        `Create a static Meta ad for avatar: ${avatar.name}.`,
        avatar.pain_point ? `Pain point: ${avatar.pain_point}.` : '',
        avatar.overlooked_reason ? `Insight: ${avatar.overlooked_reason}.` : '',
        `Concept angle: ${concept.name}.`,
        concept.framework ? `Framework: ${concept.framework}.` : '',
        productContext ? `Product context: ${productContext}.` : '',
        campaignGoal ? `Campaign goal: ${campaignGoal}.` : '',
        'Use winning ad as style inspiration, but produce a clearly new concept and headline structure.',
        'Output must be static image ad (not video).'
      ].filter(Boolean).join(' '));
      items.push({
        id,
        avatar_id: avatar.id,
        concept_id: concept.id,
        avatar_name: avatar.name,
        concept_name: concept.name,
        prompt_template: promptTemplate
      });
    }
  }

  return {
    avatars: selectedAvatars,
    concepts: selectedConcepts,
    items: items.slice(0, targetItems),
    rationale: normalizeWhitespace(
      parsed && (parsed.rationale || parsed.summary || parsed.strategy)
    ) || 'Generated campaign matrix from winning-style patterns, concept diversity, and avatar opportunities.'
  };
}

function withBrandPrompt(prompt, brandKit) {
  if (!brandKit) return prompt;

  const cleanPrompt = normalizeWhitespace(prompt);
  const brandParts = getBrandKitPolicyLines(brandKit);

  return [
    'Create a static advertisement for Meta/Facebook ads.',
    ...brandParts,
    cleanPrompt ? `Creative brief: ${cleanPrompt}` : ''
  ].filter(Boolean).join('\n');
}

function normalizeHexColor(colorHex, fallbackHex = '#000000') {
  const raw = normalizeWhitespace(colorHex || '');
  const match = raw.match(/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/);
  if (!match) return fallbackHex;

  let hex = match[1];
  if (hex.length === 3) {
    hex = hex.split('').map((char) => char + char).join('');
  }

  return `#${hex.toUpperCase()}`;
}

function describeBrandColor(colorHex, fallbackDescriptor = 'neutral') {
  const normalizedHex = normalizeHexColor(colorHex, '');
  if (!normalizedHex) return fallbackDescriptor;

  const hex = normalizedHex.slice(1);

  const r = parseInt(hex.slice(0, 2), 16) / 255;
  const g = parseInt(hex.slice(2, 4), 16) / 255;
  const b = parseInt(hex.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let hue = 0;
  if (delta > 0) {
    if (max === r) hue = ((g - b) / delta) % 6;
    else if (max === g) hue = ((b - r) / delta) + 2;
    else hue = ((r - g) / delta) + 4;
    hue *= 60;
    if (hue < 0) hue += 360;
  }

  const lightness = (max + min) / 2;
  const saturation = delta === 0 ? 0 : delta / (1 - Math.abs((2 * lightness) - 1));

  let hueFamily = 'gray';
  if (saturation >= 0.12) {
    if (hue < 15 || hue >= 345) hueFamily = 'red';
    else if (hue < 45) hueFamily = 'orange';
    else if (hue < 70) hueFamily = 'yellow';
    else if (hue < 160) hueFamily = 'green';
    else if (hue < 200) hueFamily = 'teal';
    else if (hue < 255) hueFamily = 'blue';
    else if (hue < 290) hueFamily = 'purple';
    else hueFamily = 'pink';
  }

  const lightnessDescriptor = lightness < 0.3
    ? 'deep'
    : (lightness > 0.72 ? 'light' : 'mid-tone');
  const saturationDescriptor = saturation > 0.62
    ? 'vivid'
    : (saturation < 0.22 ? 'muted' : '');

  return [lightnessDescriptor, saturationDescriptor, hueFamily].filter(Boolean).join(' ');
}

function extractPrimaryTypographyFamily(value) {
  const raw = normalizeWhitespace(value || '');
  if (!raw) return '';
  const first = raw.split(',')[0] || raw;
  return normalizeWhitespace(first.replace(/^['"]+|['"]+$/g, ''));
}

function normalizeTypographyStyleLabel(value) {
  const raw = normalizeWhitespace(value || '').toLowerCase();
  if (!raw) return '';
  if (/(geometric).*(sans)|\bsans\b.*(geometric)/.test(raw)) return 'geometric sans-serif';
  if (/(humanist).*(sans)|\bsans\b.*(humanist)/.test(raw)) return 'humanist sans-serif';
  if (/(rounded).*(sans)|\bsans\b.*(rounded)/.test(raw)) return 'rounded sans-serif';
  if (/(condensed).*(sans)|\bsans\b.*(condensed)/.test(raw)) return 'condensed sans-serif';
  if (/slab/.test(raw) && /serif/.test(raw)) return 'slab serif';
  if (/(classic|traditional|old[-\s]?style).*(serif)|\bserif\b.*(classic|traditional|old[-\s]?style)/.test(raw)) return 'classic serif';
  if (/serif/.test(raw)) return 'modern serif';
  if (/script|cursive/.test(raw)) return 'script/cursive';
  if (/handwritten|hand[-\s]?lettered/.test(raw)) return 'handwritten';
  if (/display|decorative/.test(raw)) return 'display/decorative';
  if (/mono|monospace/.test(raw)) return 'monospace';
  if (/sans|grotesk|grotesque/.test(raw)) return 'clean sans-serif';
  return '';
}

function inferTypographyStyleFromFamilyHeuristic(fontFamily) {
  const family = normalizeWhitespace(fontFamily || '').toLowerCase();
  if (!family) return '';

  if (/(dm[\s-]?sans|dmsans|poppins|montserrat|futura|gotham|circular|satoshi|avenir|proxima nova|euclid|gilroy)/.test(family)) {
    return 'geometric sans-serif';
  }
  if (/(inter|roboto|open sans|lato|helvetica|arial|noto sans|source sans|work sans|ibm plex sans)/.test(family)) {
    return 'clean sans-serif';
  }
  if (/(nunito|quicksand|comfortaa|sofia pro soft|museo sans rounded)/.test(family)) {
    return 'rounded sans-serif';
  }
  if (/(frutiger|myriad|pt sans|optima|calibri)/.test(family)) {
    return 'humanist sans-serif';
  }
  if (/(bebas|oswald|din condensed|barlow condensed|archivo narrow)/.test(family)) {
    return 'condensed sans-serif';
  }
  if (/(times|garamond|baskerville|georgia|caslon|merriweather|lora|crimson)/.test(family)) {
    return 'classic serif';
  }
  if (/(playfair|didot|bodoni|abril fatface|cormorant)/.test(family)) {
    return 'modern serif';
  }
  if (/(rockwell|roboto slab|arvo|clarendon|slab)/.test(family)) {
    return 'slab serif';
  }
  if (/(pacifico|lobster|great vibes|allura|dancing script|satisfy)/.test(family)) {
    return 'script/cursive';
  }
  if (/(courier|jetbrains mono|fira code|source code pro|monaco|consolas)/.test(family)) {
    return 'monospace';
  }
  if (/sans/.test(family)) {
    return 'clean sans-serif';
  }
  if (/serif/.test(family)) {
    return 'modern serif';
  }
  return '';
}

async function inferTypographyStyleFromFamilyWithGemini(fontFamily) {
  const family = extractPrimaryTypographyFamily(fontFamily);
  if (!family || !getGeminiApiKey()) return '';

  const cacheKey = family.toLowerCase();
  const cached = TYPOGRAPHY_STYLE_CACHE.get(cacheKey);
  if (cached && cached.style) return cached.style;

  try {
    const response = await callGeminiGenerateContent({
      system: [
        'You classify font-family inputs into broad typography styles for image-generation prompting.',
        'Do not return brand claims. Return JSON only.'
      ].join(' '),
      userPrompt: [
        `Font family input: "${family}"`,
        'Return ONLY valid JSON with exactly this shape:',
        '{"style":"string","confidence":"high|medium|low"}',
        'Allowed style values:',
        'geometric sans-serif, clean sans-serif, humanist sans-serif, rounded sans-serif, condensed sans-serif, modern serif, classic serif, slab serif, script/cursive, handwritten, display/decorative, monospace'
      ].join('\n'),
      maxTokens: 220,
      temperature: 0.1
    });
    const parsed = extractJsonObjectFromText(response.text);
    const style = normalizeTypographyStyleLabel(parsed && parsed.style ? parsed.style : '');
    if (style) {
      TYPOGRAPHY_STYLE_CACHE.set(cacheKey, { style, source: 'gemini' });
      return style;
    }
  } catch (error) {
    console.warn('[typography.style] gemini inference failed; using heuristic fallback', {
      fontFamily: family,
      error: normalizeWhitespace(error && error.message) || 'Unknown typography style inference error.'
    });
  }

  return '';
}

function getBrandKitTypographyDirection(brandKit) {
  if (!brandKit) {
    return { family: '', style: '', source: '' };
  }
  const family = extractPrimaryTypographyFamily(
    brandKit.typography_family_name || brandKit.typography || ''
  );
  const styleFromBrandKit = normalizeTypographyStyleLabel(brandKit.typography_style_hint || '');
  const styleFromHeuristic = inferTypographyStyleFromFamilyHeuristic(family);
  const style = styleFromBrandKit || styleFromHeuristic;
  const source = styleFromBrandKit
    ? (normalizeWhitespace(brandKit.typography_style_source || '') || 'brand')
    : (styleFromHeuristic ? 'heuristic' : '');
  return { family, style, source };
}

async function hydrateBrandKitTypographyStyle(brandKit) {
  if (!brandKit || typeof brandKit !== 'object') return brandKit;
  const { family, style: existingStyle, source: existingSource } = getBrandKitTypographyDirection(brandKit);
  if (!family) return brandKit;

  const cacheKey = family.toLowerCase();
  const cached = TYPOGRAPHY_STYLE_CACHE.get(cacheKey);
  if (cached && cached.style) {
    return {
      ...brandKit,
      typography_family_name: family,
      typography_style_hint: cached.style,
      typography_style_source: cached.source || existingSource || 'cache'
    };
  }

  let style = existingStyle || '';
  let source = existingSource || '';

  if (!style || source === 'heuristic') {
    const geminiStyle = await inferTypographyStyleFromFamilyWithGemini(family);
    if (geminiStyle) {
      style = geminiStyle;
      source = 'gemini';
    }
  }

  if (!style) {
    style = inferTypographyStyleFromFamilyHeuristic(family);
    source = style ? 'heuristic' : '';
  }

  if (style) {
    TYPOGRAPHY_STYLE_CACHE.set(cacheKey, { style, source: source || 'heuristic' });
  }

  return {
    ...brandKit,
    typography_family_name: family,
    typography_style_hint: style,
    typography_style_source: source || ''
  };
}

function getBrandKitPolicyLines(brandKit) {
  if (!brandKit) return [];
  const brandName = normalizeWhitespace(brandKit.brand_name || '');
  const brandDescription = normalizeWhitespace(brandKit.brand_description || '');
  const typographyDirection = getBrandKitTypographyDirection(brandKit);
  const typographyStyle = normalizeWhitespace(typographyDirection.style || '');
  const typographyFamily = normalizeWhitespace(typographyDirection.family || '');
  const primaryHex = normalizeHexColor(brandKit.color_primary, '#177443');
  const secondaryHex = normalizeHexColor(brandKit.color_secondary, '#FFCC2F');
  const accentHex = normalizeHexColor(brandKit.color_accent, '#FF8E2C');
  const primaryDescriptor = describeBrandColor(brandKit.color_primary, 'deep neutral');
  const secondaryDescriptor = describeBrandColor(brandKit.color_secondary, 'mid-tone neutral');
  const accentDescriptor = describeBrandColor(brandKit.color_accent, 'vivid accent');
  const hasUploadedLogo = Boolean(
    normalizeWhitespace(brandKit.logo_dark_path || '') || normalizeWhitespace(brandKit.logo_light_path || '')
  );

  return [
    'Brand Kit policy (higher priority than reference style hints):',
    brandName ? `- Brand name: ${brandName}.` : '- Brand name: Unnamed Brand.',
    brandDescription ? `- Brand/product context: ${brandDescription}.` : '',
    `- Brand palette lock (hard, internal metadata): primary ${primaryHex} (${primaryDescriptor}), secondary ${secondaryHex} (${secondaryDescriptor}), accent ${accentHex} (${accentDescriptor}).`,
    '- Keep primary as the dominant visual color direction across major non-product surfaces (background blocks, frames, banners, or CTA foundation).',
    '- Secondary and accent must both appear as intentional visible accents in the final creative (for example: badges, highlights, UI chips, CTA contrast, icons).',
    '- Avoid off-brand neutral-heavy palettes (beige/gray-only) as the main look; if neutrals are used, keep them minor compared with the locked palette.',
    '- If text/CTA elements are present, style them with the locked palette instead of arbitrary colors.',
    `- Do not introduce additional non-brand accent colors beyond ${primaryHex}, ${secondaryHex}, and ${accentHex} (neutral white/black allowed in minor support roles).`,
    '- Brand palette rules apply only to non-product elements (backgrounds, overlays, props, CTA zones).',
    '- Never recolor, tint, or hue-shift the product package or any printed package artwork.',
    typographyStyle
      ? `- MANDATORY typography style lock: all added overlay/headline/CTA text must use a ${typographyStyle} style.`
      : '- Typography lock: keep overlay typography clean and consistent when text is present.',
    typographyFamily
      ? `- Brand font name is "${typographyFamily}" for internal guidance only; if unavailable, prioritize the style lock above.`
      : '',
    '- Do not mix multiple unrelated font families in one creative; keep one consistent typography system.',
    '- Avoid serif/script/decorative fonts unless the locked typography style calls for it.',
    '- Never render any font family name as literal on-image copy (for example: "Brand Font", "Primary Typeface", etc.).',
    '- Never render raw Brand Kit metadata values (hex codes, field labels, or config words) as on-image text.',
    '- If reference-image typography or color treatment conflicts with Brand Kit, Brand Kit wins.',
    brandName
      ? `- Never invent alternative brand names or logo text. If a standalone logo/wordmark appears, it must read "${brandName}".`
      : '- Never invent alternative logos or brand marks.',
    hasUploadedLogo
      ? '- Official brand logos are uploaded; keep any rendered logo treatment clean and consistent with the official brand mark style.'
      : '',
    '- Preserve product-packaging logo and label text exactly from the selected product image.'
  ].filter(Boolean);
}

function buildBrandContextLine(brandKit) {
  if (!brandKit) return '';
  const typographyDirection = getBrandKitTypographyDirection(brandKit);
  const typographyStyle = normalizeWhitespace(typographyDirection.style || '');
  const typographyFamily = normalizeWhitespace(typographyDirection.family || '');
  const primaryHex = normalizeHexColor(brandKit.color_primary, '#177443');
  const secondaryHex = normalizeHexColor(brandKit.color_secondary, '#FFCC2F');
  const accentHex = normalizeHexColor(brandKit.color_accent, '#FF8E2C');
  const primaryDescriptor = describeBrandColor(brandKit.color_primary, 'deep neutral');
  const secondaryDescriptor = describeBrandColor(brandKit.color_secondary, 'mid-tone neutral');
  const accentDescriptor = describeBrandColor(brandKit.color_accent, 'vivid accent');
  return [
    brandKit.brand_name ? `Brand name: ${brandKit.brand_name}.` : '',
    brandKit.brand_description ? `Brand/product context: ${brandKit.brand_description}.` : '',
    typographyStyle ? `Brand typography style direction: ${typographyStyle}.` : '',
    typographyFamily ? `Brand font family input (reference only): ${typographyFamily}.` : '',
    `Brand colors (hard lock, internal metadata): primary ${primaryHex} (${primaryDescriptor}), secondary ${secondaryHex} (${secondaryDescriptor}), accent ${accentHex} (${accentDescriptor}).`
  ].filter(Boolean).join(' ');
}

function buildCampaignBrandPriorityLines(brandKit) {
  if (!brandKit) return [];
  const primaryHex = normalizeHexColor(brandKit.color_primary, '#177443');
  const secondaryHex = normalizeHexColor(brandKit.color_secondary, '#FFCC2F');
  const accentHex = normalizeHexColor(brandKit.color_accent, '#FF8E2C');
  return [
    ...getBrandKitPolicyLines(brandKit),
    `- Final compliance reminder: keep visible design accents locked to ${primaryHex}, ${secondaryHex}, and ${accentHex}.`,
    '- Campaign rule: avoid monochrome single-color treatment. Keep brand palette balance with visible secondary + accent usage.'
  ];
}

function logBrandKitApplication(route, clientId, brandKit) {
  if (!brandKit) {
    console.info('[brand-kit.apply]', {
      route,
      clientId,
      applied: false,
      reason: 'brand kit not found for client'
    });
    return;
  }

  const typographyDirection = getBrandKitTypographyDirection(brandKit);
  console.info('[brand-kit.apply]', {
    route,
    clientId,
    applied: true,
    brand_name: normalizeWhitespace(brandKit.brand_name || ''),
    typography: normalizeWhitespace(brandKit.typography || ''),
    typography_style_hint: normalizeWhitespace(typographyDirection.style || ''),
    typography_style_source: normalizeWhitespace(brandKit.typography_style_source || typographyDirection.source || ''),
    color_primary: normalizeWhitespace(brandKit.color_primary || '#000000'),
    color_secondary: normalizeWhitespace(brandKit.color_secondary || '#666666'),
    color_accent: normalizeWhitespace(brandKit.color_accent || '#999999'),
    has_logo_dark: Boolean(normalizeWhitespace(brandKit.logo_dark_path || '')),
    has_logo_light: Boolean(normalizeWhitespace(brandKit.logo_light_path || ''))
  });
}

function buildCampaignGenerationPrompt({
  itemPrompt,
  avatarName = '',
  conceptName = '',
  brandKit,
  hasProductImage = false,
  hasStyleReference = true,
  generationStrategy = 'winner_iteration',
  layoutPattern = null,
  styleProfile = null,
  campaignItemIndex = 1,
  toneHint = '',
  offerCta = '',
  campaignGoal = '',
  variationCycle = ''
}) {
  const cleanItemPrompt = normalizeWhitespace(itemPrompt || '');
  const cleanAvatarName = normalizeWhitespace(avatarName || '');
  const cleanConceptName = normalizeWhitespace(conceptName || '');
  const cleanToneHint = normalizeWhitespace(toneHint || '');
  const cleanOfferCta = normalizeWhitespace(offerCta || '');
  const cleanCampaignGoal = normalizeWhitespace(campaignGoal || '');
  const cleanVariationCycle = normalizeWhitespace(variationCycle || '');
  const cleanStrategy = normalizeCampaignGenerationStrategy(generationStrategy);
  const referenceLedTightLayout = hasStyleReference && cleanStrategy === 'winner_iteration';
  const brandContext = buildBrandContextLine(brandKit);
  const brandPriorityLines = buildCampaignBrandPriorityLines(brandKit);

  const normalizedStyleProfile = styleProfile && typeof styleProfile === 'object'
    ? {
      quality_tier: normalizeWhitespace(styleProfile.quality_tier || ''),
      design_aesthetic: normalizeWhitespace(styleProfile.design_aesthetic || ''),
      color_treatment: normalizeWhitespace(styleProfile.color_treatment || ''),
      typography_approach: normalizeWhitespace(styleProfile.typography_approach || ''),
      text_density: normalizeTextDensity(styleProfile.text_density || ''),
      text_pattern: normalizeWhitespace(styleProfile.text_pattern || ''),
      text_overlay_count: Number(styleProfile.text_overlay_count || 0),
      has_prominent_overlay_text: parseBoolean(styleProfile.has_prominent_overlay_text, false)
    }
    : null;

  const styleProfileLine = normalizedStyleProfile
    ? [
      'Reference style profile (visual only):',
      normalizedStyleProfile.quality_tier ? `quality tier: ${normalizedStyleProfile.quality_tier}` : '',
      normalizedStyleProfile.design_aesthetic ? `aesthetic: ${normalizedStyleProfile.design_aesthetic}` : '',
      normalizedStyleProfile.color_treatment ? `color treatment: ${normalizedStyleProfile.color_treatment}` : '',
      normalizedStyleProfile.typography_approach ? `typography approach: ${normalizedStyleProfile.typography_approach}` : '',
      normalizedStyleProfile.text_density ? `text density: ${normalizedStyleProfile.text_density}` : '',
      normalizedStyleProfile.text_pattern ? `text pattern: ${normalizedStyleProfile.text_pattern}` : '',
      Number.isFinite(normalizedStyleProfile.text_overlay_count) ? `text overlays detected: ${normalizedStyleProfile.text_overlay_count}` : '',
      `prominent overlay text: ${normalizedStyleProfile.has_prominent_overlay_text ? 'yes' : 'no'}`
    ].filter(Boolean).join(' ')
    : '';

  const layoutLine = layoutPattern
    ? `Layout direction for this ad (#${campaignItemIndex}): ${layoutPattern.instructions}`
    : '';

    const textOverlayCount = normalizedStyleProfile && Number.isFinite(Number(normalizedStyleProfile.text_overlay_count))
      ? Number(normalizedStyleProfile.text_overlay_count)
      : 0;
    const referenceLooksTextLite = normalizedStyleProfile && (
      normalizeTextDensity(normalizedStyleProfile.text_density) === 'none' ||
      textOverlayCount <= 2
    );
    const textDensity = hasStyleReference
      ? (referenceLooksTextLite
        ? 'none'
        : (normalizedStyleProfile && normalizedStyleProfile.text_density
          ? normalizedStyleProfile.text_density
          : 'low'))
      : (cleanOfferCta ? 'medium' : 'low');
  const textPolicy = getCampaignTextPolicyLines(textDensity);
  const visualSceneDirection = buildAvatarAngleSceneDirection({
    avatarName: cleanAvatarName,
    conceptName: cleanConceptName,
    toneHint: cleanToneHint,
    campaignGoal: cleanCampaignGoal
  });

  const internalOnlyLine = [
    'Internal planning context (never print literally):',
    'Use selected audience, angle, offer, tone, and variation context only to guide scene and composition choices.',
    'Never render planning labels, config keys, framework names, or metadata words as on-image text.'
  ].join(' ');

  const optionalTextLine = cleanOfferCta
    ? `If text policy allows CTA text, prefer a short CTA like "${cleanOfferCta}" (2-3 words max).`
    : '';
  const mandatoryAlignmentLine = (cleanAvatarName || cleanConceptName)
    ? `Mandatory alignment: make avatar "${cleanAvatarName || 'target audience'}" and angle "${cleanConceptName || 'selected concept'}" clearly recognizable through scene, props, and composition.`
    : '';
  const conceptTranslationLine = cleanConceptName
    ? `Concept translation rule: express "${cleanConceptName}" visually; do not rely on printing the raw concept phrase as a label.`
    : '';
  const strategyLine = cleanStrategy === 'product_exploration'
    ? '- Generation strategy: product-led exploration. Prioritize concept diversity while preserving product identity.'
    : '- Generation strategy: winning-ad iteration. Keep the reference ad’s core composition family and visual hierarchy, while updating messaging/scene details for the selected avatar and angle.';
  const productIdentityLines = hasProductImage
    ? [
      '- Product identity must come exclusively from the selected product image.',
      '- Treat the selected product image as an immutable source asset for packaging identity.',
      '- Preserve package silhouette, package colorway, brand mark, front-panel artwork, and printed text exactly.',
      '- Do not recolor, relight, restyle, relabel, or reformat the package artwork.',
      '- Brand palette guidance applies to non-product design elements only, never the package itself.'
    ]
    : ['- Product identity may come from the reference image only because no separate product image was provided.'];
  const styleProfileLineResolved = hasStyleReference ? styleProfileLine : '';

  return [
    'Create a static Meta/Facebook ad.',
    hasStyleReference ? 'Reference image usage policy:' : 'Style direction policy:',
    hasStyleReference
      ? '- Treat reference image as a style guide (quality, aesthetic, visual language), NOT a fixed template.'
      : '- No separate winning style reference was provided for this ad.',
    hasStyleReference
      ? '- Use reference image ONLY for visual style and layout direction.'
      : '- Use brand context, layout direction, and campaign brief as the visual art-direction source.',
    hasStyleReference
      ? '- Ignore all reference-image text content, product claims, category assumptions, and product identity.'
      : '- Do not invent competitor names, unsupported claims, or category assumptions.',
    ...productIdentityLines,
    strategyLine,
    '- Output must read like a conversion-focused Meta ad, not a generic social post.',
    '- Enforce direct-response hierarchy: clear headline zone, product anchor, proof/support element, and CTA zone.',
    ...(referenceLedTightLayout
      ? [
        '- Preserve the reference layout skeleton (headline zone placement, product anchor placement, and callout architecture).',
        '- Keep the same global composition family as the reference; do not introduce unrelated split-screen, before/after, or multi-panel structures unless the reference itself uses them.',
        '- Create variation through audience-specific messaging, props, scene details, and micro-hierarchy, not wholesale layout changes.'
      ]
      : [
        '- Do not replicate the same layout structure for every output in the campaign.',
        '- Vary composition, panel structure, and text placement across ads while preserving brand/style cohesion.'
      ]),
    '- Full-bleed composition requirement: the creative should occupy the full frame.',
    '- Do not render an inset poster/card with large empty border around it.',
    '- Keep outer margins tight and intentional; avoid oversized matte/padding frames.',
    styleProfileLineResolved,
    ...brandPriorityLines,
    layoutLine,
    internalOnlyLine,
    mandatoryAlignmentLine,
    conceptTranslationLine,
    'Avatar and angle must influence SCENE, prop choices, composition, and mood.',
    'Never render avatar labels or angle labels as text overlays.',
    visualSceneDirection,
    'Text-on-image policy:',
    ...textPolicy,
    optionalTextLine,
    'Never place long paragraphs, bullet lists, ingredient lists, or dense body copy as on-image text.',
    'Copy and messaging policy:',
    '- All messaging must follow brand context and campaign brief direction below.',
    '- Do not reproduce competitor messaging from the reference ad.',
    '- If this prompt includes strategic metadata, treat it as planning context, not literal text to print.',
    '- Never print font names, hex color codes, or Brand Kit config labels as on-image copy.',
    '- Never print internal framework/layout labels such as "modular conversion card", "promise/proof/accent", "avatar", "angle", or "variation cycle".',
    brandContext || '',
    cleanItemPrompt ? `Campaign brief direction (internal): ${cleanItemPrompt}` : ''
  ].filter(Boolean).join('\n');
}

const LAYOUT_LIBRARY = {
  ingredient_callout: [
    { key: 'ingredient-badge-ring', name: 'Ingredient Badge Ring', instructions: 'Use a product hero with ingredient/benefit badges arranged around the product in a circular or radial structure.' },
    { key: 'benefit-pill-stack', name: 'Benefit Pill Stack', instructions: 'Use a vertical stack of concise benefit pills beside the product hero with clear iconography.' },
    { key: 'spec-callout-grid', name: 'Spec Callout Grid', instructions: 'Use a modular mini-grid with 3-6 callout blocks that each map to one ingredient/benefit proof point.' }
  ],
  social_proof: [
    { key: 'testimonial-quote-card', name: 'Testimonial Quote Card', instructions: 'Use a quote-led layout with customer proof, trust badge, and supporting product placement.' },
    { key: 'reviews-with-stars', name: 'Star Reviews Layout', instructions: 'Use headline + star-rating trust cluster + short proof snippets, then product/CTA block.' },
    { key: 'community-proof-strip', name: 'Community Proof Strip', instructions: 'Use stacked social-proof snippets (reviews/community stats) with clean product anchoring.' }
  ],
  problem_solution: [
    { key: 'split-problem-solution', name: 'Split Problem/Solution', instructions: 'Use a left-right split where pain state and relief state are clearly contrasted.' },
    { key: 'before-after-panel', name: 'Before/After Panel', instructions: 'Use a structured before/after narrative with clear transformation markers.' },
    { key: 'pain-to-relief-timeline', name: 'Pain-to-Relief Timeline', instructions: 'Use a 2-3 step visual progression from problem to outcome with CTA at end.' }
  ],
  comparison: [
    { key: 'us-vs-them-table', name: 'Us vs Them Table', instructions: 'Use a side-by-side comparison table with check/cross indicators and a clear winner frame.' },
    { key: 'competitive-checklist', name: 'Competitive Checklist', instructions: 'Use checklist-style comparison blocks emphasizing differentiators and value.' },
    { key: 'old-way-new-way', name: 'Old Way / New Way', instructions: 'Use old-way vs new-way framing with strong contrast in outcomes and effort level.' }
  ],
  lifestyle: [
    { key: 'full-bleed-lifestyle', name: 'Full-Bleed Lifestyle', instructions: 'Use a full-bleed lifestyle scene with concise overlay copy and subtle product integration.' },
    { key: 'editorial-lifestyle', name: 'Editorial Lifestyle', instructions: 'Use editorial composition with generous whitespace and premium typography hierarchy.' },
    { key: 'moment-in-use', name: 'Moment-in-Use', instructions: 'Use an in-context product-use moment with emotionally resonant headline framing.' }
  ],
  audience_grid: [
    { key: 'multi-segment-grid', name: 'Multi-Segment Grid', instructions: 'Use a multi-panel grid highlighting different audience segments/use cases in one cohesive ad.' },
    { key: 'persona-carousel-static', name: 'Persona Panels', instructions: 'Use stacked persona panels that each map to one mini-benefit and one audience state.' },
    { key: 'use-case-collage', name: 'Use-Case Collage', instructions: 'Use a collage layout with 3-4 use cases and one unifying value proposition headline.' }
  ],
  offer_urgency: [
    { key: 'offer-hero-banner', name: 'Offer Hero Banner', instructions: 'Use a bold offer-led headline with urgency badge and a high-contrast CTA zone.' },
    { key: 'countdown-offer-card', name: 'Countdown Offer Card', instructions: 'Use a promotional card layout with urgency framing and clear redemption CTA.' },
    { key: 'value-stack-offer', name: 'Value Stack Offer', instructions: 'Use stacked value blocks showing what is included and why the offer is compelling now.' }
  ],
  product_hero: [
    { key: 'centered-product-hero', name: 'Centered Product Hero', instructions: 'Use a centered product composition with strong headline and minimal supporting callouts.' },
    { key: 'product-pedestal', name: 'Product Pedestal', instructions: 'Use a clean pedestal-style product spotlight with premium visual hierarchy.' },
    { key: 'hero-plus-support', name: 'Hero + Supporting Benefits', instructions: 'Use one dominant product hero plus compact supporting benefit badges.' }
  ],
  default: [
    { key: 'balanced-dr-layout', name: 'Balanced Direct-Response', instructions: 'Use a balanced direct-response composition with clear hierarchy, proof cues, and CTA block.' },
    { key: 'headline-product-cta', name: 'Headline/Product/CTA', instructions: 'Use a classic headline-first layout, mid-frame product anchor, and distinct CTA footer.' },
    { key: 'modular-conversion-card', name: 'Modular Conversion Card', instructions: 'Use modular blocks for primary claim, supporting evidence, product, and CTA with clear scanning flow.' }
  ]
};

function hashStringToInt(value) {
  const str = String(value || '');
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function detectLayoutFamily(conceptName) {
  const angle = String(conceptName || '').toLowerCase();
  if (/ingredient|benefit|feature|callout|proof\s*point/.test(angle)) return 'ingredient_callout';
  if (/social proof|testimonial|review|rating|community|ugc/.test(angle)) return 'social_proof';
  if (/problem|solution|before|after|pain|relief|transform/.test(angle)) return 'problem_solution';
  if (/\b(no more|without|instead of|replace|swap)\b/.test(angle)) return 'comparison';
  if (/compare|comparison|vs|versus|us\s*vs\s*them|old way|new way/.test(angle)) return 'comparison';
  if (/lifestyle|day in the life|routine|moment|editorial/.test(angle)) return 'lifestyle';
  if (/all types|all kinds|for everyone|segments|segment|persona|audience/.test(angle)) return 'audience_grid';
  if (/offer|discount|deal|limited|urgent|urgency|cta|price|value/.test(angle)) return 'offer_urgency';
  if (/hero|product focus|product showcase|minimal/.test(angle)) return 'product_hero';
  return 'default';
}

function chooseLayoutPattern({ conceptName, avatarName, itemIndex, usedLayoutCounts }) {
  const family = detectLayoutFamily(conceptName);
  const options = LAYOUT_LIBRARY[family] || LAYOUT_LIBRARY.default;
  if (!Array.isArray(options) || options.length === 0) {
    return { key: 'fallback-balanced', name: 'Balanced Direct-Response', instructions: 'Use a clear conversion-focused hierarchy with distinct CTA placement.' };
  }

  const minUsage = options.reduce((min, option) => {
    const current = Number(usedLayoutCounts[option.key] || 0);
    return Math.min(min, current);
  }, Number.POSITIVE_INFINITY);

  const leastUsed = options.filter((option) => Number(usedLayoutCounts[option.key] || 0) === minUsage);
  const seed = `${conceptName || ''}|${avatarName || ''}|${itemIndex}`;
  const pickIndex = hashStringToInt(seed) % leastUsed.length;
  const picked = leastUsed[pickIndex];
  usedLayoutCounts[picked.key] = Number(usedLayoutCounts[picked.key] || 0) + 1;
  return picked;
}

function normalizeTextDensity(value) {
  const raw = normalizeWhitespace(String(value || '')).toLowerCase();
  if (!raw) return '';
  if (['none', 'no text', 'zero', 'text-free', 'text free'].includes(raw)) return 'none';
  if (['low', 'minimal', 'light', 'sparse'].includes(raw)) return 'low';
  if (['medium', 'moderate'].includes(raw)) return 'medium';
  if (['high', 'heavy', 'text-heavy', 'dense'].includes(raw)) return 'high';
  if (raw.includes('no') && raw.includes('text')) return 'none';
  if (raw.includes('minimal') || raw.includes('sparse')) return 'low';
  if (raw.includes('moderate')) return 'medium';
  if (raw.includes('dense') || raw.includes('heavy')) return 'high';
  return 'low';
}

function deriveTextDensityFromSignals({ rawDensity, overlayCount, hasProminentOverlay }) {
  const normalized = normalizeTextDensity(rawDensity || '');
  if (normalized === 'none') {
    return 'none';
  }
  const count = Number(overlayCount);
  const prominent = Boolean(hasProminentOverlay);
  if (Number.isFinite(count)) {
    // Bias toward less text. Many references include packaging text that can be
    // misread as overlay copy, so small counts should default to text-free.
    if (count <= 2) return 'none';
    if (count <= 5) return 'low';
    if (count <= 8) return 'medium';
    return 'high';
  }
  if (normalized) {
    return normalized;
  }
  return prominent ? 'low' : 'none';
}

function getCampaignTextPolicyLines(textDensity) {
  const density = normalizeTextDensity(textDensity || 'low');
  if (density === 'none') {
    return [
      '- STRICT text-free mode: do not place any headline, tagline, CTA, badge copy, or decorative text overlay.',
      '- Allow only existing product-packaging text/logo marks that are part of the product image.',
      '- No headline, no subheadline, no bullet list, no CTA text, and no extra typography blocks anywhere in frame.'
    ];
  }
  if (density === 'low') {
    return [
      '- Prefer text-free output. If text is used, limit to one very short headline only.',
      '- No CTA button text, no subheadline, no badges with words, no bullet lists.',
      '- Keep all messaging primarily visual via scene composition and props.'
    ];
  }
  if (density === 'medium') {
    return [
      '- Keep text concise: at most 1 short headline (<= 5 words) and 1 short supporting line.',
      '- Optional CTA of 2-3 words.',
      '- No bullet lists, no paragraph blocks, no dense copy.'
    ];
  }
  if (density === 'high') {
    return [
      '- Text-heavy reference detected, but keep output readable.',
      '- At most 1 headline, up to 2 short callouts, and 1 concise CTA.',
      '- Avoid large body paragraphs and long bullet stacks.'
    ];
  }
  return [
    '- Keep text minimal by default.',
    '- Prefer no text unless composition requires it.',
    '- At most 1 short headline (<= 5 words), optional CTA (2-3 words).',
    '- No bullet lists, no subhead paragraphs, no dense copy.'
  ];
}

function buildAvatarAngleSceneDirection({ avatarName, conceptName, toneHint, campaignGoal }) {
  const avatarRaw = normalizeWhitespace(avatarName || '');
  const conceptRaw = normalizeWhitespace(conceptName || '');
  const avatar = avatarRaw.toLowerCase();
  const concept = conceptRaw.toLowerCase();
  const tone = normalizeWhitespace(toneHint || '').toLowerCase();
  const goal = normalizeWhitespace(campaignGoal || '');

  const sceneCues = [];
  if (avatar.includes('busy') || avatar.includes('professional')) sceneCues.push('use a fast-paced practical environment (desk, commute, kitchen counter, on-the-go context)');
  if (avatar.includes('mom') || avatar.includes('parent') || avatar.includes('family')) sceneCues.push('use family-life context props and realistic household moments');
  if (avatar.includes('student') || avatar.includes('college')) sceneCues.push('use study/workstation cues (notebooks, laptop, desk lighting)');
  if (avatar.includes('fitness') || avatar.includes('athlete') || avatar.includes('gym')) sceneCues.push('use fitness-adjacent props and active lifestyle cues');
  if (avatar.includes('wellness') || avatar.includes('health')) sceneCues.push('use clean wellness-oriented styling and natural ingredient cues');
  if (avatarRaw) {
    sceneCues.push(`make audience context for "${avatarRaw}" obvious through setting, props, and subject styling`);
  }

  const angleCues = [];
  if (concept.includes('ingredient') || concept.includes('benefit') || concept.includes('feature')) angleCues.push('show ingredients/benefits visually through product-adjacent objects and iconography, not text lists');
  if (concept.includes('social proof') || concept.includes('testimonial') || concept.includes('review')) angleCues.push('include trust signals visually (rating motifs, testimonial card feel) with minimal text');
  if (concept.includes('problem') || concept.includes('solution') || concept.includes('before') || concept.includes('after')) angleCues.push('use visual contrast in mood/props/states to imply pain vs relief without heavy copy, while preserving the reference layout family');
  if (concept.includes('comparison') || concept.includes('vs') || concept.includes('versus')) angleCues.push('use comparative visual framing and side-by-side structure, avoid dense comparison text');
  if (concept.includes('lifestyle') || concept.includes('routine')) angleCues.push('prioritize full-scene lifestyle storytelling with product integrated naturally');
  if (concept.includes('dessert') || concept.includes('indulgence') || concept.includes('treat')) angleCues.push('use indulgent food styling and appetizing ingredient arrangement to imply the angle visually');
  if (concept.includes('hero') || concept.includes('showcase')) angleCues.push('use a clean product-hero composition with strong negative space');
  const noMoreMatch = conceptRaw.match(/\bno\s+more\s+([a-z0-9][a-z0-9\s-]{1,40})/i);
  if (noMoreMatch) {
    const deprecatedThing = normalizeWhitespace(noMoreMatch[1]);
    angleCues.push(`treat this as a replacement contrast: the desired state should avoid "${deprecatedThing}" and visually communicate an easier alternative`);
  }
  if (conceptRaw) {
    angleCues.push(`translate angle "${conceptRaw}" into concrete scene/prop choices so the concept is obvious without relying on label text`);
  }

  if (tone.includes('minimal')) sceneCues.push('favor whitespace, simple object count, and restrained overlays');
  if (tone.includes('bold')) sceneCues.push('use strong contrast and clear focal hierarchy');
  if (tone.includes('editorial')) sceneCues.push('use premium editorial composition and controlled typography');
  if (tone.includes('playful')) sceneCues.push('use friendly, lively props and motion-implying arrangement');

  const parts = [
    sceneCues.length ? `Avatar-driven scene cues: ${sceneCues.join('; ')}.` : '',
    angleCues.length ? `Angle-driven concept cues: ${angleCues.join('; ')}.` : '',
    goal ? `Campaign goal alignment: ${goal}.` : ''
  ].filter(Boolean);

  if (parts.length === 0) {
    return 'Use avatar and angle as internal strategy context to vary scene composition and prop styling, not text overlays.';
  }
  return parts.join(' ');
}

async function analyzeReferenceStyleProfile(referenceAbsPath) {
  // Vision inference is intentionally disabled; use deterministic defaults.
  // Keep signature for compatibility with existing generation pipeline.
  void referenceAbsPath;
  return {
    quality_tier: 'polished direct-response',
    design_aesthetic: 'clean conversion-focused composition',
    color_treatment: 'high-contrast brand-forward palette',
    typography_approach: 'clear headline hierarchy with conversion callouts',
    text_density: 'none',
    text_pattern: 'no overlay text; packaging text only',
    text_overlay_count: 0,
    has_prominent_overlay_text: false
  };
}

async function uploadToFal(localPath) {
  configureFal();
  const fileBuffer = fs.readFileSync(localPath);
  const file = new File([fileBuffer], path.basename(localPath), {
    type: getMimeTypeFromPath(localPath)
  });
  return fal.storage.upload(file);
}

async function downloadFalImage(imageUrl, prefix = 'generated') {
  const response = await fetch(imageUrl);
  if (!response.ok) {
    throw new Error(`Failed to download generated image (${response.status})`);
  }

  const ext = getExtensionFromContentType(response.headers.get('content-type'));
  const filename = `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
  const absOutputPath = path.join(GENERATED_DIR, filename);
  const bytes = Buffer.from(await response.arrayBuffer());

  fs.writeFileSync(absOutputPath, bytes);
  return toPublicPath(absOutputPath);
}

async function runFalGeneration({ imagePaths, prompt, numImages, aspectRatio, resolution }) {
  configureFal();
  const safeImagePaths = Array.isArray(imagePaths) ? imagePaths.filter(Boolean) : [];
  if (safeImagePaths.length === 0) {
    throw new Error('No reference images provided to generation call.');
  }

  const uploadedImageUrls = await Promise.all(safeImagePaths.map((imagePath) => uploadToFal(imagePath)));

  const result = await fal.subscribe('fal-ai/nano-banana-pro/edit', {
    input: {
      prompt,
      image_urls: uploadedImageUrls,
      num_images: Math.max(1, Math.min(Number(numImages) || 1, 4)),
      aspect_ratio: aspectRatio || '1:1',
      output_format: 'png',
      resolution: resolution || '1K',
      safety_tolerance: 4
    }
  });

  const payload = result && result.data ? result.data : result;
  const images = Array.isArray(payload && payload.images) ? payload.images : [];

  if (images.length === 0) {
    throw new Error('FAL did not return any images.');
  }

  const generatedPaths = (
    await Promise.all(images.map(async (image) => {
      const imageUrl = typeof image === 'string' ? image : image.url;
      if (!imageUrl) return null;
      return await downloadFalImage(imageUrl);
    }))
  ).filter(Boolean);

  if (generatedPaths.length === 0) {
    throw new Error('Unable to persist generated images.');
  }

  return generatedPaths;
}

async function withTimeout(promise, timeoutMs, label = 'Operation') {
  const ms = Math.max(1000, Number(timeoutMs) || 60000);
  let timer = null;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          reject(new Error(`${label} timed out after ${ms}ms.`));
        }, ms);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function saveGenerationRecord({
  clientId,
  referenceImagePath,
  productImagePath,
  prompt,
  conceptName,
  avatarName,
  size,
  usedBrandKit,
  generatedImages,
  status
}) {
  const normalizedConceptName = normalizeWhitespace(conceptName || '') || extractGenerationConcept(prompt || '');
  const normalizedAvatarName = normalizeWhitespace(avatarName || '') || extractGenerationAvatar(prompt || '');
  const normalizedGeneratedImages = normalizeGeneratedImageEntries(
    generatedImages,
    normalizedConceptName,
    normalizedAvatarName
  );
  const inserted = await executeQuery(`
    INSERT INTO generations (
      client_id,
      reference_image_path,
      product_image_path,
      prompt,
      concept_name,
      avatar_name,
      size,
      used_brand_kit,
      generated_images,
      status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    RETURNING id
  `, [
    clientId,
    referenceImagePath || null,
    productImagePath || null,
    prompt,
    normalizedConceptName || null,
    normalizedAvatarName || null,
    size || '1:1',
    usedBrandKit ? 1 : 0,
    JSON.stringify(normalizedGeneratedImages),
    status || 'completed'
  ]);

  const insertedId = inserted && inserted.rows && inserted.rows[0] ? Number(inserted.rows[0].id) : null;
  const row = await dbGet('SELECT * FROM generations WHERE id = ? AND client_id = ?', [insertedId, clientId]);
  return parseGenerationRow(row);
}

function toAssetResponse(row) {
  const normalizedCategory = normalizeAssetCategory(row.category, 'Other');
  return {
    ...row,
    category: ASSET_CATEGORY_OPTIONS.includes(normalizedCategory) ? normalizedCategory : 'Other',
    file_size: Number(row.file_size || 0)
  };
}

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

ensureDirectories();

app.use(express.json({ limit: '4mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOADS_DIR));
app.use(express.static(PUBLIC_DIR));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/api/clients', asyncHandler(async (_req, res) => {
  res.json({ clients: await listClients(), defaultClientId: await getDefaultClientId() });
}));

app.post('/api/clients', asyncHandler(async (req, res) => {
  const name = normalizeClientName(req.body.name);
  if (!name) {
    res.status(400).json({ error: 'Client name is required.' });
    return;
  }

  const slug = slugify(name) || `client-${Date.now()}`;
  const existing = await dbGet('SELECT id FROM clients WHERE lower(name) = lower(?) OR slug = ?', [name, slug]);
  if (existing) {
    res.status(409).json({ error: 'A client with that name already exists.' });
    return;
  }

  const inserted = await executeQuery(`
    INSERT INTO clients (name, slug, is_default, created_at, updated_at)
    VALUES (?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    RETURNING id
  `, [name, slug]);

  const clientId = Number(inserted.rows[0].id);
  await ensureBrandKitRecord(clientId);
  res.status(201).json({
    client: await getClientById(clientId),
    clients: await listClients()
  });
}));

app.patch('/api/clients/:id', asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) {
    res.status(400).json({ error: 'Valid client id is required.' });
    return;
  }

  const existing = await getClientById(id);
  if (!existing) {
    res.status(404).json({ error: 'Client not found.' });
    return;
  }

  const name = normalizeClientName(req.body.name);
  if (!name) {
    res.status(400).json({ error: 'Client name is required.' });
    return;
  }

  const slug = slugify(name) || `client-${id}`;
  const conflict = await dbGet(
    'SELECT id FROM clients WHERE id != ? AND (lower(name) = lower(?) OR slug = ?)',
    [id, name, slug]
  );
  if (conflict) {
    res.status(409).json({ error: 'A client with that name already exists.' });
    return;
  }

  await executeQuery(`
    UPDATE clients
    SET name = ?, slug = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `, [name, slug, id]);

  res.json({
    client: await getClientById(id),
    clients: await listClients()
  });
}));

app.delete('/api/clients/:id', asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) {
    res.status(400).json({ error: 'Valid client id is required.' });
    return;
  }

  const existing = await getClientById(id);
  if (!existing) {
    res.status(404).json({ error: 'Client not found.' });
    return;
  }

  const allClients = await dbAll('SELECT id, is_default FROM clients ORDER BY id ASC');
  if (allClients.length <= 1) {
    res.status(400).json({ error: 'You must keep at least one client.' });
    return;
  }

  const remainingClients = allClients.filter((row) => Number(row.id) !== id);
  const currentDefault = allClients.find((row) => Number(row.is_default) === 1);
  let nextDefaultId = currentDefault ? Number(currentDefault.id) : 0;
  if (!remainingClients.some((row) => Number(row.id) === nextDefaultId)) {
    nextDefaultId = Number(remainingClients[0].id);
  }

  const uploadPaths = await collectClientUploadPaths(id);

  await withDbTransaction(async (tx) => {
    await tx.query('DELETE FROM campaign_tags WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM brand_intelligence WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM generations WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM assets WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM templates WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM brand_kits WHERE client_id = ?', [id]);
    await tx.query('DELETE FROM clients WHERE id = ?', [id]);
    await tx.query('UPDATE clients SET is_default = CASE WHEN id = ? THEN 1 ELSE 0 END', [nextDefaultId]);
  });

  for (const publicPath of uploadPaths) {
    // Best-effort cleanup for orphaned uploads.
    await deleteUploadFileIfUnreferenced(publicPath);
  }

  res.json({
    ok: true,
    deletedClientId: id,
    defaultClientId: nextDefaultId,
    clients: await listClients()
  });
}));

app.get('/api/brand-kit', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  res.json({ brandKit: await getBrandKit(clientId), clientId });
}));

app.post('/api/brand-kit', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const payload = {
    brand_name: req.body.brandName || req.body.brand_name || null,
    brand_description: req.body.brandDescription || req.body.brand_description || null,
    typography: req.body.typography || null,
    color_primary: req.body.colorPrimary || req.body.color_primary || '#000000',
    color_secondary: req.body.colorSecondary || req.body.color_secondary || '#666666',
    color_accent: req.body.colorAccent || req.body.color_accent || '#999999'
  };

  await ensureBrandKitRecord(clientId);
  await executeQuery(`
    INSERT INTO brand_kits (
      client_id, brand_name, brand_description, typography, color_primary, color_secondary, color_accent, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    ON CONFLICT(client_id) DO UPDATE SET
      brand_name = excluded.brand_name,
      brand_description = excluded.brand_description,
      typography = excluded.typography,
      color_primary = excluded.color_primary,
      color_secondary = excluded.color_secondary,
      color_accent = excluded.color_accent,
      updated_at = CURRENT_TIMESTAMP
  `, [
    clientId,
    payload.brand_name,
    payload.brand_description,
    payload.typography,
    payload.color_primary,
    payload.color_secondary,
    payload.color_accent
  ]);

  res.json({ brandKit: await getBrandKit(clientId), clientId });
}));

app.post('/api/brand-kit/logo', brandUpload.single('logo'), asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  if (!req.file) {
    res.status(400).json({ error: 'Logo file is required.' });
    return;
  }

  const variant = req.body.variant === 'light' ? 'light' : 'dark';
  const column = variant === 'light' ? 'logo_light_path' : 'logo_dark_path';
  const logoPath = toPublicPath(req.file.path);

  const current = await getBrandKit(clientId);
  const previousPath = current ? current[column] : null;

  await ensureBrandKitRecord(clientId);
  await executeQuery(`UPDATE brand_kits SET ${column} = ?, updated_at = CURRENT_TIMESTAMP WHERE client_id = ?`, [logoPath, clientId]);

  if (previousPath && previousPath !== logoPath) {
    const oldAbsolute = path.resolve(PUBLIC_DIR, previousPath.replace(/^\/+/, ''));
    if (oldAbsolute.startsWith(PUBLIC_DIR) && fs.existsSync(oldAbsolute)) {
      fs.unlinkSync(oldAbsolute);
    }
  }

  res.json({ brandKit: await getBrandKit(clientId), uploadedPath: logoPath, variant, clientId });
}));

app.delete('/api/brand-kit', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const existing = await getBrandKit(clientId);
  const candidateLogoPaths = [
    normalizeWhitespace(existing && existing.logo_dark_path ? existing.logo_dark_path : ''),
    normalizeWhitespace(existing && existing.logo_light_path ? existing.logo_light_path : '')
  ].filter((pathValue) => isUploadPublicPath(pathValue));

  let clearedProfiles = 0;
  await withDbTransaction(async (tx) => {
    await ensureBrandKitRecord(clientId, tx);
    const deletedProfiles = await tx.query('DELETE FROM brand_intelligence WHERE client_id = ? RETURNING id', [clientId]);
    clearedProfiles = Number(deletedProfiles && deletedProfiles.rowCount || 0);
    await tx.query('DELETE FROM campaign_tags WHERE client_id = ?', [clientId]);
    await tx.query(`
      UPDATE brand_kits
      SET
        brand_name = NULL,
        brand_description = NULL,
        intelligence_research_text = NULL,
        typography = NULL,
        color_primary = '#0f172a',
        color_secondary = '#334155',
        color_accent = '#10b981',
        logo_dark_path = NULL,
        logo_light_path = NULL,
        updated_at = CURRENT_TIMESTAMP
      WHERE client_id = ?
    `, [clientId]);
  });

  for (const publicPath of candidateLogoPaths) {
    await deleteUploadFileIfUnreferenced(publicPath);
  }

  res.json({
    ok: true,
    clientId,
    clearedProfiles,
    brandKit: await getBrandKit(clientId)
  });
}));

app.get('/api/brand/intelligence', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const items = await listBrandIntelligence(clientId);
  const researchText = await getBrandIntelligenceResearchText(clientId);
  res.json({ clientId, items, researchText });
}));

app.post('/api/brand/intelligence/research', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const researchText = await saveBrandIntelligenceResearchText(
    clientId,
    req.body && Object.prototype.hasOwnProperty.call(req.body, 'researchText')
      ? req.body.researchText
      : (req.body && (req.body.context || req.body.report || ''))
  );
  res.json({ clientId, researchText });
}));

app.post('/api/brand/intelligence/generate', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const requestedCount = Math.max(3, Math.min(Number(req.body.count) || 10, 20));
  const hasResearchTextField = Boolean(req.body && Object.prototype.hasOwnProperty.call(req.body, 'researchText'));
  const incomingResearchText = normalizeResearchText(
    hasResearchTextField
      ? req.body.researchText
      : (req.body.researchText || req.body.context || req.body.report || '')
  );
  let persistedResearchText = await getBrandIntelligenceResearchText(clientId);
  // Guardrail: generation should not clear saved research if the incoming field is blank.
  if (incomingResearchText) {
    persistedResearchText = await saveBrandIntelligenceResearchText(clientId, incomingResearchText);
  }
  const researchText = incomingResearchText || persistedResearchText;
  const brandKit = await getBrandKit(clientId);
  const brandName = normalizeWhitespace(brandKit && brandKit.brand_name);
  const brandDescription = normalizeWhitespace(brandKit && brandKit.brand_description);

  const trainingContext = [
    brandName ? `Brand name: ${brandName}` : '',
    brandDescription ? `Brand context from setup: ${brandDescription}` : '',
    researchText ? `Student research notes: ${researchText}` : ''
  ].filter(Boolean).join('\n');

  if (!trainingContext) {
    res.status(400).json({ error: 'Add brand description or provide research text first.' });
    return;
  }

  let normalized = null;
  let modelLabel = 'deterministic-brand-intelligence-v1';
  let usedModelOutput = false;

  if (getGeminiApiKey()) {
    try {
      const response = await callGeminiGenerateContent({
        system: [
          'You are a direct-response creative strategist for Meta static ads.',
          'Turn brand research into actionable persona-level creative angles.',
          'Return JSON only.'
        ].join(' '),
        userPrompt: [
          'Create structured ad planning cards from this training context.',
          `Output exactly ${requestedCount} items.`,
          'Each item must be materially distinct.',
          'Return ONLY valid JSON with exactly this shape:',
          '{"items":[{"persona":"string","pain_point":"string","angle":"string","visual_direction":"string","emotion":"string","copy_hook":"string"}],"rationale":"string"}',
          'Do not include markdown or extra keys.',
          `Training context:\n${trainingContext}`
        ].join('\n'),
        maxTokens: 4096,
        temperature: 0.3,
        thinkingBudget: 256
      });
      const parsed = extractJsonObjectFromText(response.text);
      normalized = normalizeBrandIntelligenceResponse(parsed, response.text, requestedCount);
      usedModelOutput = Boolean(normalized && Number(normalized.modelItemsCount) > 0);
      modelLabel = usedModelOutput
        ? (response.model || modelLabel)
        : 'deterministic-brand-intelligence-v1';
    } catch (error) {
      console.warn('[brand.intelligence] gemini generation failed; using deterministic fallback', {
        error: normalizeWhitespace(error && error.message) || 'Unknown brand intelligence generation error.'
      });
    }
  }

  if (!normalized) {
    normalized = normalizeBrandIntelligenceResponse({
      rationale: 'Deterministic fallback generated from brand setup context.'
    }, trainingContext, requestedCount);
  }

  const sourceLabel = modelLabel.startsWith('deterministic-') || !usedModelOutput
    ? 'deterministic'
    : 'ai';
  const items = await replaceBrandIntelligence(clientId, normalized.items, sourceLabel);

  res.json({
    clientId,
    model: modelLabel,
    rationale: normalized.rationale || '',
    items,
    researchText: persistedResearchText
  });
}));

app.post('/api/brand/intelligence/item', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const { item, error } = await createBrandIntelligenceItem(
    clientId,
    req.body || {},
    'manual'
  );
  if (error) {
    res.status(400).json({ error });
    return;
  }
  res.status(201).json({
    clientId,
    item,
    items: await listBrandIntelligence(clientId)
  });
}));

app.patch('/api/brand/intelligence/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const profileId = Number(req.params.id);
  if (!Number.isFinite(profileId) || profileId <= 0) {
    res.status(400).json({ error: 'Valid profile id is required.' });
    return;
  }

  const { item, error } = await updateBrandIntelligenceItem(clientId, profileId, req.body || {});
  if (error) {
    res.status(error === 'Profile not found.' ? 404 : 400).json({ error });
    return;
  }

  res.json({
    clientId,
    item,
    items: await listBrandIntelligence(clientId)
  });
}));

app.delete('/api/brand/intelligence/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const profileId = Number(req.params.id);
  if (!Number.isFinite(profileId) || profileId <= 0) {
    res.status(400).json({ error: 'Valid profile id is required.' });
    return;
  }

  const deleted = await deleteBrandIntelligenceItem(clientId, profileId);
  if (!deleted) {
    res.status(404).json({ error: 'Profile not found.' });
    return;
  }

  res.json({
    clientId,
    deletedId: profileId,
    items: await listBrandIntelligence(clientId)
  });
}));

app.post('/api/prompt/compose', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const referenceImagePath = String(req.body.referenceImagePath || '').trim();
  const productImagePath = String(req.body.productImagePath || '').trim();
  const intelligenceId = Number(req.body.intelligenceId);
  const extraInstructions = normalizeWhitespace(
    req.body.extraInstructions
    || req.body.specificRequest
    || req.body.promptContext
    || ''
  );
  const useBrandKit = parseBoolean(req.body.useBrandKit, false);
  const offerCta = normalizeWhitespace(req.body.offerCta || '').slice(0, 80);
  const campaignGoal = normalizeWhitespace(req.body.campaignGoal || '').slice(0, 120);

  if (!referenceImagePath || !productImagePath) {
    res.status(400).json({ error: 'referenceImagePath and productImagePath are required.' });
    return;
  }

  const referenceAbsPath = resolveUploadPath(referenceImagePath);
  const productAbsPath = resolveUploadPath(productImagePath);

  let selected = null;
  if (Number.isFinite(intelligenceId) && intelligenceId > 0) {
    const row = await dbGet(
      'SELECT * FROM brand_intelligence WHERE id = ? AND client_id = ?',
      [intelligenceId, clientId]
    );
    selected = parseBrandIntelligenceRow(row);
  }

  if (!selected) {
    const inline = req.body.intelligence && typeof req.body.intelligence === 'object'
      ? req.body.intelligence
      : req.body;
    const persona = normalizeBrandIntelligenceField(inline.persona || inline.avatar, 120);
    const angle = normalizeBrandIntelligenceField(inline.angle || inline.concept, 220);
    if (persona || angle) {
      selected = {
        id: null,
        persona: persona || 'Target audience',
        pain_point: normalizeBrandIntelligenceField(inline.pain_point || inline.painPoint || inline.pain, 220),
        angle: angle || 'Benefit-forward conversion framing',
        visual_direction: normalizeBrandIntelligenceField(inline.visual_direction || inline.visual || inline.scene, 220),
        emotion: normalizeBrandIntelligenceField(inline.emotion, 120),
        copy_hook: normalizeBrandIntelligenceField(inline.copy_hook || inline.copyHook, 220)
      };
    }
  }

  if (!selected) {
    const mostRecent = await dbGet(
      'SELECT * FROM brand_intelligence WHERE client_id = ? ORDER BY created_at DESC, id DESC LIMIT 1',
      [clientId]
    );
    selected = parseBrandIntelligenceRow(mostRecent);
  }

  if (!selected || (!selected.persona && !selected.angle)) {
    res.status(400).json({ error: 'Select a brand intelligence profile (persona/angle) first.' });
    return;
  }

  const rawBrandKit = useBrandKit ? await getBrandKit(clientId) : null;
  const brandKit = rawBrandKit ? await hydrateBrandKitTypographyStyle(rawBrandKit) : null;
  const intelligenceLibrary = await listBrandIntelligence(clientId);
  const intelligenceResearchText = await getBrandIntelligenceResearchText(clientId);
  const layoutPattern = null;
  const styleProfile = await analyzeReferenceStyleProfile(referenceAbsPath);

  const deterministicPrompt = buildCampaignGenerationPrompt({
    itemPrompt: [
      selected.pain_point ? `Core pain point: ${selected.pain_point}.` : '',
      selected.angle ? `Messaging angle: ${selected.angle}.` : '',
      selected.emotion ? `Target emotion: ${selected.emotion}.` : '',
      extraInstructions ? `Additional instructions: ${extraInstructions}.` : '',
      'Ensure all messaging aligns with the selected product and customer pain point.',
      'Use the winning reference for visual style/composition only; do not copy literal competitor text.'
    ].filter(Boolean).join(' '),
    avatarName: selected.persona || 'Target audience',
    conceptName: selected.angle || 'Conversion angle',
    brandKit,
    hasProductImage: true,
    hasStyleReference: true,
    generationStrategy: 'winner_iteration',
    layoutPattern,
    styleProfile,
    campaignItemIndex: 1,
    toneHint: selected.emotion || '',
    offerCta,
    campaignGoal,
    variationCycle: ''
  });

  let composedPrompt = deterministicPrompt;
  let rationale = 'Prompt composed from brand intelligence + reference style constraints.';
  let modelLabel = 'deterministic-prompt-composer-v1';
  let referenceBlueprint = null;

  if (getGeminiApiKey()) {
    try {
      const blueprintResult = await extractReferenceBlueprintWithGemini(referenceAbsPath);
      if (blueprintResult.enabled && blueprintResult.blueprint) {
        referenceBlueprint = blueprintResult.blueprint;
      }
    } catch (error) {
      console.warn('[prompt.compose] reference blueprint extraction failed; continuing without blueprint', {
        error: normalizeWhitespace(error && error.message) || 'Unknown reference blueprint error.'
      });
    }
  }

  if (getGeminiApiKey()) {
    try {
      const composition = await composeNanoBananaPromptWithGemini({
        productAbsPath,
        referenceAbsPath,
        referenceBlueprint,
        avatarName: selected.persona || '',
        conceptName: selected.angle || '',
        toneHint: selected.emotion || '',
        offerCta,
        campaignGoal,
        variationCycle: '',
        extraInstructions,
        brandKit,
        selectedProfile: selected,
        brandProfiles: intelligenceLibrary,
        researchText: intelligenceResearchText
      });
      if (composition.enabled && composition.prompt) {
        composedPrompt = composition.prompt;
        rationale = normalizeWhitespace(composition.rationale || '') || rationale;
        modelLabel = composition.model || modelLabel;
      }
    } catch (error) {
      console.warn('[prompt.compose] gemini composition failed; using deterministic prompt', {
        error: normalizeWhitespace(error && error.message) || 'Unknown prompt compose error.'
      });
    }
  }

  res.json({
    clientId,
    model: modelLabel,
      prompt: composedPrompt,
      rationale,
      referenceImagePath,
      productImagePath,
      referenceBlueprint,
      intelligence: {
      id: selected.id || null,
      persona: selected.persona || '',
      pain_point: selected.pain_point || '',
      angle: selected.angle || '',
      visual_direction: selected.visual_direction || '',
      emotion: selected.emotion || '',
      copy_hook: selected.copy_hook || ''
    }
  });
}));

app.get('/api/templates', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const category = String(req.query.category || '').trim();
  const favoritesOnly = parseBoolean(req.query.favorites, false);

  const where = ['client_id = ?'];
  const params = [clientId];

  if (category) {
    where.push('category = ?');
    params.push(category);
  }

  if (favoritesOnly) {
    where.push('is_favorite = 1');
  }

  const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
  const rows = (await dbAll(`SELECT * FROM templates ${whereClause} ORDER BY is_favorite DESC, id ASC`, params))
    .map(parseTemplateRow);
  res.json({ templates: rows, clientId });
}));

app.post('/api/templates/upload', templateUpload.single('template'), asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  if (!req.file) {
    res.status(400).json({ error: 'Template file is required.' });
    return;
  }

  const expectedAbsolutePath = path.join(TEMPLATE_DIR, req.file.filename);
  const fallbackAbsolutePath = String(req.file.path || '');
  const savedAbsolutePath = fs.existsSync(expectedAbsolutePath)
    ? expectedAbsolutePath
    : (fallbackAbsolutePath && fs.existsSync(fallbackAbsolutePath) ? fallbackAbsolutePath : '');

  if (!savedAbsolutePath) {
    throw new Error('Uploaded template file could not be found on disk.');
  }

  // Store a stable upload URL that always maps to the template upload directory.
  const templateImagePath = `/uploads/templates/${path.basename(savedAbsolutePath)}`;
  const fallbackName = path.basename(req.file.originalname || req.file.filename, path.extname(req.file.originalname || req.file.filename));
  const template = await persistTemplateRecord({
    clientId,
    name: req.body.name || fallbackName,
    category: req.body.category || 'Custom',
    imagePath: templateImagePath,
    sourceType: 'uploaded',
    tags: req.body.tags,
    isFavorite: false
  });

  res.status(201).json({ template });
}));

app.post('/api/templates/from-generation', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const imagePath = String(req.body.imagePath || '').trim();
  if (!imagePath) {
    res.status(400).json({ error: 'imagePath is required.' });
    return;
  }

  const name = normalizeTemplateName(req.body.name, 'Saved Generation');
  const templateImagePath = copyImageIntoTemplateLibrary(imagePath, name);
  const template = await persistTemplateRecord({
    clientId,
    name,
    category: req.body.category || 'Custom',
    imagePath: templateImagePath,
    sourceType: 'saved_generation',
    tags: req.body.tags,
    isFavorite: false
  });

  res.status(201).json({ template });
}));

app.patch('/api/templates/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const id = Number(req.params.id);
  const existing = await dbGet('SELECT * FROM templates WHERE id = ? AND client_id = ?', [id, clientId]);

  if (!existing) {
    res.status(404).json({ error: 'Template not found.' });
    return;
  }

  const nextName = req.body.name !== undefined
    ? normalizeTemplateName(req.body.name, existing.name)
    : existing.name;

  const nextCategory = req.body.category !== undefined
    ? normalizeTemplateCategory(req.body.category, existing.category)
    : existing.category;

  const nextTags = req.body.tags !== undefined
    ? parseTemplateTags(req.body.tags)
    : parseTemplateTags(existing.tags);

  const nextFavorite = req.body.isFavorite !== undefined
    ? parseBoolean(req.body.isFavorite, Boolean(existing.is_favorite))
    : Boolean(existing.is_favorite);

  await executeQuery(`
    UPDATE templates
    SET name = ?, category = ?, tags = ?, is_favorite = ?
    WHERE id = ? AND client_id = ?
  `, [nextName, nextCategory, JSON.stringify(nextTags), nextFavorite ? 1 : 0, id, clientId]);

  const updated = parseTemplateRow(await dbGet('SELECT * FROM templates WHERE id = ? AND client_id = ?', [id, clientId]));
  res.json({ template: updated });
}));

app.delete('/api/templates/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const id = Number(req.params.id);
  const existing = await dbGet('SELECT * FROM templates WHERE id = ? AND client_id = ?', [id, clientId]);

  if (!existing) {
    res.status(404).json({ error: 'Template not found.' });
    return;
  }

  await executeQuery('DELETE FROM templates WHERE id = ? AND client_id = ?', [id, clientId]);

  const imagePath = String(existing.image_path || '').trim();
  const sourceType = String(existing.source_type || '').trim().toLowerCase();
  const shouldDeleteFile = imagePath.startsWith('/uploads/') && sourceType !== 'starter';

  if (shouldDeleteFile) {
    try {
      const stillReferenced = await dbGet('SELECT COUNT(*) AS count FROM templates WHERE image_path = ?', [imagePath]);
      const absolutePath = path.resolve(PUBLIC_DIR, imagePath.replace(/^\/+/, ''));
      if (
        Number(stillReferenced && stillReferenced.count) === 0 &&
        absolutePath.startsWith(PUBLIC_DIR) &&
        fs.existsSync(absolutePath)
      ) {
        fs.unlinkSync(absolutePath);
      }
    } catch (_error) {
      // Keep delete operation successful even if file cleanup fails.
    }
  }

  res.json({ ok: true });
}));

app.post('/api/prompt/reverse', asyncHandler(async (req, res) => {
  const imagePath = String(req.body.imagePath || '').trim();
  const context = normalizeWhitespace(req.body.context || '');
  const variantCount = Number(req.body.variantCount) || 4;

  if (!imagePath) {
    res.status(400).json({ error: 'imagePath is required.' });
    return;
  }

  const sourceAbsPath = resolveUploadPath(imagePath);
  const variantTarget = Math.max(1, Math.min(variantCount, 8));
  let normalized = null;
  let modelLabel = 'deterministic-style-blueprint-v1';

  if (getGeminiApiKey()) {
    try {
      const response = await callGeminiGenerateContent({
        system: [
          'You are a senior Meta static-ad strategist.',
          'Analyze the provided reference ad image and return a reusable style blueprint.',
          'Use visual structure only; never copy literal text, claims, or brand names.',
          'Return JSON only.'
        ].join(' '),
        userContent: [
          toGeminiInlineDataPart(sourceAbsPath),
          {
            type: 'text',
            text: [
              'Generate a style blueprint and variant prompts for static Meta ads.',
              context ? `Additional context: ${context}` : '',
              'Return ONLY valid JSON with exactly this shape:',
              '{"style_prompt":"string","layout_blueprint":["string"],"copy_skeleton":{"headline":"string","subheadline":"string","body":"string","cta":"string"},"rationale":"string","variant_prompts":[{"name":"string","prompt":"string"}]}',
              `variant_prompts must contain exactly ${variantTarget} items.`,
              'No markdown, no code fences, no extra keys.'
            ].filter(Boolean).join('\n')
          }
        ],
        maxTokens: 2200,
        temperature: 0.25
      });
      const parsed = extractJsonObjectFromText(response.text);
      normalized = normalizeStyleAnalysisResponse(parsed, response.text, variantTarget);
      modelLabel = response.model || modelLabel;
    } catch (error) {
      console.warn('[prompt.reverse] gemini reverse-planning failed; using deterministic fallback', {
        error: normalizeWhitespace(error && error.message) || 'Unknown reverse-planning error.'
      });
    }
  }

  if (!normalized) {
    const deterministicStyleSeed = [
      'Create a static Meta/Facebook ad with direct-response hierarchy.',
      'Use the provided reference image only for visual style, composition, and layout rhythm.',
      'Ignore literal reference text and never copy competitor claims or brand names.',
      'Keep output concise and conversion-focused with clear headline/product/CTA zones.',
      context ? `Additional context: ${context}` : ''
    ].filter(Boolean).join(' ');
    const parsed = {
      style_prompt: deterministicStyleSeed,
      layout_blueprint: [
        'Primary headline block near top with strong contrast',
        'Product anchor in mid-frame with clear focal hierarchy',
        'Support/proof strip near lower third with restrained text',
        'CTA zone at bottom with high-contrast treatment'
      ],
      copy_skeleton: {
        headline: '{HEADLINE}',
        subheadline: '{SUBHEADLINE}',
        body: '{BODY_COPY}',
        cta: '{CTA}'
      },
      rationale: 'Deterministic fallback blueprint generated locally (no vision-model analysis).'
    };
    normalized = normalizeStyleAnalysisResponse(parsed, '', variantTarget);
  }

  res.json({
    imagePath,
    model: modelLabel,
    stylePrompt: normalized.style_prompt,
    layoutBlueprint: normalized.layout_blueprint,
    copySkeleton: normalized.copy_skeleton,
    rationale: normalized.rationale,
    variantPrompts: normalized.variant_prompts,
    // Backward compatibility for earlier UI flows.
    basePrompt: normalized.style_prompt,
    variants: normalized.variant_prompts.map((item) => item.prompt)
  });
}));

app.post('/api/prompt/concepts', asyncHandler(async (req, res) => {
  const referenceImagePath = String(req.body.referenceImagePath || '').trim();
  const productImagePath = String(req.body.productImagePath || '').trim();
  const productContext = normalizeWhitespace(req.body.productContext || req.body.context || '');
  const conceptCount = Math.max(3, Math.min(Number(req.body.conceptCount) || 6, 8));

  if (!referenceImagePath) {
    res.status(400).json({ error: 'referenceImagePath is required.' });
    return;
  }

  const referenceAbsPath = resolveUploadPath(referenceImagePath);

  if (productImagePath) {
    // Validate product image path if provided. The image itself is not needed for this concept pass.
    resolveUploadPath(productImagePath);
  }

  let normalized = null;
  let modelLabel = 'deterministic-concept-portfolio-v1';

  if (getGeminiApiKey()) {
    try {
      const response = await callGeminiGenerateContent({
        system: [
          'You are a direct-response concept strategist for Meta static ads.',
          'Generate concept-level directions with meaningful strategic diversity.',
          'Return JSON only.'
        ].join(' '),
        userContent: [
          toGeminiInlineDataPart(referenceAbsPath),
          {
            type: 'text',
            text: [
              'Generate concept directions from this reference image (visual style only).',
              'Do not copy literal text, brand names, or claims from the reference.',
              productImagePath ? 'A separate product image exists and will be the only product-identity source in generation.' : '',
              productContext ? `Product context: ${productContext}` : '',
              `Provide exactly ${conceptCount} concepts.`,
              'Return ONLY valid JSON with exactly this shape:',
              '{"concepts":[{"id":"string","name":"string","concept_type":"string","angle":"string","audience_stage":"string","why_distinct":"string","distance_score":0,"prompt_template":"string","copy_skeleton":{"headline":"string","subheadline":"string","body":"string","cta":"string"}}],"recommended_id":"string","rationale":"string"}',
              'No markdown, no code fences, no extra keys.'
            ].filter(Boolean).join('\n')
          }
        ],
        maxTokens: 2600,
        temperature: 0.3
      });
      const parsed = extractJsonObjectFromText(response.text);
      normalized = normalizeConceptPortfolioResponse(parsed, response.text, conceptCount);
      modelLabel = response.model || modelLabel;
    } catch (error) {
      console.warn('[prompt.concepts] gemini concept planning failed; using deterministic fallback', {
        error: normalizeWhitespace(error && error.message) || 'Unknown concept-planning error.'
      });
    }
  }

  if (!normalized) {
    const parsed = {
      rationale: [
        'Concept portfolio generated from deterministic strategy matrix.',
        'Reference image is treated as visual-style input only.',
        productImagePath ? 'Product identity is locked to the uploaded product image.' : '',
        productContext ? `Product context: ${productContext}` : ''
      ].filter(Boolean).join(' ')
    };
    normalized = normalizeConceptPortfolioResponse(parsed, '', conceptCount);
  }

  res.json({
    referenceImagePath,
    productImagePath: productImagePath || null,
    model: modelLabel,
    concepts: normalized.concepts,
    recommendedConceptId: normalized.recommended_id,
    rationale: normalized.rationale
  });
}));

app.post('/api/campaign/plan', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const winningImagePaths = Array.isArray(req.body.winningImagePaths)
    ? req.body.winningImagePaths.map((item) => String(item || '').trim()).filter(Boolean)
    : [];
  const productImagePath = normalizeWhitespace(req.body.productImagePath || '');
  const generationStrategy = normalizeCampaignGenerationStrategy(req.body.generationStrategy || req.body.strategy || '');
  const profilePairs = normalizeProfilePairArray(req.body.profilePairs || req.body.profiles || [], 20);
  const offerCta = normalizeWhitespace(req.body.offerCta || req.body.offer || '').slice(0, 160);
  const tone = normalizeTone(req.body.tone || '');
  const campaignGoal = normalizeWhitespace(req.body.campaignGoal || '');
  const useBrandKit = parseBoolean(req.body.useBrandKit, true);
  const maxItems = Number(req.body.maxItems) || 24;
  const validatedProductPath = productImagePath ? resolveUploadPath(productImagePath) : null;

  if (generationStrategy === 'winner_iteration' && winningImagePaths.length === 0) {
    res.status(400).json({ error: 'At least one winning image is required for winner iteration mode.' });
    return;
  }
  if (generationStrategy === 'product_exploration' && !validatedProductPath) {
    res.status(400).json({ error: 'A product identity image is required for product-led exploration.' });
    return;
  }
  if (winningImagePaths.length === 0 && !validatedProductPath) {
    res.status(400).json({ error: 'Provide at least one winning image or a product image.' });
    return;
  }
  if (profilePairs.length === 0) {
    res.status(400).json({ error: 'At least one selected profile is required.' });
    return;
  }

  const validatedWinningPaths = winningImagePaths.slice(0, 8).map((item) => {
    resolveUploadPath(item);
    return item;
  });

  const targetItems = Math.max(1, Math.min(maxItems, 60));
  const items = [];
  let avatars = [];
  let concepts = [];
  const matrixMode = 'profile_pairs';
  let matrixUniqueCombinations = 0;
  let rationale = '';
  const normalizedPairs = profilePairs.map((pair, index) => {
    const avatarId = `avatar-profile-${index + 1}-${slugify(pair.persona).slice(0, 20) || 'audience'}`;
    const conceptId = `concept-profile-${index + 1}-${slugify(pair.angle).slice(0, 20) || 'angle'}`;
    return {
      id: `pair-${index + 1}`,
      avatar: {
        id: avatarId,
        name: pair.persona,
        source: 'profile',
        pain_point: pair.pain_point || '',
        overlooked_reason: ''
      },
      concept: {
        id: conceptId,
        name: pair.angle,
        source: 'profile',
        framework: ''
      },
      pain_point: pair.pain_point || '',
      emotion: pair.emotion || ''
    };
  });

  const avatarMap = new Map();
  const conceptMap = new Map();
  normalizedPairs.forEach((pair) => {
    const avatarKey = pair.avatar.name.toLowerCase();
    const conceptKey = pair.concept.name.toLowerCase();
    if (!avatarMap.has(avatarKey)) avatarMap.set(avatarKey, pair.avatar);
    if (!conceptMap.has(conceptKey)) conceptMap.set(conceptKey, pair.concept);
  });
  avatars = Array.from(avatarMap.values());
  concepts = Array.from(conceptMap.values());
  matrixUniqueCombinations = normalizedPairs.length;

  const pairCount = Math.max(1, normalizedPairs.length);
  for (let index = 0; index < targetItems; index += 1) {
    const pair = normalizedPairs[index % pairCount];
    const cycle = Math.floor(index / pairCount) + 1;
    const promptParts = [
      `Create a static Meta ad for avatar: ${pair.avatar.name}.`,
      `Concept angle: ${pair.concept.name}.`,
      pair.pain_point ? `Customer pain point: ${pair.pain_point}.` : '',
      pair.emotion ? `Target emotion: ${pair.emotion}.` : '',
      tone ? `Tone: ${tone}.` : '',
      offerCta ? `Offer/CTA to include: ${offerCta}.` : '',
      campaignGoal ? `Campaign goal: ${campaignGoal}.` : '',
      cycle > 1 ? `Variation cycle: ${cycle}. Keep this iteration meaningfully distinct from earlier variants for this profile pair.` : '',
      generationStrategy === 'product_exploration'
        ? 'Use product identity image as the primary source for product visuals.'
        : 'Use winning ad references for layout/style cues only.',
      'Keep product identity consistent with the selected product image when provided.',
      'This must be a static image ad, not a video.'
    ].filter(Boolean);

    items.push({
      id: `item-${index + 1}-${pair.id}-v${cycle}`,
      avatar_id: pair.avatar.id,
      concept_id: pair.concept.id,
      avatar_name: pair.avatar.name,
      concept_name: pair.concept.name,
      prompt_template: normalizeWhitespace(promptParts.join(' '))
    });
  }

  const plannedProfilePairs = normalizedPairs.map((pair) => ({
    persona: pair.avatar.name,
    angle: pair.concept.name,
    pain_point: pair.pain_point || '',
    emotion: pair.emotion || ''
  }));

  rationale = normalizeWhitespace(
    matrixUniqueCombinations < targetItems
      ? `Built from ${matrixUniqueCombinations} selected profiles. Profiles are reused/cycled to reach ${targetItems} requested ads.`
      : (matrixUniqueCombinations > targetItems
        ? `Built from ${matrixUniqueCombinations} selected profiles and sampled to ${targetItems} requested ads.`
        : `Built from ${matrixUniqueCombinations} selected profiles for ${targetItems} requested ads.`)
  );

  const plan = {
    generation_strategy: generationStrategy,
    planning_mode: matrixMode,
    product_image_path: productImagePath || null,
    avatars,
    concepts,
    profile_pairs: plannedProfilePairs,
    items,
    offer_cta: offerCta || null,
    tone: tone || null,
    campaign_goal: campaignGoal || null,
    matrix: {
      requested_ads: targetItems,
      profile_pairs: plannedProfilePairs.length,
      mode: matrixMode,
      style_references: validatedWinningPaths.length,
      avatars: avatars.length,
      concepts: concepts.length,
      unique_combinations: matrixUniqueCombinations,
      planned_ads: items.length
    },
    rationale
  };

  res.json({
    clientId,
    generationStrategy,
    productImagePath: productImagePath || null,
    winningImagePaths: validatedWinningPaths,
    model: 'structured-profile-plan-v1',
    plan
  });
}));

app.post('/api/campaign/generate', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  configureFal();
  const generationStrategy = normalizeCampaignGenerationStrategy(req.body.generationStrategy || req.body.strategy || '');
  const winningImagePaths = Array.isArray(req.body.winningImagePaths)
    ? req.body.winningImagePaths.map((item) => String(item || '').trim()).filter(Boolean)
    : [];
  const productImagePath = String(req.body.productImagePath || '').trim();
  const planItems = Array.isArray(req.body.planItems) ? req.body.planItems : [];
  const size = String(req.body.size || '1:1');
  const resolution = String(req.body.resolution || '1K');
  const useBrandKit = parseBoolean(req.body.useBrandKit, false);
  const allowReferenceProductFallback = parseBoolean(req.body.allowReferenceProductFallback, false);
  const requireGeminiPromptComposer = parseBoolean(req.body.requireGeminiPromptComposer, true);
  const maxItems = Math.max(1, Math.min(Number(req.body.maxItems) || planItems.length || 12, 50));
  const itemTimeoutMs = Math.max(
    60000,
    Math.min(
      Number(req.body.itemTimeoutMs) ||
      Number(process.env.CAMPAIGN_ITEM_TIMEOUT_MS) ||
      180000,
      600000
    )
  );
  const timeoutGraceMs = Math.max(
    0,
    Math.min(
      Number(req.body.timeoutGraceMs)
      || Number(process.env.CAMPAIGN_ITEM_TIMEOUT_GRACE_MS)
      || 120000,
      600000
    )
  );
  const concurrency = Math.max(
    1,
    Math.min(
      Number(req.body.concurrency)
      || Number(process.env.CAMPAIGN_GENERATION_CONCURRENCY)
      || 3,
      6
    )
  );

  if (generationStrategy === 'winner_iteration' && winningImagePaths.length === 0) {
    res.status(400).json({ error: 'winningImagePaths is required for winner iteration mode.' });
    return;
  }
  if (generationStrategy === 'product_exploration' && !productImagePath) {
    res.status(400).json({ error: 'productImagePath is required for product-led exploration.' });
    return;
  }
  if (winningImagePaths.length === 0 && !productImagePath) {
    res.status(400).json({ error: 'Provide at least one winning image or product image.' });
    return;
  }

  if (planItems.length === 0) {
    res.status(400).json({ error: 'planItems is required.' });
    return;
  }
  if (requireGeminiPromptComposer && !getGeminiApiKey()) {
    res.status(400).json({
      error: 'Gemini prompt composer is required, but GEMINI_API_KEY is not set.'
    });
    return;
  }

  const validatedWinningAbsPaths = winningImagePaths.slice(0, 8).map((publicPath) => resolveUploadPath(publicPath));
  const validatedWinningPublicPaths = winningImagePaths.slice(0, validatedWinningAbsPaths.length);
  const productAbsPath = productImagePath ? resolveUploadPath(productImagePath) : null;
  const hasStyleReference = validatedWinningAbsPaths.length > 0;
  const rawBrandKit = useBrandKit ? await getBrandKit(clientId) : null;
  const brandKit = rawBrandKit ? await hydrateBrandKitTypographyStyle(rawBrandKit) : null;
  const intelligenceLibrary = await listBrandIntelligence(clientId);
  const intelligenceResearchText = await getBrandIntelligenceResearchText(clientId);
  if (useBrandKit) {
    logBrandKitApplication('campaign.generate', clientId, brandKit);
  }

  const selectedItems = planItems.slice(0, maxItems);
  const plannerSeedItems = selectedItems.map((item, index) => {
    const resolvedItemId = normalizeWhitespace(item && item.id) || `item-${index + 1}`;
    const seedPrompt = normalizeWhitespace(
      (item && (item.prompt_template || item.prompt)) ||
      `Create a static ad for ${(item && (item.avatar_name || item.avatarName)) || 'target audience'} using ${(item && (item.concept_name || item.conceptName)) || 'a distinct concept'} framing.`
    );
    const parsedMeta = parseCampaignItemPromptMeta(seedPrompt);
    const avatarName = normalizeWhitespace(
      (item && (item.avatar_name || item.avatarName)) ||
      parsedMeta.avatarName ||
      extractGenerationAvatar(seedPrompt)
    );
    const conceptName = normalizeWhitespace(
      (item && (item.concept_name || item.conceptName)) ||
      parsedMeta.conceptName ||
      extractGenerationConcept(seedPrompt)
    );
    return {
      item_id: resolvedItemId,
      avatar_name: avatarName,
      concept_name: conceptName,
      seed_prompt: sanitizePlannerText(parsedMeta.cleanDirection || seedPrompt, 320),
      tone: sanitizePlannerText(parsedMeta.toneHint, 60),
      campaign_goal: sanitizePlannerText(parsedMeta.campaignGoal, 80),
      offer_cta: sanitizePlannerText(parsedMeta.offerCta, 60)
    };
  });

  let promptPlanner = {
    enabled: false,
    model: null,
    requestCount: 0,
    reason: ''
  };
  let plannerSpecsByItemId = {};
  const shouldUsePromptPlanner = !(hasStyleReference && generationStrategy === 'winner_iteration');
  if (shouldUsePromptPlanner) {
    try {
      promptPlanner = await planCreativeSpecsWithGemini({
        plannerItems: plannerSeedItems,
        generationStrategy,
        hasStyleReference,
        brandKit
      });
      plannerSpecsByItemId = promptPlanner && promptPlanner.specsByItemId ? promptPlanner.specsByItemId : {};
      if (promptPlanner.enabled) {
        console.info('[prompt-planner] gemini planning complete', {
          enabled: true,
          model: promptPlanner.model,
          requestCount: promptPlanner.requestCount,
          plannedItems: Object.keys(plannerSpecsByItemId).length
        });
      } else {
        console.info('[prompt-planner] gemini planning skipped', {
          enabled: false,
          reason: promptPlanner.reason
        });
      }
    } catch (error) {
      const plannerError = normalizeWhitespace(error && error.message) || 'Unknown Gemini planner error.';
      console.warn('[prompt-planner] gemini planning failed, using deterministic fallback', {
        error: plannerError
      });
      promptPlanner = {
        enabled: false,
        model: null,
        requestCount: 0,
        reason: plannerError
      };
      plannerSpecsByItemId = {};
    }
  } else {
    promptPlanner = {
      enabled: false,
      model: null,
      requestCount: 0,
      reason: 'Skipped for winner-iteration reference-led mode.'
    };
    plannerSpecsByItemId = {};
    console.info('[prompt-planner] skipped for winner-iteration reference-led mode');
  }

  const results = [];
  const failures = [];
  let completedItems = 0;
  let timedOutItems = 0;
  let geminiPromptComposedItems = 0;
  let geminiPromptFailedItems = 0;
  const usedLayoutCounts = {};
  const styleSourceAbsPath = hasStyleReference ? validatedWinningAbsPaths[0] : null;
  const styleProfile = styleSourceAbsPath
    ? await analyzeReferenceStyleProfile(styleSourceAbsPath)
    : null;

  const preparedItems = selectedItems.map((item, index) => {
    const safeItem = item || {};
    const resolvedItemId = normalizeWhitespace(safeItem.id || '') || `item-${index + 1}`;
    const plannerSpec = plannerSpecsByItemId[resolvedItemId] || null;
    const referenceAbsPath = validatedWinningAbsPaths.length > 0
      ? validatedWinningAbsPaths[index % validatedWinningAbsPaths.length]
      : productAbsPath;
    const referencePublicPath = validatedWinningPublicPaths.length > 0
      ? validatedWinningPublicPaths[index % validatedWinningPublicPaths.length]
      : (productImagePath || '');
    const effectiveProductAbsPath = productAbsPath || referenceAbsPath;
    const effectiveProductPublicPath = productImagePath || referencePublicPath;
    const hasDistinctProductImage = Boolean(productAbsPath && referenceAbsPath && productAbsPath !== referenceAbsPath);
    const itemPrompt = normalizeWhitespace(
      safeItem.prompt_template ||
      safeItem.prompt ||
      `Create a static ad for ${safeItem.avatar_name || 'target audience'} using ${safeItem.concept_name || 'a distinct concept'} framing.`
    );
    const parsedItemMeta = parseCampaignItemPromptMeta(itemPrompt);
    const avatarCandidate = (
      safeItem.avatar_name
      || safeItem.avatarName
      || (safeItem.avatar && typeof safeItem.avatar === 'object' ? safeItem.avatar.name : safeItem.avatar)
      || parsedItemMeta.avatarName
      || extractGenerationAvatar(itemPrompt)
      || ''
    );
    const conceptCandidate = (
      safeItem.concept_name
      || safeItem.conceptName
      || (safeItem.concept && typeof safeItem.concept === 'object' ? safeItem.concept.name : safeItem.concept)
      || parsedItemMeta.conceptName
      || extractGenerationConcept(itemPrompt)
      || ''
    );
    const avatarName = normalizeWhitespace(avatarCandidate);
    const conceptName = normalizeWhitespace(conceptCandidate);
    const toneHint = normalizeWhitespace(parsedItemMeta.toneHint || '');
    const offerCta = normalizeWhitespace(parsedItemMeta.offerCta || (plannerSpec && plannerSpec.cta_hint) || '');
    const campaignGoal = normalizeWhitespace(parsedItemMeta.campaignGoal || '');
    const variationCycle = normalizeWhitespace(parsedItemMeta.variationCycle || '');
    const matchedIntelligence = findBestBrandIntelligenceMatch(intelligenceLibrary, avatarName, conceptName);
    const plannerDirection = (hasStyleReference && generationStrategy === 'winner_iteration')
      ? ''
      : (plannerSpec
      ? [
        plannerSpec.scene_direction ? `Scene direction: ${plannerSpec.scene_direction}.` : '',
        plannerSpec.copy_framework ? `Use ${plannerSpec.copy_framework} persuasion structure.` : '',
        plannerSpec.visual_format ? `Preferred visual format: ${plannerSpec.visual_format}.` : '',
        plannerSpec.product_integration ? `Product integration style: ${plannerSpec.product_integration}.` : '',
        plannerSpec.headline_hint ? `Headline hint: ${plannerSpec.headline_hint}.` : '',
        plannerSpec.supporting_line_hint ? `Supporting line hint: ${plannerSpec.supporting_line_hint}.` : '',
        plannerSpec.cta_hint ? `CTA hint: ${plannerSpec.cta_hint}.` : '',
        plannerSpec.why_distinct ? `Distinctive angle note: ${plannerSpec.why_distinct}.` : ''
      ].filter(Boolean).join(' ')
      : '');
    const layoutPattern = (hasStyleReference && generationStrategy === 'winner_iteration')
      ? null
      : chooseLayoutPattern({
        conceptName,
        avatarName,
        itemIndex: index,
        usedLayoutCounts
      });
    const antiDup = (hasStyleReference && generationStrategy === 'winner_iteration')
      ? [
        'Do not duplicate competitor brand identity or literal copy.',
        'Preserve the reference ad layout family (global structure and hierarchy) for this winning-ad iteration.',
        'Vary audience-specific messaging, supporting props, and details without changing the core composition pattern.'
      ].join(' ')
      : [
        'Do not duplicate the source ad.',
        'Use a structurally distinct composition from other outputs in this batch.',
        'Change paneling, headline placement, and callout architecture as needed for this concept.',
        hasStyleReference
          ? 'Use the reference ad only as a style/quality guide, not a fixed template.'
          : 'No fixed style template is provided for this item. Build a fresh composition from strategy cues.'
      ].join(' ');
    const finalPrompt = buildCampaignGenerationPrompt({
      itemPrompt: [
        parsedItemMeta.cleanDirection || '',
        matchedIntelligence && matchedIntelligence.pain_point ? `Customer pain point: ${matchedIntelligence.pain_point}.` : '',
        matchedIntelligence && matchedIntelligence.emotion ? `Target emotion: ${matchedIntelligence.emotion}.` : '',
        plannerDirection,
        antiDup
      ].filter(Boolean).join(' '),
      avatarName,
      conceptName,
      brandKit,
      hasProductImage: Boolean(productAbsPath),
      hasStyleReference,
      generationStrategy,
      layoutPattern,
      styleProfile,
      campaignItemIndex: index + 1,
      toneHint,
      offerCta,
      campaignGoal,
      variationCycle
    });
    const generationImagePaths = hasDistinctProductImage
      ? [referenceAbsPath, effectiveProductAbsPath].filter(Boolean)
      : [referenceAbsPath].filter(Boolean);

    return {
      index,
      resolvedItemId,
      avatarName,
      conceptName,
      referencePublicPath,
      referenceAbsPath,
      effectiveProductPublicPath,
      hasDistinctProductImage,
      effectiveProductAbsPath,
      generationImagePaths,
      finalPrompt,
      toneHint,
      offerCta,
      campaignGoal,
      variationCycle,
      matchedIntelligence
    };
  });

  const referenceBlueprintByPath = new Map();
  if (requireGeminiPromptComposer) {
    const uniqueReferencePaths = Array.from(new Set(
      preparedItems
        .map((item) => item && item.referenceAbsPath ? String(item.referenceAbsPath) : '')
        .filter(Boolean)
    ));
    for (const referencePath of uniqueReferencePaths) {
      try {
        const blueprintResult = await extractReferenceBlueprintWithGemini(referencePath);
        if (blueprintResult.enabled && blueprintResult.blueprint) {
          referenceBlueprintByPath.set(referencePath, blueprintResult.blueprint);
        }
      } catch (error) {
        console.warn('[campaign.generate] reference blueprint extraction failed for path; continuing without blueprint', {
          error: normalizeWhitespace(error && error.message) || 'Unknown reference blueprint error.'
        });
      }
    }
  }

  let cursor = 0;
  const workerCount = Math.min(concurrency, preparedItems.length);
  const workers = Array.from({ length: workerCount }, () => (async () => {
    while (true) {
      const workIndex = cursor;
      cursor += 1;
      if (workIndex >= preparedItems.length) {
        break;
      }

      const item = preparedItems[workIndex];
      let promptForRecord = item.finalPrompt;
      try {
        let generatedImages = [];
        let composedPromptModel = null;
        let composedPromptRationale = '';
        console.info('[campaign.generate] item payload', {
          itemIndex: item.index + 1,
          totalItems: preparedItems.length,
          referenceImagePath: item.referencePublicPath,
          productImagePath: item.effectiveProductPublicPath,
          hasProductImage: Boolean(item.effectiveProductAbsPath),
          imageRefCount: item.generationImagePaths.length,
          usesTwoImageEditMode: item.hasDistinctProductImage,
          generationStrategy,
          hasStyleReference,
          allowReferenceProductFallback,
          promptPlannerEnabled: Boolean(promptPlanner && promptPlanner.enabled),
          promptPlannerModel: promptPlanner && promptPlanner.model ? promptPlanner.model : null,
          requireGeminiPromptComposer,
          concurrency: workerCount
        });
        const composition = await composeNanoBananaPromptWithGemini({
          productAbsPath: item.effectiveProductAbsPath,
          referenceAbsPath: item.referenceAbsPath,
          referenceBlueprint: referenceBlueprintByPath.get(String(item.referenceAbsPath || '')) || null,
          avatarName: item.avatarName,
          conceptName: item.conceptName,
          toneHint: item.toneHint,
          offerCta: item.offerCta,
          campaignGoal: item.campaignGoal,
          variationCycle: item.variationCycle,
          extraInstructions: [
            item.matchedIntelligence && item.matchedIntelligence.pain_point
              ? `Primary pain point: ${item.matchedIntelligence.pain_point}.`
              : '',
            item.matchedIntelligence && item.matchedIntelligence.emotion
              ? `Target emotion: ${item.matchedIntelligence.emotion}.`
              : ''
          ].filter(Boolean).join(' '),
          brandKit,
          selectedProfile: item.matchedIntelligence || null,
          brandProfiles: intelligenceLibrary,
          researchText: intelligenceResearchText
        });
        if (!composition.enabled || !composition.prompt) {
          throw new Error(
            composition && composition.reason
              ? `Gemini prompt composition failed: ${composition.reason}`
              : 'Gemini prompt composition failed before generation.'
          );
        }
        promptForRecord = composition.prompt;
        composedPromptModel = composition.model || null;
        composedPromptRationale = composition.rationale || '';
        geminiPromptComposedItems += 1;
        const falPrompt = promptForRecord;
        console.info('[campaign.generate] prompt composed', {
          itemIndex: item.index + 1,
          model: composedPromptModel,
          rationale: truncatePromptContext(composedPromptRationale, 200)
        });
        const generationPromise = runFalGeneration({
          imagePaths: item.generationImagePaths,
          prompt: falPrompt,
          numImages: 1,
          aspectRatio: size,
          resolution
        });
        try {
          generatedImages = await withTimeout(
            generationPromise,
            itemTimeoutMs,
            `Campaign item ${item.index + 1}`
          );
        } catch (firstTimeoutError) {
          const timeoutMessage = normalizeWhitespace(firstTimeoutError && firstTimeoutError.message) || 'Generation failed.';
          if (!/timed out/i.test(timeoutMessage) || timeoutGraceMs <= 0) {
            throw firstTimeoutError;
          }
          console.warn('[campaign.generate] extending timeout window for long-running FAL job', {
            itemIndex: item.index + 1,
            totalItems: preparedItems.length,
            itemTimeoutMs,
            timeoutGraceMs
          });
          generatedImages = await withTimeout(
            generationPromise,
            timeoutGraceMs,
            `Campaign item ${item.index + 1} (extended wait)`
          );
        }

        if (!generatedImages.length) {
          throw new Error('No generated images returned.');
        }

        const generation = await saveGenerationRecord({
          clientId,
          referenceImagePath: item.referencePublicPath,
          productImagePath: item.effectiveProductPublicPath,
          prompt: falPrompt,
          conceptName: item.conceptName,
          avatarName: item.avatarName,
          size,
          usedBrandKit: Boolean(useBrandKit),
          generatedImages,
          status: 'completed'
        });

        completedItems += 1;
        for (const imagePath of generatedImages) {
          results.push({
            item_index: item.index,
            item_id: item.resolvedItemId,
            avatar_name: item.avatarName,
            concept_name: item.conceptName,
            image_path: imagePath,
            generation_id: generation.id
          });
        }
      } catch (error) {
        const message = normalizeWhitespace(error && error.message) || 'Generation failed.';
        if (/timed out/i.test(message)) {
          timedOutItems += 1;
        }
        if (/gemini prompt composition failed/i.test(message)) {
          geminiPromptFailedItems += 1;
        }

        await saveGenerationRecord({
          clientId,
          referenceImagePath: item.referencePublicPath,
          productImagePath: item.effectiveProductPublicPath,
          prompt: promptForRecord,
          conceptName: item.conceptName,
          avatarName: item.avatarName,
          size,
          usedBrandKit: Boolean(useBrandKit),
          generatedImages: [],
          status: 'failed'
        });
        failures.push({
          item_index: item.index,
          item_id: item.resolvedItemId,
          avatar_name: item.avatarName,
          concept_name: item.conceptName,
          reason: message
        });
      }
    }
  })());
  await Promise.all(workers);
  results.sort((a, b) => Number(a.item_index || 0) - Number(b.item_index || 0));
  failures.sort((a, b) => Number(a.item_index || 0) - Number(b.item_index || 0));

  const responseStatus = failures.length > 0 ? 207 : 201;
  const publicResults = results.map((item) => ({
    item_id: item.item_id,
    avatar_name: item.avatar_name,
    concept_name: item.concept_name,
    image_path: item.image_path,
    generation_id: item.generation_id
  }));
  const publicFailures = failures.map((item) => ({
    item_id: item.item_id,
    avatar_name: item.avatar_name,
    concept_name: item.concept_name,
    reason: item.reason
  }));
  res.status(responseStatus).json({
    clientId,
    generationStrategy,
    results: publicResults,
    images: publicResults.map((item) => item.image_path),
    failures: publicFailures,
    summary: {
      requestedItems: selectedItems.length,
      completedItems,
      failedItems: publicFailures.length,
      timedOutItems,
      itemTimeoutMs,
      timeoutGraceMs,
      concurrency: workerCount,
      promptComposer: {
        provider: 'gemini',
        required: Boolean(requireGeminiPromptComposer),
        composedItems: geminiPromptComposedItems,
        failedItems: geminiPromptFailedItems
      },
      promptPlanner: {
        provider: 'gemini',
        enabled: Boolean(promptPlanner && promptPlanner.enabled),
        model: promptPlanner && promptPlanner.model ? promptPlanner.model : null,
        requestCount: Number(promptPlanner && promptPlanner.requestCount) || 0,
        reason: promptPlanner && promptPlanner.reason ? promptPlanner.reason : ''
      }
    }
  });
}));

app.get('/api/assets', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const search = String(req.query.search || '').trim();
  const category = normalizeAssetCategory(req.query.category, '');
  const params = [clientId];
  let sql = 'SELECT * FROM assets WHERE client_id = ?';

  if (search) {
    sql += ' AND original_name LIKE ?';
    params.push(`%${search}%`);
  }

  if (category) {
    sql += ' AND category = ?';
    params.push(category);
  }

  sql += ' ORDER BY created_at DESC';

  const rows = (await dbAll(sql, params)).map(toAssetResponse);
  res.json({ assets: rows, clientId });
}));

app.post('/api/assets/upload', assetUpload.array('assets', 20), asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const files = Array.isArray(req.files) ? req.files : [];
  if (files.length === 0) {
    res.status(400).json({ error: 'No files uploaded.' });
    return;
  }

  const created = await withDbTransaction(async (tx) => {
    const rows = [];
    for (const file of files) {
      const filePath = toPublicPath(file.path);
      const normalizedCategory = normalizeAssetCategory(req.body && req.body.category, 'Other');
      const inserted = await tx.query(`
        INSERT INTO assets (
          client_id,
          filename,
          original_name,
          file_type,
          file_size,
          category,
          file_path,
          created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        RETURNING id
      `, [
        clientId,
        file.filename,
        file.originalname,
        file.mimetype,
        Number(file.size || 0),
        normalizedCategory,
        filePath
      ]);
      const insertedId = inserted && inserted.rows && inserted.rows[0] ? Number(inserted.rows[0].id) : null;
      const row = await tx.get('SELECT * FROM assets WHERE id = ? AND client_id = ?', [insertedId, clientId]);
      rows.push(toAssetResponse(row));
    }
    return rows;
  });

  res.status(201).json({ assets: created });
}));

async function applyAssetCategoryUpdate(clientId, id, rawCategory) {
  if (!Number.isFinite(id) || id <= 0) {
    return { status: 400, error: 'Valid asset id is required.' };
  }

  const asset = await dbGet('SELECT * FROM assets WHERE id = ? AND client_id = ?', [id, clientId]);
  if (!asset) {
    return { status: 404, error: 'Asset not found.' };
  }

  const category = normalizeAssetCategory(rawCategory, '');
  if (!category) {
    return { status: 400, error: 'Valid category is required.' };
  }

  await executeQuery('UPDATE assets SET category = ? WHERE id = ? AND client_id = ?', [category, id, clientId]);
  const updated = await dbGet('SELECT * FROM assets WHERE id = ? AND client_id = ?', [id, clientId]);
  return { status: 200, asset: toAssetResponse(updated) };
}

app.post('/api/assets/category', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const id = Number(req.body && (req.body.assetId ?? req.body.id));
  const result = await applyAssetCategoryUpdate(clientId, id, req.body && req.body.category);

  if (result.error) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  res.status(result.status).json({ asset: result.asset, clientId });
}));

app.patch('/api/assets/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const id = Number(req.params.id);
  const result = await applyAssetCategoryUpdate(clientId, id, req.body && req.body.category);

  if (result.error) {
    res.status(result.status).json({ error: result.error });
    return;
  }

  res.status(result.status).json({ asset: result.asset, clientId });
}));

app.delete('/api/assets/:id', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const id = Number(req.params.id);
  const asset = await dbGet('SELECT * FROM assets WHERE id = ? AND client_id = ?', [id, clientId]);

  if (!asset) {
    res.status(404).json({ error: 'Asset not found.' });
    return;
  }

  await executeQuery('DELETE FROM assets WHERE id = ? AND client_id = ?', [id, clientId]);

  const absolutePath = path.resolve(PUBLIC_DIR, String(asset.file_path || '').replace(/^\/+/, ''));
  if (absolutePath.startsWith(PUBLIC_DIR) && fs.existsSync(absolutePath)) {
    fs.unlinkSync(absolutePath);
  }

  res.json({ success: true });
}));

app.get('/api/generations', asyncHandler(async (_req, res) => {
  const clientId = await getRequestClientId(_req);
  const rows = await dbAll('SELECT * FROM generations WHERE client_id = ? ORDER BY created_at DESC, id DESC LIMIT 100', [clientId]);
  res.json({ generations: rows.map(parseGenerationRow), clientId });
}));

app.post('/api/generations/delete-image', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  const imagePath = String(req.body.imagePath || '').trim();
  if (!imagePath || !imagePath.startsWith('/uploads/')) {
    res.status(400).json({ error: 'Valid imagePath is required.' });
    return;
  }

  let updatedRows = 0;

  await withDbTransaction(async (tx) => {
    const rows = await tx.all('SELECT id, generated_images FROM generations WHERE client_id = ?', [clientId]);
    for (const row of rows) {
      const images = parseGeneratedImages(row.generated_images);
      const imagePaths = images.map((item) => getGeneratedImagePath(item)).filter(Boolean);
      if (!imagePaths.includes(imagePath)) continue;
      const nextImages = images.filter((item) => getGeneratedImagePath(item) !== imagePath);
      await tx.query('UPDATE generations SET generated_images = ? WHERE id = ? AND client_id = ?', [JSON.stringify(nextImages), row.id, clientId]);
      updatedRows += 1;
    }
  });

  if (updatedRows === 0) {
    res.status(404).json({ error: 'Image not found in generation history.' });
    return;
  }

  const absolutePath = path.resolve(PUBLIC_DIR, imagePath.replace(/^\/+/, ''));
  if (absolutePath.startsWith(PUBLIC_DIR) && fs.existsSync(absolutePath)) {
    fs.unlinkSync(absolutePath);
  }

  res.json({ success: true, updatedRows });
}));

app.post('/api/generate', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  configureFal();
  const {
    referenceImagePath,
    productImagePath,
    prompt,
    size,
    resolution,
    numImages,
    useBrandKit
  } = req.body;

  if (!referenceImagePath || !productImagePath) {
    res.status(400).json({ error: 'Reference image and product image are required.' });
    return;
  }

  if (!prompt || String(prompt).trim().length === 0) {
    res.status(400).json({ error: 'Prompt is required.' });
    return;
  }

  const referencePath = resolveUploadPath(referenceImagePath);
  const productPath = resolveUploadPath(productImagePath);
  const rawBrandKit = useBrandKit ? await getBrandKit(clientId) : null;
  const brandKit = rawBrandKit ? await hydrateBrandKitTypographyStyle(rawBrandKit) : null;
  if (useBrandKit) {
    logBrandKitApplication('generate', clientId, brandKit);
  }
  const finalPrompt = withBrandPrompt(String(prompt).trim(), brandKit);
  const falPrompt = buildTwoImageEditPrompt(finalPrompt);

  const generatedImages = await runFalGeneration({
    imagePaths: [referencePath, productPath],
    prompt: falPrompt,
    numImages,
    aspectRatio: size || '1:1',
    resolution: resolution || '1K'
  });

  const generation = await saveGenerationRecord({
    clientId,
    referenceImagePath,
    productImagePath,
    prompt: finalPrompt,
    size: size || '1:1',
    usedBrandKit: Boolean(useBrandKit),
    generatedImages,
    status: 'completed'
  });

  res.status(201).json({ generation, images: generatedImages, clientId });
}));

app.post('/api/generate/edit', asyncHandler(async (req, res) => {
  const clientId = await getRequestClientId(req);
  configureFal();
  const { generationId, imagePath, prompt, size, resolution, numImages, useBrandKit } = req.body;

  if (!prompt || String(prompt).trim().length === 0) {
    res.status(400).json({ error: 'Prompt is required.' });
    return;
  }

  let sourceImagePath = imagePath;

  if (!sourceImagePath && generationId) {
    const existing = await dbGet('SELECT * FROM generations WHERE id = ? AND client_id = ?', [Number(generationId), clientId]);
    if (!existing) {
      res.status(404).json({ error: 'Generation not found.' });
      return;
    }

    const existingImages = parseGeneratedImages(existing.generated_images);
    sourceImagePath = getGeneratedImagePath(existingImages[0]) || existing.reference_image_path || null;
  }

  if (!sourceImagePath) {
    res.status(400).json({ error: 'imagePath or generationId is required.' });
    return;
  }

  const sourceAbsPath = resolveUploadPath(sourceImagePath);
  const rawBrandKit = useBrandKit ? await getBrandKit(clientId) : null;
  const brandKit = rawBrandKit ? await hydrateBrandKitTypographyStyle(rawBrandKit) : null;
  if (useBrandKit) {
    logBrandKitApplication('generate.edit', clientId, brandKit);
  }
  const finalPrompt = withBrandPrompt(String(prompt).trim(), brandKit);

  const generatedImages = await runFalGeneration({
    imagePaths: [sourceAbsPath],
    prompt: finalPrompt,
    numImages,
    aspectRatio: size || '1:1',
    resolution: resolution || '1K'
  });

  const generation = await saveGenerationRecord({
    clientId,
    referenceImagePath: sourceImagePath,
    productImagePath: null,
    prompt: finalPrompt,
    size: size || '1:1',
    usedBrandKit: Boolean(useBrandKit),
    generatedImages,
    status: 'completed'
  });

  res.status(201).json({ generation, images: generatedImages, clientId });
}));

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    res.status(400).json({ error: err.message });
    return;
  }

  let message = err.message || 'Internal server error.';
  if (err.body && Array.isArray(err.body.detail) && err.body.detail[0] && err.body.detail[0].msg) {
    message = err.body.detail[0].msg;
  }

  const statusCode = err.message && err.message.includes('FAL_KEY')
    ? 400
    : Number(err.status) || 500;
  res.status(statusCode).json({ error: message });
});

async function startServer() {
  try {
    db = await initDb();
    app.listen(PORT, HOST, () => {
      const localUrl = `http://localhost:${PORT}`;
      const hostUrl = HOST === '0.0.0.0' ? localUrl : `http://${HOST}:${PORT}`;
      console.log(`\nApp running at ${hostUrl}\nLocal testing URL: ${localUrl}\n`);
    });
  } catch (error) {
    console.error('Failed to initialize PostgreSQL:', error && error.message ? error.message : error);
    process.exit(1);
  }
}

startServer();
