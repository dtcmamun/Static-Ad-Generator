# Project Name - Development Notes

## Project Overview
<!-- Brief description of what this app does -->

## Tech Stack
- **Backend**: Node.js/Express
- **Frontend**: Single HTML file with Tailwind CSS, vanilla JS
- **Hosting**: Replit

## Replit-Specific Notes

### Port
- Server MUST default to port 5000: `process.env.PORT || 5000`
- Replit's dev preview only shows apps on port 5000

### Secrets (Environment Variables)
- On Replit: Add via the Secrets panel (lock icon in sidebar)
- Locally: Copy `.env.example` to `.env`

### SQLite (if using better-sqlite3)
- MUST disable foreign keys after opening DB: `db.pragma('foreign_keys = OFF')`
- Replit enforces foreign keys by default (unlike most local setups)
- `INSERT OR REPLACE` triggers delete+reinsert which breaks FK constraints

### External Assets (CDN images, etc.)
- Always download external assets locally during processing
- CDN URLs (Facebook, etc.) expire — local copies don't
- Serve via Express static: `app.use(express.static('public'))`
- Add asset directories to `.gitignore`

### Building ZIP for Replit Import
- Run `./build-replit-zip.sh` from the project root
- Files MUST be at root level in the ZIP (no wrapping folder)
- Exclude: node_modules, .env, .git, user-generated files

## Server Details
- Port: 5000 (configurable via PORT env var)
- Entry point: server.js

## Files to Know
- `server.js` - All backend logic and API routes
- `views/index.html` - Full frontend (HTML + CSS + JS)

## API Endpoints
<!-- Document your endpoints here -->
- `GET /api/health` - Health check
