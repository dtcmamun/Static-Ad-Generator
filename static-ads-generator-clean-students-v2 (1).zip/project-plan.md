# Meta Static Ads Generator — Product Plan (Revised)

## Direction Lock (Based on Founder Feedback)

### Keep in Scope
- AI image generation workflow for Meta static creatives
- Brand memory (logos, colors, typography, guidelines)
- Image-to-prompt reverse engineering for winning ad scaling
- A/B variant generation from one concept (structured test angles)
- Reference-first template workflow (user references + saved winners)

### Out of V1
- Carousel auto-assembly
- Andromeda-style variant-distance framework (`>=40%`) as a hard requirement

### Key Decision: Template Library Strategy
- Do **not** make V1 depend on manually curated niche template packs.
- Ship a small starter template set for onboarding/demo only.
- Let users upload references and promote winning generations into reusable templates.
- Treat the template system as a living internal library, not a static catalog.

---

## Product Goal

Ship a Replit-ready app where a student/agency can:
1. upload references + product assets,
2. generate branded static ads quickly,
3. produce structured variants for testing,
4. save winners as reusable references.

No auth/payments for V1. Focus on speed, reliability, and campaign iteration.

---

## Current Stack

- Backend: Node.js + Express
- Frontend: single-page HTML + Tailwind CDN + vanilla JS
- Database: SQLite (`better-sqlite3`)
- AI: FAL (`fal-ai/nano-banana-pro/edit`)
- Hosting target: Replit (port 5000)

---

## Current Baseline (Already Implemented)

- Brand kit CRUD + logo upload
- Asset library upload/search/delete
- Template browser + category filter
- Core generation + re-prompt
- Local persistence of generated images + generation history
- Basic placeholder template set

---

## Revised Roadmap

## V1 (Ship This)

### 1) Reference-First Template System
- Keep small starter templates (demo quality).
- Add `Save as Template` action on generated results/history images.
- Add `Upload as Template` action in Templates view.
- Add template tags/labels (e.g. "UGC-style", "Problem/Solution", "Offer heavy") for quick retrieval.
- Maintain optional category filter, but prioritize user-owned references.

### 2) Image-to-Prompt Reverse Engineering (Core Request)
- Add endpoint: `POST /api/prompt/reverse`
- Input: one image (winning ad) + optional context (niche/product).
- Output:
  - extracted creative prompt
  - short rationale (layout, offer style, visual tone)
  - `4` ready-to-run prompt variants
- UI:
  - new "Reverse Engineer" action for template/asset/history images
  - one-click "Generate 4 Variants"

### 3) Structured A/B Variant Generator
- Add variant mode to generator:
  - Angle: fear vs aspiration vs authority vs social-proof
  - Visual density: minimal vs moderate vs busy
  - CTA placement: top, middle, bottom
  - Overlay intensity: none, light, heavy
- Generate 4 variants with explicit metadata per output.
- Store metadata with generation records for post-run comparison.

### 4) Brand Memory Hardening
- Extend brand data to include:
  - tone words (e.g. premium, urgent, friendly),
  - compliance notes (claims to avoid),
  - brand do/don't rules.
- Add "default prompt prefix" generated from brand profile.
- Add "strict brand mode" toggle (higher adherence, lower novelty).

### 5) Lightweight Copy Hooks (V1-Simple)
- Add optional fields in generator:
  - target avatar
  - pain point
  - offer
- Return:
  - 1 headline,
  - 1 primary text,
  - 1 CTA suggestion
  alongside image output.
- Keep this simple and deterministic; full copy studio is V2.

### 6) UX/Ops Quality
- Better empty states + onboarding hints
- Improved loading/progress messages
- Clear, actionable error handling (FAL and upload failures)
- Safer local environment checks (missing `FAL_KEY`, invalid file types)

---

## V1.5 (After Initial Ship)

- Batch campaign builder (12-20 variants in one run plan, executed in chunks)
- Result grouping by concept > angle > style
- Export run summary (CSV/JSON): prompt, variant metadata, image path
- Saved "prompt frameworks" library per niche/team

---

## V2

- Niche packs as optional add-ons (home services, local SMB, e-comm)
- Full copy engine with multi-hook output sets
- Collaboration/review workflow
- Advanced variant-distance controls (Andromeda-style rubric)

---

## Data Model Additions (Planned)

### `templates` table
- add fields:
  - `source_type` (`starter` | `uploaded` | `saved_generation`)
  - `tags` (JSON)
  - `is_favorite` (0/1)

### `generations` table
- add fields:
  - `variant_group_id`
  - `variant_metadata` (JSON: angle/style/cta/text overlay)
  - `headline`
  - `primary_text`
  - `cta_text`

### Optional new table: `prompt_frameworks`
- `id`, `name`, `niche`, `base_prompt`, `variables`, `created_at`

---

## API Additions (Planned)

- `POST /api/templates/upload`
- `POST /api/templates/from-generation`
- `PATCH /api/templates/:id` (tags/favorite/category updates)
- `POST /api/prompt/reverse`
- `POST /api/generate/variants` (4 structured variants)

---

## Execution Order (Next Build Cycle)

1. Template system upgrade (`Save as Template`, `Upload as Template`, tags)
2. Reverse-engineer endpoint + UI
3. Structured 4-variant generator + metadata persistence
4. Brand memory schema extension + strict mode
5. Lightweight hook/copy output integration
6. UX polish and regression pass

---

## Acceptance Criteria for V1

1. User can generate from:
- starter template, uploaded reference, or saved winner.

2. User can reverse-engineer one ad and run 4 new variants from it in one flow.

3. User can generate a 4-variant test set with explicit metadata labels.

4. User can save generated outputs as templates and reuse them in future sessions.

5. Brand memory consistently affects prompt construction when enabled.

6. History shows prompts, variant labels, and resulting images for each run.

---

## Explicit Non-Goals (V1)

- Carousel story assembly
- Massive curated niche library managed manually
- Strict formal variant-distance enforcement framework
- Multi-user collaboration/auth/payments
