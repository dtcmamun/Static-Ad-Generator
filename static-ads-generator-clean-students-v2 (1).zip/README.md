# Replit Starter Template (Node.js + Express)

Minimal starter template for deploying an app on Replit.

## Quick Start (Replit)

1. Import this project into Replit (ZIP or GitHub).
2. Click **Run**.
3. Open the Replit web preview.

The app runs on port `5000` and exposes:

- `GET /` - starter page
- `GET /api/health` - health check

## Local Run

```bash
npm install
npm start
```

Defaults:

- `PORT=5000`
- `NODE_ENV=production` (set in `.replit`)

For local overrides, copy `.env.example` to `.env`.
